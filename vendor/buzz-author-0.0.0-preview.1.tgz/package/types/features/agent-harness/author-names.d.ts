import type { AgentReads } from "../agents/reads";
import type { EventData } from "../relay/events";
import type { AuthorNames } from "./turn-records";
/** How long a turn waits for profiles before naming whom it can. */
export declare const AUTHOR_NAMES_TIMEOUT_MS = 2000;
/** Reads the profiles of these messages' authors, for at most
 * `AUTHOR_NAMES_TIMEOUT_MS`, and gives each author's names once known. A
 * message the signing authority posted for someone is theirs. A turn without
 * the reads names no one. */
export declare function readAuthorNames(reads: Pick<AgentReads, "profiles" | "authorNames"> | undefined, messages: readonly EventData[], signingAuthority?: string): Promise<(pubkey: string) => AuthorNames | undefined>;
