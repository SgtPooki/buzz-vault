import type { Catalog, StorageResult, ManagementAction, PluginImports } from "./types";
export declare const desktop: boolean;
export declare function createPluginStorage(bundledCatalog: () => Catalog["plugins"]): {
    getCatalog: () => Promise<StorageResult>;
    changePlugin: (action: ManagementAction, id: string) => Promise<StorageResult>;
    recoverSettings: () => Promise<StorageResult>;
    readModule: (id: string, revision: string) => Promise<string>;
    reloadPlugin: (id: string) => Promise<StorageResult>;
    imports: PluginImports | undefined;
};
export type PluginStorage = Omit<ReturnType<typeof createPluginStorage>, "imports"> & {
    imports?: PluginImports | undefined;
};
