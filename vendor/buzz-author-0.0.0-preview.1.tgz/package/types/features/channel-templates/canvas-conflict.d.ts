import type { OutgoingEvent } from "../relay/outbox";
/** A refused retry cannot prove an earlier uncertain publication never landed. */
export declare function isDefinitiveCanvasConflict(operation: OutgoingEvent | undefined): boolean;
/** A confirmed revision mismatch; refreshing is required before another save. */
export declare class CanvasConflictError extends Error {
    constructor();
}
