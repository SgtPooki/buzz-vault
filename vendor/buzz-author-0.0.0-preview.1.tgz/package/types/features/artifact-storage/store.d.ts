import type { ArtifactCollectionDefinition, HostArtifactCollection } from "./types";
/** Same IndexedDB transaction boundary as the relay journals. No head-cache eviction. */
export declare function createArtifactStore(viewer: string, relay: string): {
    collection: (owner: string, definition: ArtifactCollectionDefinition) => HostArtifactCollection;
    clear(): Promise<void>;
    close(): void;
};
export type ArtifactStore = ReturnType<typeof createArtifactStore>;
export declare function purgeArtifactStorage(viewer: string, relay: string): Promise<void>;
