import { type ChannelDetailsDraft, type ChannelDetails } from "../relay/channel-details-protocol";
import type { ChannelSummary } from "../relay/contracts";
import type { RelaySession } from "../relay/session";
/** Sharing changes access, never presentation or Solo placement. */
export declare function canShareConversation(session: RelaySession, channel?: ChannelSummary): boolean;
export declare const soloChatLink: (id: string) => string;
export declare const soloChatLinkMessage: (id: string, name?: string) => string;
/** Link sharing is available in channels, their threads and DMs. */
export declare function chatShareDestination(destination: Pick<ChannelSummary, "channelType"> | undefined): boolean;
/** Check the destination before opening community reading; never enroll its members. */
export declare function checkShareDestination(session: RelaySession, id: string, signal: AbortSignal): Promise<void>;
/** Both share entry points confirm Private and View only chats. Public stays intact.
 * Return the signed snapshot for consent; confirmed Private writes use the existing
 * details owner and retain its exact uncertain attempt for explicit checking. */
export declare function shareSoloChatAccess(session: RelaySession, id: string, { signal, confirmed, attempts, check, onAccessChanged, }: {
    signal: AbortSignal;
    confirmed?: ChannelDetails | undefined;
    attempts: Map<string, ChannelDetailsDraft>;
    check?: () => void;
    /** Only after this share's save or exact uncertain attempt is confirmed. */
    onAccessChanged?: () => void;
}): Promise<ChannelDetails | undefined>;
/** Promote in place through the existing signed details owner. A retry checks an
 * uncertain save; it never republishes it or resets an unchanged cleanup deadline. */
export declare function applySharedChannelDetails(session: RelaySession, id: string, draft: ChannelDetailsDraft, expected: ChannelDetailsDraft, signal: AbortSignal): Promise<void>;
