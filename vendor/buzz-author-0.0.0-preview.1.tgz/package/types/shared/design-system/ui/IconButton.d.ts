import type { ComponentProps, ReactElement } from "react";
import { Button, type ButtonProps } from "./Button";
type IconButtonVariant = NonNullable<ButtonProps["variant"]> | "destructive-quiet" | "solid" | "inset" | "tint" | "chrome" | "avatar" | "media" | "bare";
type IconButtonSize = NonNullable<ButtonProps["size"]> | "xs" | "toolbar" | "large";
type IconButtonShape = "inset" | "control" | "round" | "row-end" | "squircle";
export type IconButtonProps = Omit<ComponentProps<typeof Button>, "children" | "size" | "variant" | "shape"> & {
    "aria-label": string;
    icon: ReactElement;
    variant?: IconButtonVariant;
    size?: IconButtonSize;
    shape?: IconButtonShape;
};
export declare function IconButton({ icon, variant, size, shape, ...props }: IconButtonProps): import("react").JSX.Element;
export {};
