import type { VerifiedEvent } from "nostr-tools";
/** False means proven non-delivery, not merely a negative or missing OK.
 * `refusal` is the log-safe summary; `reason` is the relay's own bounded text
 * for a proven refusal, for the client only and never for logs. */
export declare class SocketRequestError extends Error {
    readonly sent: boolean;
    readonly refusal?: string | undefined;
    readonly reason?: string | undefined;
    constructor(message: string, sent: boolean, refusal?: string | undefined, reason?: string | undefined);
}
type Publication = {
    event: VerifiedEvent;
    sent: boolean;
    finish(receipt?: string, error?: Error): void;
};
/** Correlation only. The live owner supplies auth, socket, cooldown and recovery;
 * the existing outbox owns retry. Never replay publications on reconnect. */
export declare function createSocketPublications(wake: () => void): {
    publish(input: VerifiedEvent, signal: AbortSignal): Promise<string>;
    next(): Publication | undefined;
    dispatch(job: Publication, send: (frame: unknown[]) => void): void;
    receive(data: unknown[]): boolean;
    clear(): void;
};
export {};
