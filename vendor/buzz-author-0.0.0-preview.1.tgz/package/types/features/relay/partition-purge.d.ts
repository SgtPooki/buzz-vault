/** Clears the relay's durable stores for one partition, each through the
 * caller's `attempt` so an unavailable store neither keeps the others nor goes
 * unreported. The databases stay separate; only this entrypoint is shared. */
export declare function purgeRelayPartition(origin: string, viewer: string, attempt: (store: string, work: () => Promise<void>) => Promise<void>): Promise<void>;
