import type { Context } from "@deepseek-ai/cordis";
/** Trusted routing supplied by the harness adapter, never by hook input. */
export type AgentHookContext = Readonly<{
    agent: string;
    session: string;
}>;
/** Event names, input and output formats belong to the selected agent type. */
export type AgentHook = Readonly<{
    id: string;
    harness: string;
    event: string;
    run(input: unknown, context: AgentHookContext): unknown | Promise<unknown>;
}>;
export declare function createAgentHooks(root: Context): {
    register(ctx: Context, hook: AgentHook): void;
    validate(types: readonly {
        key: string;
        hooks?: Readonly<{
            events: readonly string[];
        }>;
    }[]): void;
    /** Adapters compose results in their own native format. Look up handlers on
     * every event so enabling or removing a plugin needs no process restart. */
    handlers(harness: string, event: string): Readonly<Readonly<{
        id: string;
        harness: string;
        event: string;
        run(input: unknown, context: AgentHookContext): unknown | Promise<unknown>;
    }> & {
        key: string;
        pluginId: string;
        revision: string;
    }>[];
};
export type AgentHookDispatchOptions = Readonly<{
    accepts(output: unknown): boolean;
    milliseconds: number;
    /** Label native output using the registered owner, independently of payload. */
    compose?(output: unknown, pluginId: string): unknown;
}>;
/** Adapters supply native response acceptance and an event-wide time budget. */
export declare function dispatchAgentHooks(hooks: readonly (AgentHook & {
    pluginId: string;
})[], input: unknown, context: AgentHookContext, accepts: (output: unknown) => boolean, milliseconds: number, compose?: AgentHookDispatchOptions["compose"]): Promise<unknown>;
