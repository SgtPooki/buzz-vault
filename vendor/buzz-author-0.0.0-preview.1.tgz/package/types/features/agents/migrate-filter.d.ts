import type { AgentStore } from "./state";
/** Upgrades a stored event watch that still has the old `filter` field to the
 * `authors`, `exclude_authors` and `is_reply` fields, as the relay spec's
 * export does. One way: the result has no `filter`. Other values come back
 * unchanged. Throws a message when the filter cannot be converted.
 *
 * An `author ==` test matched a watched event's lowercase hex key exactly. A
 * value that is not lowercase hex, or is the agent's own key (its own events
 * never reach a watch), never matched, so it is dropped. If that leaves an
 * `authors` test with no key, the watch could never fire, which the fields
 * cannot express, so the filter stays. */
export declare function upgradeWatch(value: unknown, agent: string): unknown;
/** Converts every stored watch filter in place, in the legacy shared record
 * and in each agent's own record. A filter that cannot be converted stays as
 * it is: the reader then skips that watch and shows it for repair. A failure
 * must not stop startup, so each failed save is only logged. */
export declare function migrateWatchFilters(storage: AgentStore): Promise<void>;
