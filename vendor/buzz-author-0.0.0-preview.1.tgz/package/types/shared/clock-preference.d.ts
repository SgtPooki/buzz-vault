export type HourCycle = "h12" | "h23";
export type ClockPreference = {
    hourCycle: "system" | HourCycle;
    seconds: boolean;
    messageTimestamps: "show" | "hide-solo" | "hide";
};
/** Device-local clock settings. */
export declare function clockPreference(): ClockPreference;
/** The hour cycle to format with; undefined follows the locale. */
export declare function clockHourCycle(): HourCycle | undefined;
/** Re-renders the caller when a clock setting or the system's 24-hour setting
 * changes, so times from `shared/datetime` stay current; the system setting is
 * re-read when the window regains focus. */
export declare function useClockFormat(): void;
/** The clock settings, re-rendering the caller as `useClockFormat` does. */
export declare function useClockPreference(): {
    hourCycle: "system" | HourCycle;
    seconds: boolean;
    messageTimestamps: "show" | "hide-solo" | "hide";
    unsaved: boolean;
};
export declare function setClockPreference(change: Partial<ClockPreference>): void;
