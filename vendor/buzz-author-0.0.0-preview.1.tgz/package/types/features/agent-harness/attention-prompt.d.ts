import type { ClassifierOutcome } from "../agents/service";
import type { EventData } from "../relay/events";
/** Janet's end-of-turn review, added to every turn of an agent with attention. */
export declare const ATTENTION_REVIEW: string;
/** The end-of-turn note for an agent with attention and no Interests. */
export declare const ATTENTION_NONE: string;
/** Said at the end of every turn while attention is off on this device. */
export declare const ATTENTION_OFF: string;
/** A timer's turn: no event, just what it is for. */
export declare function timerPrompt(input: Readonly<{
    id: string;
    interest: string;
    prompt: string;
    instructions?: string;
    /** This is its last allowed occurrence. */
    spent: boolean;
    conversation?: boolean;
}>): string;
/** A watch's turn: Janet's watch framing, the Interest, whether a classifier
 * ran, then the observed event as data. */
export declare function watchPrompt(input: Readonly<{
    id: string;
    interest: string;
    instructions?: string;
    conversation?: boolean;
    event: EventData & {
        sig?: string;
    };
    /** Set when the watch has a classifier: its answers, or why it did not
     * run or failed. */
    classifier?: ClassifierOutcome;
}>): string;
/** A catch-up's turn: the watch's messages missed while the agent was
 * offline, oldest first, framed as a watch turn's one message is. */
export declare function catchUpPrompt(input: Readonly<{
    id: string;
    interest: string;
    instructions?: string;
    events: readonly Readonly<{
        event: EventData & {
            sig?: string;
        };
        classifier?: ClassifierOutcome;
    }>[];
    /** Older missed messages were skipped. */
    skipped: boolean;
    conversation?: boolean;
}>): string;
/** Most characters of one catch-up message's text a turn shows. A turn's
 * batch is bounded, but one longer message still goes alone: its text is
 * cut here so the turn stays far inside the model's context. */
export declare const CATCH_UP_TEXT_LIMIT: number;
/** Deterministic producer output is data, with the task supplied separately. */
export declare function sourcePrompt(input: Readonly<{
    id: string;
    provider: string;
    text: string;
    classifier?: ClassifierOutcome;
    interest: string;
    instructions?: string;
    conversation?: boolean;
}>): string;
