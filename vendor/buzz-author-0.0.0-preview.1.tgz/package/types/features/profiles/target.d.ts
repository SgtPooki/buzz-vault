import { type HistorySelection } from "../agents/history-presentation";
/** Public identity locator, not a relay hint or an authority claim. */
export declare function profileTarget(pubkey: string, hint?: {
    agent: boolean;
}): string | undefined;
/** App-local avatar presentation only; never evidence of ownership or control. */
export declare function profileAgentHint(target: string): boolean;
export declare function profilePanelKey(target: string): string | undefined;
/** Public message/composer input must never supply an app-local avatar hint. */
export declare function profileKey(target: string): string | undefined;
/** App-local Activity destination, never a public identity or authority
 * claim. An agent has one, so its Activity tab is reused however it opens; an
 * opener that knows the conversation asks for its transcript with
 * `openProfileTranscript`. */
export declare function profileActivityViewTarget(pubkey: string): string | undefined;
export declare function profileActivityViewKey(target: string): string | undefined;
export declare function subscribeProfileTranscripts(listener: () => void): () => undefined;
/** Opens an Activity `target` through `open`, asking the profile it opens
 * to show its conversation's transcript once. A target that is only shown
 * again, as when its retained tab remounts on returning to the channel, asks
 * for nothing. */
export declare function openProfileTranscript(target: string, open: (target: string) => boolean): boolean;
/** The opening still asking `target`'s profile for its transcript. */
export declare function profileTranscriptRequest(target: string): number | undefined;
/** Takes `target`'s opening for the profile now showing it, so a profile
 * mounted later, as on returning to the channel, finds nothing to act on. */
export declare function claimProfileTranscript(target: string): number | undefined;
/** A config version inspector within the existing owned-agent profile. */
export declare function profileHistoryRoute(target: string): Readonly<{
    side: "settings" | "instructions";
    id: string;
}> | undefined;
export declare function profileHistoryTarget(target: string, selected?: HistorySelection): string;
export declare function profileHistoryActive(target: string): boolean;
/** A profile's version addresses share its opening; unknown fragments stay exact. */
export declare function profileHistoryBase(target: string): string;
