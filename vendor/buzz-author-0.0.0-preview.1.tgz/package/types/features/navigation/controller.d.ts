import { type OpenTarget } from "./targets";
import type { DismissedVisits, NavigationEntry, NavigationHistory } from "./history";
/**
 * Shared abort reason. A reason-less abort() makes Blink mint a DOMException per
 * call, and V8 keeps its unformatted stack alive: that stack holds the start()
 * scope (so the next attempt) and the click dispatch (so the unmounted DOM).
 * One instance captures no per-abort stack, so its .stack points at module
 * evaluation, not the aborting site: do not use it for diagnostics.
 */
export declare const NAVIGATION_ABORTED: DOMException;
export type OpenFailure = "invalid-target" | "unavailable" | "denied" | "not-found" | "timeout" | "host-error";
export type OpenResult = Readonly<{
    status: "opened";
} | {
    status: "cancelled" | "superseded";
} | {
    status: "failed";
    reason: OpenFailure;
    /** The page shows this failure in place, next to what failed; the host
     * keeps the page on screen instead of replacing it. */
    presented?: true;
    /** Reopen this visit once, while it is still the one shown: called
     * with that reopen, returns its cancel (see reauthorizedOnce). */
    reauthorize?: (reopen: () => void) => () => void;
}>;
/** Focus is per opening, never part of a saved address or history entry. */
export type NavigationFocus = "content" | "preserve";
export type NavigationOpenOptions = {
    replace?: boolean;
    /** @deprecated For explicit Close use Navigation.dismiss, which retires visits.
     * Legacy return/replace behavior: this option does not retire restoration visits.
     * Return to the visit behind this one when it matches, otherwise replace it.
     * When the host traverses asynchronously, the return lands after open()
     * resolves, so the resolved result describes the visit being left. */
    dismiss?: boolean;
    focus?: NavigationFocus;
};
export type OpenAttempt = Readonly<{
    id: string;
    entry: NavigationEntry;
    signal: AbortSignal;
    focus?: NavigationFocus;
    /** History traversal returned to a visit it already held; not opened again. */
    traversal?: true;
}>;
export type NavigationSnapshot = Readonly<{
    entry: NavigationEntry;
    attempt: OpenAttempt;
    status: "opening" | OpenResult["status"];
    reason?: OpenFailure;
    /** The failed page presents its own failure in place. */
    presented?: true;
    /** An incoming URL failed before it could create a history destination. */
    ingress?: boolean;
    retryable?: boolean;
    retainedVisits?: readonly string[] | undefined;
    canGoBack: boolean;
    canGoForward: boolean;
}>;
export type Navigation = Readonly<{
    snapshot(): NavigationSnapshot;
    subscribe(listener: () => void): () => void;
    open(target: OpenTarget, options?: NavigationOpenOptions): Promise<OpenResult>;
    back(): void;
    forward(): void;
    /** Explicit dismissal retires content visits; passive traversal retains them. */
    dismiss(visits: DismissedVisits, fallback: OpenTarget): void;
    retry(): Promise<OpenResult>;
}>;
/** The host alone receives completion/cancellation authority. Plugins get Navigation. */
export declare function createNavigationController(history: NavigationHistory, timeoutMs?: number): {
    navigation: Readonly<{
        snapshot(): NavigationSnapshot;
        subscribe(listener: () => void): () => void;
        open(target: OpenTarget, options?: NavigationOpenOptions): Promise<OpenResult>;
        back(): void;
        forward(): void;
        /** Explicit dismissal retires content visits; passive traversal retains them. */
        dismiss(visits: DismissedVisits, fallback: OpenTarget): void;
        retry(): Promise<OpenResult>;
    }>;
    /** Shell-owned draft guard; native traversal bounces before presentation unmounts. */
    guardDeparture(guard: NonNullable<((next: OpenTarget, decide: (proceed: boolean) => void) => boolean) | undefined>): () => void;
    /**
     * Host-only: a presenter now exists. The pending visit's deadline starts (or
     * restarts) here and stops when the last presenter detaches, so an attempt
     * nobody could present never times out, while one a presenter stalls on does.
     */
    attach(): () => void;
    /** Normalize a pending presentation, not a new intent; never reset its deadline. */
    resolve(attempt: OpenAttempt, input: OpenTarget): boolean;
    /** Acknowledge only the exact active attempt after actual presentation. */
    complete(attempt: OpenAttempt, result: Extract<OpenResult, {
        status: "opened" | "failed";
    }>): boolean;
    /** While registered, the page presenting visit `entryId` reports through
     * `passes` whether it holds anything to come back to. When it holds
     * nothing, the next page opened from it replaces it in history. */
    passThrough(entryId: string, passes: () => boolean): () => void;
    /** Host-only traversal to a retained visit; does not retire dismissed content. */
    returnTo(entryId: string): boolean;
    cancel(): void;
    /** Keep pre-navigation recovery separate from the previous history visit. */
    fail(reason: OpenFailure, retry?: () => Promise<OpenResult>): void;
    dispose(): void;
};
