import type { AttachmentRenderer, ContributionReader } from "../conversation/contracts";
import type { DraftAttachment } from "./attachment-draft";
/** A GIF staged with the draft. It sends as its Markdown, not as an upload. */
export type ComposerGif = Readonly<{
    markdown: string;
    title: string;
    source?: string | undefined;
}>;
export declare function ComposerAttachments({ items, gifs, removeGif, renderers, disabled, remove, retry, media, onExitComplete, }: {
    renderers?: ContributionReader<AttachmentRenderer> | undefined;
    media(url: string): string | undefined;
    items: readonly DraftAttachment[];
    gifs?: readonly ComposerGif[] | undefined;
    removeGif?(markdown: string): void;
    disabled: boolean;
    remove(id: string): void;
    retry(id: string): void;
    /** The section finished animating out after the last item was removed. */
    onExitComplete?: (() => void) | undefined;
}): import("react").JSX.Element;
