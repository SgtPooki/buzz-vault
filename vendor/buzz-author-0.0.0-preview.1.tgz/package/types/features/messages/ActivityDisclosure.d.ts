import { type ReactNode, type RefObject, type Ref } from "react";
/** The conversation's existing activity disclosure, shared by history and outcomes. */
export declare function ActivityDisclosure({ expanded, onToggle, label, summary, icon, children, actions, trigger, container, interactive, expandedSummary, }: {
    expanded: boolean;
    onToggle: () => void;
    label: string;
    summary: ReactNode;
    icon?: ReactNode;
    children?: ReactNode;
    actions?: ReactNode;
    trigger?: RefObject<HTMLButtonElement | null> | undefined;
    container?: Ref<HTMLDivElement> | undefined;
    interactive?: boolean;
    expandedSummary?: ReactNode;
}): import("react").JSX.Element;
