import type { ReactNode } from "react";
/** A content card for empty, setup, and status views. Actions and state stay caller-owned. */
export declare function EmptyState({ icon, title, description, action, level, frame, }: {
    icon: ReactNode;
    title: string;
    description?: ReactNode;
    action?: ReactNode;
    level?: 3 | 4;
    /** `none` drops the card border inside a surface that already frames it, such as a popover. */
    frame?: "card" | "none";
}): import("react").JSX.Element;
