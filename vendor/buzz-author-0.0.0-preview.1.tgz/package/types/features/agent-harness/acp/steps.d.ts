/** A `session/update` as the step it shows: a tool call by its title and
 * target, thinking, or writing. */
export declare function stepLabel(update: Record<string, unknown>): {
    tool: string;
    target?: string;
} | undefined;
/** The option that allows the call, preferring one that keeps allowing. */
export declare function allow(params: Record<string, unknown>): {
    outcome: string;
    optionId: string;
} | {
    optionId?: never;
    outcome: string;
};
/** The JSON-RPC code of a harness's error answer, when `error` is one. */
export declare function codeOf(error: unknown): number | undefined;
export declare function errorMessage(error: unknown): string;
