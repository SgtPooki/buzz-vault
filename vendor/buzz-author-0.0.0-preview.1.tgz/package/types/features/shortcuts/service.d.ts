import { Service, type Context } from "@deepseek-ai/cordis";
import { type Contribution } from "../../plugins/contributions";
import { type KeyBinding, type NormalizedShortcut, type Shortcut } from "./bindings";
export type { KeyBinding, NormalizedShortcut, Shortcut } from "./bindings";
export type RegisteredShortcut = Contribution<NormalizedShortcut>;
export type Shortcuts = {
    register(shortcut: Shortcut): void;
    snapshot(): readonly RegisteredShortcut[];
    subscribe(listener: () => void): () => void;
};
/** Device-local user rebinds, keyed by host id or namespaced contribution key. */
export type BindingOverrides = {
    /** A stored override is a nonempty alias list; anything else means the default. */
    resolve(key: string): readonly KeyBinding[] | undefined;
};
declare module "@deepseek-ai/cordis" {
    interface Context {
        shortcuts: Shortcuts;
    }
}
export declare class ShortcutsService extends Service implements Shortcuts {
    private readonly contributions;
    private readonly hostBindings;
    private readonly hostListeners;
    private hostReady;
    constructor(ctx: Context, host?: Window | undefined, overrides?: BindingOverrides);
    /** Host composition only: runs a host shortcut if it is eligible now. */
    readonly runHost: (id: string) => boolean;
    snapshot: () => readonly Readonly<Readonly<{
        id: string;
        title: string;
        binding: KeyBinding | readonly KeyBinding[];
        run: () => void | Promise<void>;
        when?: () => boolean;
        allowInEditable?: boolean;
        allowInModal?: boolean;
        allowInVisit?: boolean;
        repeat?: boolean;
        order?: number;
    }> & Readonly<{
        binding: readonly KeyBinding[];
        order: number;
    }> & {
        key: string;
        pluginId: string;
        revision: string;
    }>[];
    subscribe: (listener: () => void) => () => void;
    register(shortcut: Shortcut): void;
    /** Host composition only; not part of the injected plugin contract. */
    registerHost(shortcut: Shortcut): () => void;
    /** Host-only read path for Settings; plugins keep seeing only contributions. */
    hostSnapshot: () => readonly NormalizedShortcut[];
    hostSubscribe: (listener: () => void) => () => void;
    private publishHost;
}
