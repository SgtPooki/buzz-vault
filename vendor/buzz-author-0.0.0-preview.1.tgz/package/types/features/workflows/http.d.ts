import type { WorkflowHost } from "./host.ts";
export declare const WORKFLOW_READ_BYTES: number;
/** Only the fixed run-history route; input cannot choose an upstream URL or size. */
export declare function workflowRunsPath(body: unknown): string;
/** Stream-bound before parsing. Never include upstream text in an error/log. */
export declare function workflowReadText(response: Response): Promise<string>;
/** Adapters supply authentication/admission; the capability validates domain rows. */
export declare function workflowHost(request: (route: string, body: unknown, signal: AbortSignal) => Promise<Response>): WorkflowHost;
