import { type ReactNode } from "react";
import { type TabAction } from "../../shared/design-system/ui/Tabs";
import type { TabDragHost } from "./useTabDrag";
type Item = {
    id: string;
    label: string;
    icon?: ReactNode;
    content: ReactNode;
    /** Increment when an opening returns to this existing tab. */
    attentionRequest?: number | undefined;
    /** Stable for one opening, including retained exit content. */
    instance?: object;
    /** Omit for a permanent tab such as a channel's own conversation. Returns
     * false when it keeps the tab, as when asking about unsaved edits first. */
    close?: (() => boolean | void) | undefined;
    /** Keyboard placement: one position left or right, across panes at an edge. */
    move?: ((delta: -1 | 1) => void) | undefined;
    /** A blank name restores the tab's own title. */
    rename?: ((name: string) => void) | undefined;
    actions?: readonly TabAction[] | undefined;
    /** Header icon actions for this tab's content, shown while it is selected. */
    toolbar?: ReactNode;
};
type Identity = {
    label: string;
    icon?: ReactNode;
};
/** `keepOwner`: the owner stays open; only its detail tabs are cleared. */
type Close = (options?: {
    keepOwner?: boolean;
}) => void;
type Local = {
    id: string;
    label: string;
    owner: string;
    close: Close;
};
export declare function usePanelTabHost(): {
    owner: string;
    register(tab: Local): () => void;
    activate(owner: string, label: string): boolean;
    title(owner: string, identity: Identity | undefined): void;
    slots: ReadonlyMap<string, HTMLDivElement>;
} | null;
export declare function usePanelTabTitle(label: string, icon?: ReactNode): void;
/** The channel owns target tabs; private details retain their feature's lifetime. */
export declare function PanelWorkspace({ items, value, select, actions, identity, main, label, focusOnMount, adoptSelection, tabMenu, drag, }: {
    /** The channel owner closes tabs across both panes, including hidden tabs. */
    tabMenu?: {
        key: string;
        closeAll(): boolean;
        closeOthers?: ((id: string) => boolean) | undefined;
    } | undefined;
    drag?: TabDragHost | undefined;
    items: Item[];
    value: string;
    select(id: string): void;
    /** Header icon actions owned by the hosting page. */
    actions?: ReactNode;
    /** Interactive conversation identity; a lone permanent tab needs no tab strip. */
    identity?: ReactNode;
    /**
     * The page's main pane: a lone permanent tab reads as a title, and native
     * Close acts here only while focus is inside (the side pane is the default).
     */
    main?: boolean;
    label?: string;
    /** Restoring a channel visit leaves focus with its main conversation. */
    focusOnMount?: boolean;
    /** A new value adopts the current selection without moving focus. */
    adoptSelection?: unknown;
}): import("react").JSX.Element;
export declare function PanelLocalTab({ title, close, children, }: {
    title: string;
    close: Close;
    children: ReactNode;
}): import("react").ReactPortal | null;
export {};
