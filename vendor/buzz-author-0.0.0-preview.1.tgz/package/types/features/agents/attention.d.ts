import type { EventData } from "../relay/events";
export declare const ATTENTION_SCHEMA = "agent-attention/v1";
export type Interest = Readonly<{
    type: "interest";
    /** What the owner sees as the Interest's name. */
    title?: string;
    /** One or two sentences under the title on the owner's card. */
    summary?: string;
    instructions: string;
    paused?: boolean;
}>;
export type ClassifierQuestion = Readonly<{
    question: string;
    true?: string;
    false?: string;
    guidance?: string;
    /** The yes probability at which the answer passes; CLASSIFIER_THRESHOLD
     * when absent. */
    threshold?: number;
}>;
/** Janet's default: a lower threshold passes more events. */
export declare const CLASSIFIER_THRESHOLD = 0.2;
export type EventWatch = Readonly<{
    type: "event";
    interest_id: string;
    name?: string;
    enabled: boolean;
    since: number;
    channel?: string;
    root?: string;
    channels: "all" | readonly string[];
    kinds: readonly number[];
    /** The event's author must be one of these. Not with `exclude_authors`. */
    authors?: readonly string[];
    /** The event's author must not be one of these. */
    exclude_authors?: readonly string[];
    tags?: Readonly<Record<string, readonly string[]>>;
    /** true: replies only; false: top-level only (NIP-10 `reply` marker). */
    is_reply?: boolean;
    classifier?: Readonly<{
        questions: Readonly<Record<string, ClassifierQuestion>>;
    }>;
}>;
export type TimerWatch = Readonly<{
    type: "timer";
    interest_id: string;
    prompt: string;
    enabled: boolean;
    interval_secs: number;
    armed_at: number;
    max_occurrences: number | null;
    expires_at: number | null;
    channel?: string;
    root?: string;
}>;
/** A plugin-owned deterministic producer. Attention owns its registration and destination. */
export type SourceWatch = Readonly<{
    type: "source";
    interest_id: string;
    enabled: boolean;
    name?: string;
    provider: string;
    config: Readonly<Record<string, unknown>>;
    classifier?: EventWatch["classifier"];
    channel?: string;
    root?: string;
}>;
export type AttentionValue = Interest | EventWatch | TimerWatch | SourceWatch;
export type AttentionObject = Readonly<{
    slug: string;
    value: AttentionValue;
    /** Unix seconds; on the relay this is the event's `created_at`. */
    modifiedAt: number;
}>;
/** At most this many Interests, and this many watches and timers together. */
export declare const OBJECT_LIMIT = 100;
export declare function parseSlug(slug: string): {
    space: "interest" | "watch";
    id: string;
} | undefined;
export declare const interestSlug: (id: string) => string;
export declare const watchSlug: (id: string) => string;
/** Checks one object on its own, as a reader does. Returns a message, or nothing. */
export declare function validateObject(slug: string, value: unknown): string | undefined;
/** Kinds that are conversation: only these p-tag an agent into a conversation,
 * and only these start a mention run. A reaction to or deletion of the agent's
 * message is addressed (no watch sees it) but is not someone talking to it. */
export declare const CHAT_KINDS: readonly number[];
/** Directly addressed events take the runtime's built-in mention path, never a
 * watch: an encrypted DM (kind 4) to the agent, or a chat event that p-tags it.
 * A chat reply that does not mention it, even in its own thread, is not
 * addressed, and neither is a reaction to or deletion of its message: only a
 * watch can wake it for one.
 * Its own events are the caller's to skip. */
export declare function addressedTo(event: EventData, agent: string): boolean;
export declare const tagsAgent: (event: EventData, agent: string) => boolean;
/** Steps 1, 2 and 4 of event watch matching. Step 3 (addressed events and the
 * agent's own events) belongs to the caller; classifiers are not run here. */
export declare function watchMatches(watch: EventWatch, event: EventData): boolean;
/** Runtime schedule state for one timer. Not config: it never leaves the runner. */
export type TimerState = Readonly<{
    armedAt: number;
    nextDue: number;
    used: number;
}>;
/** The saved state while it still describes this schedule. Without one, every
 * occurrence due by `now` counts as used, so a timer never runs more often than
 * it allows (occurrence k is due at armed_at + k × interval_secs). */
export declare function timerState(timer: TimerWatch, prior: TimerState | undefined, now: number): TimerState;
export declare function timerSpent(timer: TimerWatch, state: TimerState, now: number): boolean;
export type ChannelChoice = Readonly<{
    id: string;
    name: string;
}>;
export type Watch = EventWatch | TimerWatch | SourceWatch;
export type WatchObject = AttentionObject & {
    value: Watch;
};
export declare const UNITS: readonly [readonly ["day", 86400], readonly ["hour", 3600], readonly ["minute", 60], readonly ["second", 1]];
export declare const plural: (count: number, unit: string) => string;
/** The largest whole unit of `seconds`. */
export declare function interval(seconds: number): {
    count: number;
    unit: "day" | "hour" | "minute" | "second";
    size: 1 | 60 | 3600 | 86400;
};
export declare function every(seconds: number): string;
/** `release-triage` reads as "Release triage". */
export declare const interestTitle: (id: string) => string;
/** One line for a watch, for rows and the peek. */
export declare function describeWatch(watch: Watch, channels?: readonly ChannelChoice[]): string;
/** The objects by role, in slug order; `orphans` serve no Interest. */
export declare function attentionOf(attention: Readonly<Record<string, AttentionObject>>): {
    interests: Readonly<{
        slug: string;
        value: AttentionValue;
        /** Unix seconds; on the relay this is the event's `created_at`. */
        modifiedAt: number;
    }>[];
    watches: WatchObject[];
    orphans: WatchObject[];
};
/** Identity of the exact saved registration whose producer finished. */
export declare const sourceSignature: (object: AttentionObject) => string;
export declare function sourceCompleted(runs: Readonly<Record<string, string>> | undefined, object: AttentionObject | undefined): boolean;
/** Interest pause leaves each watch's own enabled setting intact. */
export declare function interestPaused(attention: Readonly<Record<string, AttentionObject>>, id: string): boolean;
