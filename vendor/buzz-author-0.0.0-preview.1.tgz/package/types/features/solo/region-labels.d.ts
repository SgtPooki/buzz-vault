export declare const REGION_PREFIX = "buzz.region:";
export declare const regionLabels: (labels?: readonly string[]) => string[];
/** Invalid external multi-owner edits resolve identically on every device. */
export declare function effectiveRegionLabel(labels?: readonly string[]): string | undefined;
export declare function soloRegionLabel(pluginId: string, sourceId: string): string;
