import type { Profile } from "./contracts";
import { type RelayEvent } from "./events";
import type { RelayReader } from "./reader";
import { type VerifiedProfileAuthority } from "./verified-profile";
/** The relay's `POST /profiles/search` page-size ceiling. */
export declare const PROFILE_SEARCH_MAX = 100;
/** The relay's highest page, the same as its NIP-50 search. */
export declare const PROFILE_SEARCH_PAGES = 1000;
/** The relay's longest accepted trimmed query, in Unicode code points (Rust
 * `chars()`). A longer query goes to NIP-50 search, which has no such limit. */
export declare const PROFILE_SEARCH_QUERY_MAX = 100;
export type ProfileSearchOptions = {
    /** Results per page. */
    limit: number;
    /** 1-based page of `limit` results; NIP-50 gets it only when given. */
    page?: number;
    signal: AbortSignal;
    priority?: "foreground" | "background";
};
/** How long a relay's 404 or 405 keeps searches on NIP-50 before the endpoint
 * is tried again. A relay upgraded while the app runs is used within this time. */
export declare const PROFILE_SEARCH_RETRY_MS: number;
/** How long a search's verified answer stands in for a read: a page names
 * its rows right after it settles. */
export declare const PROFILE_SEARCH_HEADS_MS = 30000;
/** Finds people by profile name. Uses the relay's name-only endpoint, which
 * applies the NIP-50 prefix rule and paging to just `name` and `display_name`.
 * NIP-50 search over kind:0 matches the whole profile JSON, so text in avatar
 * data URLs, `about` or `nip05` can fill its pages and hide a real name match.
 *
 * A relay without the endpoint answers 404 or 405. That search then uses
 * NIP-50, and so do later ones for {@link PROFILE_SEARCH_RETRY_MS}; after that
 * the endpoint is tried again. A relay that loses the endpoint falls back the
 * same way.
 *
 * Both searches go through the given reader, which owns their deadline,
 * cancellation and stale-result checks.
 *
 * Where the authority is `searchable`, the endpoint also returns each found
 * person's current verified head, and none when they have none. Those
 * answers are kept, a page at a time, for {@link verifiedHeads}. A person it
 * found who has no kind:0 is returned as their head, so the result has one
 * event per person; {@link searchedProfiles} reads it. The NIP-50 fallback
 * returns kind:0 only. */
export declare function createProfileSearch(fallback: RelayReader, now?: () => number, authority?: () => VerifiedProfileAuthority | undefined): ((query: string, { limit, page, signal, priority }: ProfileSearchOptions, reader?: RelayReader) => Promise<readonly RelayEvent[]>) & {
    verifiedHeads: (pubkeys: readonly string[], current: VerifiedProfileAuthority) => ReadonlyMap<string, RelayEvent | undefined>;
    answered: (pubkey: string, current: VerifiedProfileAuthority) => boolean;
};
export type ProfileSearch = ReturnType<typeof createProfileSearch>;
/** The people a {@link createProfileSearch} page found, by pubkey: each
 * kind:0 profile, and for a person found only by a verified head that
 * `authority` signed, the nameless profile an empty kind:0 gives. Their
 * verified name comes from that head, which the search keeps for
 * `useVerifiedNames`. Any other event names nobody. */
export declare function searchedProfiles(events: readonly RelayEvent[], authority: VerifiedProfileAuthority | undefined): Map<string, Profile>;
