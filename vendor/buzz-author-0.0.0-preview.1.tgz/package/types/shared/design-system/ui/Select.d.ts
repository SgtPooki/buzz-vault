import { type ReactNode } from "react";
export type SelectGroup = {
    label: string;
    /** Separate this group from the preceding choices. */
    separator?: boolean;
    options: readonly {
        value: string;
        label: string;
        description?: ReactNode;
        /** Decorative 20px icon, avatar, or custom accessory shown before the option's text. */
        leading?: ReactNode;
        disabled?: boolean;
    }[];
};
/** A compact, labelled single-choice control with accessible option groups. */
export declare function Select({ label, value, groups, onValueChange, variant: requestedVariant, disabled, description, error, name, required, readOnly, placeholder, valueLabel, valueTitle, valueSuffix, leading, align, size, appearance, }: {
    label: string;
    description?: ReactNode;
    error?: ReactNode;
    name?: string;
    required?: boolean;
    readOnly?: boolean;
    placeholder?: string;
    /** Compact display text; option labels retain their full meaning. */
    valueLabel?: string | undefined;
    valueTitle?: string;
    /** Compact metadata stays visible while the selected value truncates. */
    valueSuffix?: string | undefined;
    /** Decorative 20px icon, avatar, or custom accessory shown before the selected value. */
    leading?: ReactNode;
    /** Anchor the popup to the corresponding trigger edge. */
    align?: "start" | "center" | "end";
    variant?: "inline" | "field" | "compact" | "preference";
    /** Match adjacent controls without changing the selection treatment. */
    size?: "xs" | "sm" | "md";
    appearance?: "outlined" | "glass-ghost" | "inverted" | "link";
    disabled?: boolean;
    value: string;
    groups: readonly SelectGroup[];
    onValueChange: (value: string) => void;
}): import("react").JSX.Element;
