export declare const TEAM_PAYLOAD_TAG = "buzz-team-payload-v1";
export declare const TEAM_MANIFEST_TAG = "buzz-channel-kit-v2";
export declare const TEAM_PAYLOAD_BYTES: number;
export declare const TEAM_CHUNK_BYTES: number;
export declare const TEAM_CHUNKS: number;
export interface TeamManifest {
    version: 1;
    owner: string;
    revision: string;
    digest: string;
    bytes: number;
    chunks: number;
}
export interface TeamPayload {
    version: 1;
    community: string;
    owner: string;
    teamId: string;
    revision: string;
    index: number;
    data: string;
}
export declare function parseTeamManifest(raw: unknown): TeamManifest;
export declare function parseTeamPayload(raw: unknown, community: string): TeamPayload;
export declare function payloadCoordinate(value: Omit<TeamPayload, "data" | "version">): string;
/** Team instructions travel as ASCII `v1:` plus their raw UTF-8 bytes. */
export declare const TEAM_TEXT_BYTES: number;
export declare function parseTextManifest(raw: unknown): TeamManifest;
