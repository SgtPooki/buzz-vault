import { type PluginStorage } from "./storage";
import { PluginRuntime } from "./runtime";
import type { Context } from "@deepseek-ai/cordis";
import type { PluginManifest, PluginModule } from "./api";
import type { ConfigurationState, ManagementAction, PluginInfo } from "./types";
export declare function canRetryPlugin(plugin: PluginInfo | undefined, activation: ReturnType<PluginRuntime["snapshot"]>[string] | undefined, externalPluginsPaused: boolean): boolean;
export type BundledPlugin = {
    manifest: PluginManifest;
    module: PluginModule;
    enabledByDefault?: boolean;
};
export declare function createPluginManager(ctx: Context, { bundled, builtIn, storage, }: {
    bundled: readonly BundledPlugin[];
    /** Host-owned contributions, independent of optional-plugin storage. */
    builtIn?: readonly BundledPlugin[];
    storage?: PluginStorage | undefined;
}): {
    snapshot: () => {
        configuration: ConfigurationState;
        activation: import("./runtime").PluginStates;
        busy: boolean;
        error: string | null;
        refreshError: string | null;
    };
    startup: () => "loading" | "ready" | "recovery";
    subscribe(listener: () => void): () => void;
    imports: import("./types").PluginImports | undefined;
    installImport: (token: string, path: string) => Promise<boolean>;
    change: (action: ManagementAction, id: string) => Promise<boolean>;
    requests: {
        forAgent: (requester: import("./requests").PluginRequester) => {
            list(): Promise<{
                plugins: {
                    id: string;
                    name: string;
                    enabled: boolean;
                    bundled: boolean;
                    revision: string;
                    source: {
                        kind: "bundled";
                    } | {
                        kind: "git";
                        repository: string;
                        reference: string;
                        commit?: string;
                    } | {
                        kind: "folder";
                    };
                    pendingRequest?: {
                        id: string;
                        action: import("./requests").PluginRequestAction;
                    };
                }[];
            }>;
            disable(id: string): Promise<{
                id: string;
                enabled: false;
            }>;
            discover(repository: string, reference?: string): Promise<{
                commit: string | null;
                candidates: {
                    path: string;
                    id: string;
                    name: string;
                    apiVersion: 1;
                    host?: Readonly<{
                        agentHooks?: readonly string[];
                        agentExecution?: readonly string[];
                        commands?: readonly Readonly<{
                            id: string;
                            program: string;
                            args: readonly string[];
                            maxInputBytes?: number;
                            maxOutputBytes?: number;
                            artifact?: Readonly<{
                                path: string;
                                sha256: string;
                                siblings?: readonly Readonly<{
                                    name: string;
                                    sha256: string;
                                }>[];
                            }>;
                        }>[];
                        networkOrigins?: readonly string[];
                        federatedIdentity?: Readonly<{
                            authority: string;
                            operations: readonly Readonly<{
                                method: "GET" | "HEAD" | "POST" | "PUT" | "PATCH" | "DELETE";
                                path: string;
                            }>[];
                        }>;
                        processes?: readonly Readonly<{
                            id: string;
                            program: string;
                            args?: readonly string[];
                            bundled?: boolean;
                            artifact?: Readonly<{
                                path: string;
                                sha256: string;
                                siblings?: readonly Readonly<{
                                    name: string;
                                    sha256: string;
                                }>[];
                            }>;
                        }>[];
                        mcp?: boolean;
                        files?: boolean;
                        managedFiles?: boolean;
                        publicImages?: boolean;
                    }>;
                    alreadyInstalled: boolean;
                }[];
            }>;
            request(input: import("./requests").PluginRequestInput): Promise<{
                requestId: string;
                applied: false;
                action: import("./requests").PluginRequestAction;
                pluginName: string;
            }>;
            status(requestId: string): {
                state: "expired";
                action?: never;
                pluginId?: never;
            } | {
                state: unknown;
                action: import("./requests").PluginRequestAction;
                pluginId: string;
            };
        };
        conflict: (id: string) => string | undefined;
        pending: () => readonly Readonly<{
            id: string;
            requester: Readonly<{
                pubkey: string;
                name: string;
            }>;
            action: import("./requests").PluginRequestAction;
            pluginId: string;
            pluginName: string;
            source?: Readonly<{
                repository: string;
                reference: string;
                path: string;
                commit: string;
            }>;
            reason: string;
        }>[];
        decided: (id: string) => import("./requests").DecidedPluginRequest | undefined;
        subscribe(listener: () => void): () => void;
        settle(id: string, state: "approved" | "declined"): void;
    };
    reload: (id: string) => Promise<boolean>;
    retryPlugin: (id: string) => boolean;
    retry: () => Promise<boolean>;
    recover: () => Promise<boolean>;
    dismissError: () => void;
    dispose(): Promise<void>;
};
export type PluginManager = ReturnType<typeof createPluginManager>;
