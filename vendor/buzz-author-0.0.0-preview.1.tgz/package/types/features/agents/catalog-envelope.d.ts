/** NIP-AP catalog envelope rules shared by the app and the dev signing broker.
 * Dependency-free so the broker's config can load it natively. */
export declare const AGENT_CATALOG_KIND = 30175;
export declare const TEAM_CATALOG_KIND = 30178;
export declare const MAX_CONTENT_BYTES = 65535;
/** Serialized catalog event or template bound. Content is JSON text, which JSON
 * string escaping at most doubles; the rest covers keys, the bounded tags, id,
 * pubkey and signature. Mirrored by the native signer. */
export declare const MAX_EVENT_BYTES: number;
export declare const isCatalogKind: (kind: unknown) => kind is 30175 | 30178;
export type Body = Record<string, unknown>;
export declare const bytes: (value: string) => number;
export declare function object(content: string): Body | undefined;
/** Signer admission, mirrored by the native validator: exactly one `d`, at most
 * one exact `["shared","true"]` and one `client-id`, and no `env_vars` body. */
export declare function validCatalogEnvelope(event: {
    kind?: unknown;
    content?: unknown;
    tags?: unknown;
    created_at?: unknown;
}): boolean;
