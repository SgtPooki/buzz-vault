import { type Ref, type ReactNode } from "react";
import type { Effort } from "../../agents/service";
export declare function EffortSlider({ avatarSrc, name, chatScoped, model, efforts, resting, value, disabled, pick, thumb, }: {
    name: string;
    chatScoped?: boolean;
    avatarSrc: string | undefined;
    model(level?: string): ReactNode;
    efforts: readonly Effort[];
    /** The effort the run uses without a pick, when known. */
    resting: string | undefined;
    value: string | undefined;
    disabled: boolean;
    pick(effort: string | undefined): void;
    thumb?: Ref<HTMLInputElement>;
}): import("react").JSX.Element;
