import { type RelayRecovery } from "./recovery";
import type { RelaySession } from "./session";
/** Recovery state for one surface. `shown` is true while the notice is
 * visible; `recovering` is true from the first failure, including the
 * quiet RECOVERY_NOTICE_DELAY_MS before the notice appears. */
export declare function useRecovery(recovery: RelayRecovery | undefined): {
    recovering: boolean;
    shown: boolean;
};
/** Retries a finite read that recovery does not own once credentials change
 * (federated sign-in). Call `begin()` as each read starts and pass its failure
 * to the function it returns. Only a missing-sign-in refusal of a read sent
 * before the change retries, once; any other failure, or a read begun after
 * the change, stays put. Reads only: never a mutation or a user's action. */
export declare function useReauthorizedRetry(recovery: RelayRecovery | undefined, retry: () => void): {
    begin(): (error: unknown) => void;
};
/** True while recovery retries this surface's own read, from its first
 * failure and through the quiet delay before the notice. The surface then
 * hides its own copy of the failure; the notice is the one report. `owns`
 * picks the read from the live view (rosterRecovering, headRecovering). A
 * failure recovery does not retry, such as a denial, stays visible even while
 * another source recovers. */
export declare function useRecoveryOwns(session: Pick<RelaySession, "recovery" | "live">, owns: (live: ReturnType<RelaySession["live"]["snapshot"]>) => boolean): boolean;
export declare const RECOVERY_TITLE = "Buzz is having trouble connecting";
/** The one relay recovery notice, on every page. Recovery retries on its own,
 * so it offers no button. */
export declare function RecoveryNotice({ recovery, }: {
    recovery: RelayRecovery | undefined;
}): import("react").JSX.Element | null;
