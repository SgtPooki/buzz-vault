import type { Context } from "@deepseek-ai/cordis";
import { type Navigation, type OpenAttempt, type OpenResult, type NavigationFocus } from "./controller";
import { type JsonValue, type OpenTarget } from "./targets";
import type { RelayData, RelaySnapshot } from "../relay/service";
export type PageNavigation = Readonly<{
    entryId: string;
    target: OpenTarget;
    signal: AbortSignal;
    /** Suppress destination autofocus when the opening control retains focus. */
    focus?: NavigationFocus;
    /** Back/Forward returned to this visit. A consumer that kept its state may
     * restore it rather than replay the visit's opening. */
    traversal?: true;
    /** This visit's state under a consumer's key, kept for Back/Forward until
     * the shared store evicts it. */
    position(key: string): JsonValue | undefined;
    /** Usable after this presentation is revoked, so leaving can record it.
     * Every visit and consumer shares one store that keeps the latest 100
     * entries, so use few keys and small values: never drafts, message bodies,
     * credentials or authorization. */
    savePosition(key: string, value: JsonValue): void;
    /** Bind a domain subtree to the exact connection it renders, without another visit. */
    forSession(relay: RelayData, connection: RelaySnapshot): PageNavigation;
    /** Resolve the pending visit's default destination without replacing its caller. */
    resolve(target: OpenTarget): boolean;
    /** While registered, `passes` says whether this visit holds nothing to come
     * back to; then the next page opened from it takes its place in history.
     * Returns the unregister function. */
    passThrough(passes: () => boolean): () => void;
    complete(result: Extract<OpenResult, {
        status: "opened" | "failed";
    }>): boolean;
}>;
declare module "@deepseek-ai/cordis" {
    interface Context {
        navigation: Navigation;
    }
}
export declare function provideNavigation(ctx: Context, host?: (Window & typeof globalThis) | undefined): {
    navigation: Readonly<{
        snapshot(): import("./controller").NavigationSnapshot;
        subscribe(listener: () => void): () => void;
        open(target: OpenTarget, options?: import("./controller").NavigationOpenOptions): Promise<OpenResult>;
        back(): void;
        forward(): void;
        dismiss(visits: import("./history").DismissedVisits, fallback: OpenTarget): void;
        retry(): Promise<OpenResult>;
    }>;
    guardDeparture(guard: NonNullable<((next: OpenTarget, decide: (proceed: boolean) => void) => boolean) | undefined>): () => void;
    attach(): () => void;
    resolve(attempt: OpenAttempt, input: OpenTarget): boolean;
    complete(attempt: OpenAttempt, result: Extract<OpenResult, {
        status: "opened" | "failed";
    }>): boolean;
    passThrough(entryId: string, passes: () => boolean): () => void;
    returnTo(entryId: string): boolean;
    cancel(): void;
    fail(reason: import("./controller").OpenFailure, retry?: () => Promise<OpenResult>): void;
    dispose(): void;
    position: (id: string) => JsonValue | undefined;
    savePosition: (id: string, value: JsonValue) => void;
    request(attempt: OpenAttempt, owner: PresentationOwner, retainUnderSettings?: boolean): {
        /** Resume only the original visit; retained content cannot acknowledge Settings. */
        resume(next: OpenAttempt): boolean;
        request: Readonly<{
            entryId: string;
            target: OpenTarget;
            signal: AbortSignal;
            /** Suppress destination autofocus when the opening control retains focus. */
            focus?: NavigationFocus;
            /** Back/Forward returned to this visit. A consumer that kept its state may
             * restore it rather than replay the visit's opening. */
            traversal?: true;
            /** This visit's state under a consumer's key, kept for Back/Forward until
             * the shared store evicts it. */
            position(key: string): JsonValue | undefined;
            /** Usable after this presentation is revoked, so leaving can record it.
             * Every visit and consumer shares one store that keeps the latest 100
             * entries, so use few keys and small values: never drafts, message bodies,
             * credentials or authorization. */
            savePosition(key: string, value: JsonValue): void;
            /** Bind a domain subtree to the exact connection it renders, without another visit. */
            forSession(relay: RelayData, connection: RelaySnapshot): PageNavigation;
            /** Resolve the pending visit's default destination without replacing its caller. */
            resolve(target: OpenTarget): boolean;
            /** While registered, `passes` says whether this visit holds nothing to come
             * back to; then the next page opened from it takes its place in history.
             * Returns the unregister function. */
            passThrough(passes: () => boolean): () => void;
            complete(result: Extract<OpenResult, {
                status: "opened" | "failed";
            }>): boolean;
        }>;
        dispose: () => void;
    };
};
/** Presentation authority is narrower than the pending visit's lifetime. */
export type PresentationOwner = {
    valid(): boolean;
    subscribe(listener: () => void): () => void;
};
