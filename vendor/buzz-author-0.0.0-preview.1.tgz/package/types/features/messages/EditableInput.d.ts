import { type ReactNode, type RefObject, type HTMLAttributes } from "react";
import { type MentionDraft, type MentionRecipient } from "./mention-draft";
import { type ComposerFormat, type ComposerLinkEdit, type ComposerInputElement } from "./composer-dom";
import "prosemirror-view/style/prosemirror.css";
export type EditorDecoration = {
    start: number;
    end: number;
    content: ReactNode;
    editAsText?: boolean;
};
export type EditableInputProps = Omit<HTMLAttributes<ComposerInputElement>, "onChange" | "onInput"> & {
    ref: RefObject<ComposerInputElement | null>;
    value: string;
    disabled: boolean;
    placeholder: string;
    maxLength: number;
    onDraftChange(draft: MentionDraft): void;
    onFormatsChange(active: readonly ComposerFormat[]): void;
    onEditLink?(edit: ComposerLinkEdit): void;
    /** A paste would exceed the serialized message budget; nothing was inserted. */
    onPasteTooLong?(): void;
    /** Vet a pasted identity link as a notification recipient: the recipient under
     * its current name, or null to keep the display-only chip. */
    acceptRecipient?(pubkey: string): MentionRecipient | null;
};
/** ProseMirror owns native editing, composition, selection and a single history.
 * React owns only the noneditable token artwork and the surrounding composer. */
export declare function EditableInput({ ref, draft, decorationsFor, value: _value, disabled, placeholder, maxLength, onDraftChange, onFormatsChange, onEditLink, onPasteTooLong, acceptRecipient, ...events }: EditableInputProps & {
    draft: MentionDraft;
    decorationsFor(draft: MentionDraft): readonly EditorDecoration[];
}): import("react").JSX.Element;
