import { type RelayProfiler } from "./profiling";
import type { ReadFilter, RelayEvent } from "./events";
import type { ReadTransport } from "./transport";
export type Priority = "foreground" | "background";
export type ReadOptions = {
    signal?: AbortSignal;
    priority?: Priority;
    /** A write preflight must start after its intent, never join an older in-flight read. */
    fresh?: boolean;
    /** Replaces the reader's deadline for new work; a joining read keeps the
     * deadline of the read it joins. */
    deadlineMs?: number;
    /** A read of every channel resolves the channels its events name first,
     * whatever their kinds, so a readable one the session does not know yet is
     * not dropped. It waits for discovery: before it, the read fails. */
    resolveChannels?: boolean;
};
/** Finite, verified event reads. No retained event cache or claim of live freshness. */
export type RelayReader = {
    readStateSnapshot?(options?: ReadOptions): Promise<readonly RelayEvent[]>;
    /** One page of the relay's name-only profile search (see
     * `ReadTransport.searchProfiles`), under the same deadline and cancellation
     * as `read`. Absent when the transport has no such endpoint. */
    searchProfiles?(query: string, limit: number, page: number, options?: ReadOptions): Promise<readonly RelayEvent[]>;
    read(filters: readonly ReadFilter[], options?: ReadOptions): Promise<readonly RelayEvent[]>;
};
/** The most serialized events one read may return. */
export declare const RELAY_READ_BYTES: number;
/** For reads whose result can approach RELAY_READ_BYTES: the native
 * transport's per-request ceiling (src-tauri/src/relay.rs). Ten seconds needs
 * about 800 KB/s for such a result, so a slow relay link would fail the read
 * on every retry rather than finish it. */
export declare const LARGE_READ_DEADLINE_MS = 30000;
/** Session-owned scheduling and cancellation. Equal concurrent reads share work;
 * cancelling one consumer never cancels another. Completion releases all request state. */
export declare function createRelayReader(transport: ReadTransport | null, { timeoutMs, maxPending, profiling, }?: {
    timeoutMs?: number;
    maxPending?: number;
    profiling?: RelayProfiler;
}): {
    reader: RelayReader;
    /** The session's local inventory shares navigation admission and read lifetime. */
    readAgentLibrary: (signal: AbortSignal) => Promise<Readonly<{
        definitions: readonly Readonly<{
            id: string;
            name: string;
            avatar?: string;
        }>[];
        identities: readonly Readonly<{
            pubkey: string;
            name: string;
            avatar?: string;
            definitionId?: string;
        }>[];
    }>>;
    /** Promote existing queued work without creating a consumer or a new deadline. */
    promote(matches: (filters: readonly ReadFilter[]) => boolean): void;
    invalidate(matches?: (filters: readonly ReadFilter[]) => boolean): void;
    dispose(): void;
};
