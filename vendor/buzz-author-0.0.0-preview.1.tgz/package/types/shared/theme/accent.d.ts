import type { CSSProperties } from "react";
import { ACCENTS } from "../design-system/tokens/brand";
export { ACCENTS };
export type Accent = (typeof ACCENTS)[number];
export declare const DEFAULT_ACCENT: Accent;
export declare const ACCENT_KEY = "buzz-accent.v1";
/** The former message-bubble preference; read once when no accent is saved. */
export declare const LEGACY_BUBBLE_KEY = "buzz-bubble-color.v1";
export declare function parseAccent(value: unknown): Accent;
export declare function parseLegacyBubbleColor(value: unknown): Accent;
export type Contrast = "low" | "high";
export declare const CONTRAST_KEY = "buzz-contrast.v1";
export declare const parseContrast: (value: unknown) => Contrast;
export declare const accentButtonStyle: CSSProperties;
