import { terminalOutcome } from "./observer";
type Source = Readonly<{
    id: string;
    agent: string;
    receivedAt: number;
    plaintext: string;
}>;
export type TranscriptScope = Readonly<{
    agent: string;
    channelId?: string | undefined;
}>;
export type PromptSection = Readonly<{
    tag: string;
    body: string;
}>;
type Base = {
    id: string;
    at: number;
};
/** ACP `diff` tool content; a missing old text is a new file. */
export type ToolDiff = {
    path: string;
    oldText?: string;
    newText: string;
};
/** Tool names and inputs are adapter-specific, so they are shown as sent;
 * only ACP's standard `kind`, `status`, `locations` and content are read.
 * The exception is a Buzz message tool, recognized by a title of
 * `buzz__<tool>` or `mcp__buzz__<tool>`: when it completes with a
 * `rawInput.text` and no `rawOutput.isError`, it is shown as the agent's
 * posted message instead of as a tool. Renaming those titles or fields in an
 * adapter turns its sends back into tool rows. */
export type ToolItem = Base & {
    type: "tool";
    toolCallId: string;
    title: string;
    kind: string;
    status: string;
    input: string;
    output: string;
    diffs: ToolDiff[];
    paths: string[];
    completedAt?: number;
    truncated: boolean;
    permission?: {
        options: string[];
        outcome?: string;
    };
    /** Calls recorded while this script was executing, in recorded order. */
    children?: TranscriptItem[];
};
export type TranscriptItem = (Base & {
    type: "system";
    sections: PromptSection[];
}) | (Base & {
    type: "prompt";
    text: string;
    author?: string;
    authorPubkey?: string;
    sections: PromptSection[];
    steer: boolean;
}) | (Base & {
    type: "message" | "thought";
    text: string;
    messageId?: string;
    /** Posted to Buzz, rather than said only in the session. */
    posted?: boolean;
}) | ToolItem | (Base & {
    type: "plan";
    entries: {
        content: string;
        status: string;
    }[];
}) | (Base & {
    type: "status";
    text: string;
});
export type TranscriptTurn = {
    turnId: string;
    channelId: string | null;
    /** Null is the channel conversation; undefined means not recoverable. */
    threadRootId: string | null | undefined;
    source?: string;
    triggeringEventIds: string[];
    sessionId?: string;
    newSession: boolean;
    /** The first shown turn of a session that began before the shown ones. */
    continued?: boolean;
    /** Selected ACP session config values, e.g. model and thinking level. */
    config: string[];
    startedAt: number;
    endedAt?: number;
    outcome?: ReturnType<typeof terminalOutcome>;
    error?: string;
    stopReason?: string;
    context?: {
        used: number;
        size: number;
    };
    /** No turn_started frame is loaded, so earlier items may be missing. */
    partial: boolean;
    items: TranscriptItem[];
};
export type Transcript = Readonly<{
    turns: readonly TranscriptTurn[];
}>;
/** A prompt section's readable title; an unknown tag shows as it is. */
export declare const sectionTitle: (tag: string) => string;
/** A steer's section holds its event, or before exact records, a whole turn. */
export declare const STEER = "new-message-arrived-while-you-were-working";
/** Split top-level `<tag attrs>` … `</tag>` prompt framing; other text is kept. */
export declare function promptSections(text: string): PromptSection[];
/** The triggering Buzz event(s): author label and content, without tags.
 * An event sent as an exact record names its author by `name`, if known. */
export declare function promptMessage(sections: PromptSection[], name?: (pubkey: string) => string | undefined): {
    text: string;
    author: string | undefined;
    authorPubkey: string | undefined;
};
/** Older harnesses supplied thread scope only in the captured ACP prompt. */
export declare function activityPromptThread(payload: unknown): string | null | undefined;
export declare function activityTranscript(records: readonly Source[], scope: TranscriptScope, 
/** Names an exact-record prompt's author, if known. */
name?: (pubkey: string) => string | undefined): Transcript;
export {};
