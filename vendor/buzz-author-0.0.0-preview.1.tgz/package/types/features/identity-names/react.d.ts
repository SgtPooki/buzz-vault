import type { NamingIdentity } from "./policy";
import type { RelaySession } from "../relay/session";
import type { IdentityNameView } from "./service";
/** The interface arrives through the captured session, never a global lookup.
 * Pass stable `candidates` and `displayFacts` arrays: a new one re-renders on the next name change. */
export declare function useIdentityNames(names: IdentityNameView | undefined): (pubkey: string, fallback: string, candidates?: readonly string[], displayFacts?: readonly NamingIdentity[]) => string;
/** For callers that read `names.lookup` or `names.scope` directly, which
 * `useIdentityNames` does not watch: re-render on every name change while active. */
export declare function useNamesRevision(names: IdentityNameView | undefined, active: boolean): number;
/** Channel membership defines ambiguity, not the community-wide profile cache. */
export declare function useChannelIdentityNames(session: {
    names?: IdentityNameView | undefined;
    channels: Pick<RelaySession["channels"], "list" | "subscribeList">;
} | undefined, channelId: string | undefined): (pubkey: string, fallback: string) => string;
