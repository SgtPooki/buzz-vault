import type { RelaySession } from "../relay/session";
import type { OutboxRecovery } from "../relay/outbox";
import type { FollowUpMessage } from "./follow-up-storage";
/** Recreated after restart; no composer closures or old membership authority. */
export declare function followUpMessage(session: RelaySession, message: FollowUpMessage): {
    ready(): boolean;
    beforeRelease(): Promise<void>;
    publish(recovery?: OutboxRecovery): string;
};
