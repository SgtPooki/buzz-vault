import type { ActivityTurn } from "./activity";
import { type ActivityRecord } from "./activity-records";
/** Live request association from explicit captured trigger IDs only. No time/name
 * inference, backfill, or broader channel fallback when the start is missing. */
export declare function requestActivity(records: readonly Omit<ActivityRecord, "envelopeId">[], agent: string, channelId: string, requestId: string | readonly string[], turns?: readonly ActivityTurn[]): {
    records: ActivityRecord[];
    turnIds: Set<string>;
    terminal: Map<string, NonNullable<"ended" | "error" | "stopped" | "unknown" | undefined>>;
    uncertain: boolean;
};
/** Already scoped lifecycle evidence, never a claim that a reply was delivered.
 * Working dominates; all linked turns must agree before an aggregate end label.
 * Retained request associations survive raw feed trimming. */
export declare function requestActivityState(selected: ReturnType<typeof requestActivity>, turns: readonly ActivityTurn[], trimmed?: number): "waiting" | "working" | "unknown" | "ended" | "error" | "stopped";
