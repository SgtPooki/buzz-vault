import type { EventData } from "../relay/events";
export declare const CANVAS_INSTRUCTIONS = "canvas-instructions";
export type CanvasHead = Pick<EventData, "pubkey" | "kind" | "created_at" | "tags" | "content">;
/** Partial edits do not approve instructions inherited from another writer. */
export declare function approvedCanvas(head: CanvasHead, owner: string): Promise<boolean>;
