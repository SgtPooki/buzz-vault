import { EditorState, type Transaction } from "prosemirror-state";
import type { Command } from "prosemirror-state";
import type { BlockFormat } from "./composer-dom";
export declare function activeBlockFormats(state: EditorState): BlockFormat[];
/** Use native ProseMirror block commands, composing their steps into the same
 * transaction as token expansion/selection isolation. No second history owner. */
export declare function apply(tr: Transaction, command: Command): boolean;
export declare function toggleComposerBlock(state: EditorState, format: BlockFormat): Transaction | undefined;
/** Typed characters that can complete a fence line. */
export declare const composerFenceDelimiters: ReadonlySet<string>;
/** Typing the third character of a line holding only ``` or ~~~ turns that line
 * into a code block at once, without waiting for Enter. Only a fence the typed
 * character completes at the end of its line qualifies: a fence that closes or
 * sits inside a block the other lines of its paragraph, or of the sibling
 * paragraphs joined to it on the wire, open (pasted source, a message opened
 * for editing, or a paragraph a toolbar toggle split), fences inside
 * code/link/literal ranges or tokens, and any line inside an existing code
 * block stay literal source. The transaction carries the deletion and the
 * block; the caller closes history around it, so one undo restores the typed
 * fence. */
export declare function composerCodeFence(state: EditorState, typed: string): Transaction | undefined;
/** The typed character that completes a list or quote prefix. */
export declare const composerPrefixDelimiters: ReadonlySet<string>;
/** Typing the space after a lone `- `, `1. ` or `> ` marker turns the caret's
 * line into a list item or quoted paragraph at once, producing the node the
 * toolbar toggle would: prose after the caret on that line becomes the block's
 * content, and the paragraph's other lines stay where they are. Inside a quote
 * the markers nest a list or a second quote; inside a list item a marker of
 * the item's own list kind, typed as the only text of an item after the first,
 * nests that item as Tab does. A marker typed after prose, as code, link or
 * literal text, inside a code block, or inside pasted fenced source stays
 * literal; chips, links and formatting later on the line move into the block.
 * The caller closes history around the transaction, so one undo restores the
 * typed prefix. */
export declare function composerBlockPrefix(state: EditorState, typed: string): Transaction | undefined;
/** A line break continues the block; an empty last line exits it. The host
 * owns when Enter sends or requests a line break. */
export declare function composerBlockLineBreak(state: EditorState): Transaction | undefined;
