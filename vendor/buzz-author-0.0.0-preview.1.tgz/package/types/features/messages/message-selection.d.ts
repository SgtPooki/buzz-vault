import type { KeyboardEvent } from "react";
import type { ChannelMessage } from "../relay/contracts";
/**
 * Keyboard message selection. A selected message is a focused row, so focus,
 * Virtua's keep-mounted rule and screen readers all follow the same fact.
 * Lists publish row lookup and editing; shortcuts act on the focused row.
 */
export type MessageList = Readonly<{
    row(id: string): ChannelMessage | undefined;
    /** The conversation's newest message, rendered or not. */
    newest(): string | undefined;
    canEdit(row: ChannelMessage): boolean;
    edit(row: ChannelMessage): void;
    /** Your own messages, through the menu's delete confirmation. */
    canDelete(row: ChannelMessage): boolean;
    remove(row: ChannelMessage): void;
    canMarkUnread(row: ChannelMessage): boolean;
    markUnread(row: ChannelMessage): void;
    /** Where Escape and Down past the newest message return focus. */
    composer(): HTMLElement | null;
}>;
export declare function registerMessageList(element: HTMLElement, list: MessageList): () => void;
export declare function selectMessage(row: HTMLElement): void;
/**
 * Selects the newest message by identity, since a nested thread's tree order
 * can put an older sibling last; false when it isn't rendered or there is none.
 */
export declare function selectNewestMessage(list: HTMLElement | null | undefined): boolean;
export type SelectedMessage = Readonly<{
    element: HTMLElement;
    row: ChannelMessage;
    list: MessageList;
}>;
export declare function selectedMessage(): SelectedMessage | undefined;
/** The focused pane's list, else the first visible one, as composer shortcuts do. */
export declare function activeMessageList(): HTMLElement | undefined;
/** The selected row's own reaction picker trigger, preferring its action bar. */
export declare function reactionTrigger(element: HTMLElement): HTMLButtonElement | undefined;
/** The selected row's own Reply control, which opens or answers its thread. */
export declare function replyTrigger(element: HTMLElement): HTMLButtonElement | undefined;
/**
 * Up/Down move between messages and Escape returns to the composer, but only
 * while a message itself is selected; controls inside it keep their keys.
 * Up at the oldest rendered row stays native so history can load, as does
 * Down at the last rendered row while newer ones are unmounted.
 */
export declare function moveMessageSelection(event: KeyboardEvent<HTMLElement>): void;
