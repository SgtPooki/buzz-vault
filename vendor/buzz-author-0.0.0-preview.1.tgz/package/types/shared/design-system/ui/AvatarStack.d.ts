type StackAvatar = {
    id: string;
    name: string;
    src?: string | undefined;
    shape: "circle" | "squircle";
};
/** Compact identity artwork. The enclosing control supplies its accessible name. */
export declare function AvatarStack({ items, size, max, animateEntrance, }: {
    items: readonly StackAvatar[];
    size?: "compact" | "small" | "mini" | "hero" | "hero-large";
    /** How many avatars show before the overflow count. */
    max?: number;
    /** Playful hero entry, matching the huddle avatar spring. */
    animateEntrance?: boolean;
}): import("react").JSX.Element | null;
export {};
