import type { ActivityRowPresentation } from "./activity-presentation";
import { type ReactNode } from "react";
import type { RelaySession } from "../relay/session";
import type { UnreadCapability } from "../relay/unread";
import { type MediaPlayback } from "./MediaAttachment";
import type { ConversationExtensions } from "../conversation/contracts";
import type { ChannelMessage, Profile } from "../relay/contracts";
export type MessageLinkOrigin = Readonly<{
    rootId: string;
}>;
export type MessageRowProps = {
    row: ChannelMessage;
    recordedActivity?: ActivityRowPresentation | undefined;
    representedAgents?: readonly string[] | undefined;
    repliedAgents?: readonly string[] | undefined;
    stoppedRequest?: ChannelMessage | undefined;
    staticMentions?: boolean | undefined;
    getThreadRoot?: (() => ChannelMessage | undefined) | undefined;
    session?: RelaySession | undefined;
    /** Resolves names, channels and mentions where the row is shown without
     * `session`, which would also offer its controls. */
    references?: RelaySession | undefined;
    scope?: string | undefined;
    unread?: UnreadCapability | undefined;
    extensions?: ConversationExtensions | undefined;
    profile: Profile | undefined;
    participantProfiles?: ReadonlyMap<string, Profile> | undefined;
    agentPubkeys?: ReadonlySet<string> | undefined;
    canOpenLink?: ((target: string) => boolean) | undefined;
    media(url: string, size?: "small"): string | undefined;
    /** Receives the thread the link was opened from: the row’s root, or the row. */
    onOpenLink(url: string, origin?: MessageLinkOrigin): boolean;
    day: boolean;
    retry: ((id: string) => void) | undefined;
    /** Pins this row in a virtualized list; returns the release. */
    keepMounted?: ((messageId: string) => () => void) | undefined;
    onOpenThread?: ((messageId: string, threadRootId: string, intent?: "reply") => void) | undefined;
    onReply?: ((messageId: string) => void) | undefined;
    /** False: existing threads open, but the row offers none to start or reply in. */
    startsThreads?: boolean;
    quickControls?: ReactNode;
    overflowItems?: ReactNode;
    layout?: "timeline" | "thread" | "continuation";
    compactAvatar?: boolean;
    viewer?: string | undefined;
    stackPrevious?: boolean;
    stackNext?: boolean;
    alignViewer?: boolean;
    mediaMode?: "inline" | "thread";
    mediaSeekTo?: number;
    mediaSeekRequest?: number;
    onMediaPlayback?: (playback: MediaPlayback) => void;
    onMediaTime?: (seconds: number) => void;
    onOpenMediaReview?: (messageId: string, attachment: ChannelMessage["attachments"][number], seconds: number, hasComments?: boolean, attachments?: ChannelMessage["attachments"]) => void;
};
/** Coordination between agents reads as one quiet line in time order: who
 * wrote it, who it is for, and its first paragraph. Opening the line shows
 * the whole message. The mentions it opens with become the line's recipients,
 * so they are not repeated in its text. */
export declare const MessageRow: import("react").MemoExoticComponent<(props: MessageRowProps) => import("react").JSX.Element>;
