import type { ChannelSummary } from "../relay/contracts";
/**
 * How the viewer already relates to each person, for ordering people as
 * destinations (New message recipients, Command-K People). Lower is closer:
 * a one-to-one DM, then a group DM, then one of the viewer's messageable agents,
 * then a shared channel, then nobody. This is the destination form of the
 * mention chooser's "channel members first".
 */
export declare function peopleRelationships(channels: readonly ChannelSummary[], messageableAgents: ReadonlySet<string>): {
    /** The one-to-one DM with this person, if one is listed. */
    dm: (pubkey: string) => string | undefined;
    rank: (pubkey: string) => 0 | 1 | 2 | 3 | 4;
};
