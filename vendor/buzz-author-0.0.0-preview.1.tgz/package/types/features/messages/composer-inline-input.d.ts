import { type Transaction } from "prosemirror-state";
/** Typed characters that can close an inline span. */
export declare const composerInlineDelimiters: ReadonlySet<string>;
/** Adopt only the inline span just closed by typing, never pasted/restored
 * Markdown or fenced blocks. The parser owns escapes, flanking and delimiter
 * matching, so the composer styles exactly what recipients will render. */
export declare function applyComposerInlineInput(tr: Transaction, typed: string): boolean;
