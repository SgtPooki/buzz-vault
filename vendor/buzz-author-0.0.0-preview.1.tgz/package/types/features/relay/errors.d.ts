export type ReadErrorKind = "cancelled" | "denied" | "unavailable" | "invalid-response";
export declare class ReadError extends Error {
    readonly kind: ReadErrorKind;
    readonly status?: number | undefined;
    /** Host API admission delay, not proof of history completeness or denial. */
    readonly retryAfterMs?: number | undefined;
    constructor(kind: ReadErrorKind, message: string, status?: number | undefined, 
    /** Host API admission delay, not proof of history completeness or denial. */
    retryAfterMs?: number | undefined);
}
/** HTTP statuses where the same request can succeed later unchanged. */
export declare function transientStatus(status: number): boolean;
export declare function httpReadError(status: number): ReadError;
/** Shared taxonomy for broker, signed transport and query lifecycle. The exact
 * legacy fixture phrase is accepted during migration, not arbitrary status text. */
export declare function readErrorKind(error: unknown): ReadErrorKind;
/** True when trying the same read again can succeed without anyone acting:
 * the relay or network was unavailable, slow, or the read was cancelled. A
 * denial, an invalid response or a deterministic local check is not. */
export declare function isTransientFailure(error: unknown): boolean;
