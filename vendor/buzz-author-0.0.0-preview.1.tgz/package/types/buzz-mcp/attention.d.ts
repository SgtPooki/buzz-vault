import type { AgentAttention } from "../features/agents/service";
import type { Tool } from "./tools";
export declare const ATTENTION_TOOLS: readonly Tool[];
type Args = Readonly<Record<string, unknown>>;
export declare const isAttentionTool: (name: string) => boolean;
/** Runs attention tool `name`. A throw is a tool error for the agent to read;
 * its text names the classifier state too. */
export declare function callAttentionTool(attention: AgentAttention, name: string, args: Args): Promise<string>;
export {};
