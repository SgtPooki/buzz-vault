/** Versioned primary snapshot; a generic #e read cannot resolve mixed-case targets. */
export declare function effectiveEditFilter(id: string, channel: string): {
    kinds: number[];
    ids: string[];
    "#h": string[];
    effective_edit: number;
    consistency: string;
}[];
/** Empty replacement tags are authoritative, never a reason to use the original. */
export declare function effectiveEditDto(value: unknown, id: string, channel: string): import("nostr-tools").VerifiedEvent;
