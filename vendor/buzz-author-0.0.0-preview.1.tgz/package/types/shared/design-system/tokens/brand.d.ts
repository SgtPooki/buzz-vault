/** Palette metadata for Appearance references and proposed plugin artwork. */
export declare const BRAND_SHADES: readonly [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12];
/** Canonical Appearance order; re-exported by shared/theme/accent.ts. */
export declare const ACCENTS: readonly ["bee", "magenta", "iris", "cobalt", "citrus", "mono"];
/** Retained artwork palettes are independent of selectable Appearance accents. */
export declare const PALETTE_FAMILIES: readonly ["bee", "magenta", "iris", "cobalt", "citrus", "mono", "flame", "jade"];
/** Proposed artwork mapping uses existing theme-aware palette families independently
 * of the existing Appearance choices above. */
export declare const BRAND_GRADIENTS: readonly [{
    readonly name: "Communication";
    readonly category: "communication";
    readonly start: "cyan-9";
    readonly end: "jade-9";
    readonly compromise: "Cyan to jade gives Communication a teal/green identity distinct from Agents.";
}, {
    readonly name: "Agents";
    readonly category: "agents";
    readonly start: "blue-9";
    readonly end: "iris-9";
    readonly compromise: "Existing Iris supplies violet beneath lighter blue in both themes.";
}, {
    readonly name: "Agent tools";
    readonly category: "agent-tools";
    readonly start: "purple-9";
    readonly end: "magenta-9";
    readonly compromise: "Purple to the existing Magenta fill gives agent tools a violet-to-rose identity.";
}, {
    readonly name: "Developer tools & integrations";
    readonly category: "developer-tools-and-integrations";
    readonly start: "orange-9";
    readonly end: "flame-9";
    readonly compromise: "Orange to the existing Flame fill gives developer tools a warm ember identity.";
}, {
    readonly name: "People & communities";
    readonly category: "people-and-communities";
    readonly start: "red-9";
    readonly end: "magenta-9";
    readonly compromise: "Red to existing Magenta gives people a scarlet-to-rose identity.";
}, {
    readonly name: "Productivity";
    readonly category: "productivity";
    readonly start: "amber-9";
    readonly end: "flame-9";
    readonly compromise: "Golden amber to Flame gives productivity a warm sunset identity.";
}];
