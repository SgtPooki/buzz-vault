import type { ReactNode } from "react";
import type { AttachmentRenderer, AttachmentRendererProps, ContributionReader, TargetOpener } from "./contracts";
export declare function AttachmentView({ registry, fallback, ...props }: Omit<AttachmentRendererProps, keyof TargetOpener> & {
    registry: ContributionReader<AttachmentRenderer>;
    fallback: ReactNode;
}): string | number | bigint | boolean | import("react").JSX.Element | Iterable<ReactNode> | Promise<string | number | bigint | boolean | Iterable<ReactNode> | import("react").ReactElement<unknown, string | import("react").JSXElementConstructor<any>> | import("react").ReactPortal | null | undefined> | null | undefined;
