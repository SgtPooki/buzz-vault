import { ContextMenu as BaseContextMenu } from "@base-ui/react/context-menu";
import { Menu as BaseMenu } from "@base-ui/react/menu";
import { type HoverOpen } from "./hoverIntent";
import { type ComponentProps, type ReactNode } from "react";
export declare function MenuRoot<Payload>(props: BaseMenu.Root.Props<Payload>): import("react").JSX.Element;
type MenuTriggerProps<Payload> = Omit<BaseMenu.Trigger.Props<Payload>, "openOnHover" | "delay" | "closeDelay"> & {
    /** Opening on hover takes its timing from a DESIGN.md "Hover timing" bucket. */
    openOnHover?: HoverOpen | false | undefined;
};
export declare function MenuTrigger<Payload>({ openOnHover, ...props }: MenuTriggerProps<Payload>): import("react").JSX.Element;
export declare function ContextMenuRoot({ open, defaultOpen, onOpenChange, onOpenChangeComplete, ...props }: ComponentProps<typeof BaseContextMenu.Root>): import("react").JSX.Element;
export declare function ContextMenuTrigger(props: ComponentProps<typeof BaseContextMenu.Trigger>): import("react").JSX.Element;
export declare const MenuGroup: import("react").ForwardRefExoticComponent<Omit<import("@base-ui/react").MenuGroupProps, "ref"> & import("react").RefAttributes<HTMLDivElement>>;
export declare const MenuRadioGroup: import("react").NamedExoticComponent<Omit<import("@base-ui/react").MenuRadioGroupProps, "ref"> & import("react").RefAttributes<HTMLDivElement>>;
export type MenuPosition = Pick<ComponentProps<typeof BaseMenu.Positioner>, "align" | "alignOffset" | "anchor" | "collisionPadding" | "collisionAvoidance" | "side" | "sideOffset" | "sticky">;
type PopupProps = Omit<ComponentProps<typeof BaseMenu.Popup>, "className"> & MenuPosition & {
    children: ReactNode;
    /** Compact is for short action lists; larger choices retain panel corners. */
    size?: "compact" | "default" | "wide";
};
/** An anchored action menu with collision handling and shared floating-surface styling. */
export declare function MenuPopup(props: PopupProps): import("react").JSX.Element;
export declare function MenuSubmenu(props: ComponentProps<typeof BaseMenu.SubmenuRoot>): import("react").JSX.Element;
export declare function MenuSubmenuPopup(props: PopupProps): import("react").JSX.Element;
type ItemProps = Omit<ComponentProps<typeof BaseMenu.Item>, "className"> & {
    tone?: "default" | "danger";
};
export declare function MenuItem({ tone, ...props }: ItemProps): import("react").JSX.Element;
type LinkItemProps = Omit<ComponentProps<typeof BaseMenu.LinkItem>, "className">;
export declare function MenuLinkItem(props: LinkItemProps): import("react").JSX.Element;
type SubmenuTriggerProps = Omit<ComponentProps<typeof BaseMenu.SubmenuTrigger>, "className">;
export declare function MenuSubmenuTrigger({ children, ...props }: SubmenuTriggerProps): import("react").JSX.Element;
type CheckboxItemProps = Omit<ComponentProps<typeof BaseMenu.CheckboxItem>, "className">;
export declare function MenuCheckboxItem({ children, ...props }: CheckboxItemProps): import("react").JSX.Element;
type RadioItemProps = Omit<ComponentProps<typeof BaseMenu.RadioItem>, "className"> & {
    selection?: "check" | "highlight";
};
export declare function MenuRadioItem({ children, selection, ...props }: RadioItemProps): import("react").JSX.Element;
export declare function MenuGroupLabel({ children, emphasis, }: {
    children: ReactNode;
    emphasis?: "default" | "quiet";
}): import("react").JSX.Element;
export declare function MenuSeparator(): import("react").JSX.Element;
export declare function MenuIcon({ children }: {
    children: ReactNode;
}): import("react").JSX.Element;
export declare function MenuTrailing({ children }: {
    children: ReactNode;
}): import("react").JSX.Element;
/** Supporting context and status text, outside the menu's keyboard item list. */
export declare function MenuNote(props: Omit<ComponentProps<"p">, "className">): import("react").JSX.Element;
export {};
