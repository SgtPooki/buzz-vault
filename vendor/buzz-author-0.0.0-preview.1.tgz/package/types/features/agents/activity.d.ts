import type { LocalAgentSource, LocalWork } from "./local-activity";
import type { EventData } from "../relay/events";
import type { LiveSnapshot } from "../relay/live";
import { terminalOutcome, type ObserverFrame } from "./observer";
export declare const ACTIVITY_RECORD_LIMIT = 200;
export declare const ACTIVITY_BYTE_LIMIT: number;
export declare const ACTIVITY_TURN_LIMIT = 512;
export declare const ACTIVITY_FRESH_MS = 30000;
type RawRecord = ObserverFrame & Readonly<{
    receivedAt: number;
    kind: string;
    /** Recognized envelope/child channel metadata; plaintext stays unmodified. */
    channelIds: readonly string[];
}>;
export type ActivityTurn = Readonly<{
    agent: string;
    turnId: string;
    sessionId?: string;
    threadRootId?: string;
    channelId: string | null;
    timestamp: number;
    state: "working" | "unknown" | "ended";
    /** Retained independently of the bounded raw activity buffer. */
    outcome?: ReturnType<typeof terminalOutcome>;
    triggeringEventIds?: readonly string[];
    /** Multiple distinct starts reused this turn ID; request identity is ambiguous. */
    ambiguous?: boolean;
    /** Roots established from retained signed triggering messages, not typing. */
    requests?: readonly Readonly<{
        messageId: string;
        threadRootId: string;
    }>[];
}>;
type Typing = Readonly<{
    agent: string;
    channelId: string;
    threadRootId: string | undefined;
    timestamp: number;
    /** First observed working signal in this uninterrupted typing run. */
    startedAt: number;
    working: boolean;
    expiresAt: number;
}>;
/** Published typing: a pulse that only refreshes its clock changes nothing. */
type TypingEntry = Omit<Typing, "timestamp" | "expiresAt">;
/** Session-owned live evidence. Plugin activation owns demand, not sockets or keys. */
export declare function createAgentActivity(available: boolean, observe: (generation: number | null) => void, canAccess: (channel: string) => boolean, notify?: (listener: () => void) => void, findMessage?: (id: string) => EventData | undefined, local?: {
    source: LocalAgentSource;
    scope: string;
}): {
    queries: Readonly<{
        snapshot: () => Readonly<{
            status: "unavailable" | "disabled" | "connecting" | "listening" | "interrupted";
            records: readonly RawRecord[];
            turns: readonly ActivityTurn[];
            local?: readonly LocalWork[];
            typing: readonly TypingEntry[];
            trimmed: number;
            /** Unlike raw-record trimming, losing a turn can lose request completeness. */
            turnsTrimmed?: boolean;
        }>;
        /** Owner-authorized status readback for an exact retained remote task.
         * Never invent raw telemetry or replace an already received terminal. */
        reconcile(turn: ActivityTurn, outcome: "ended" | "error" | "stopped"): void;
        /** Display-only local acknowledgement, scoped to this session and access. */
        dismissError(agent: string, channelId: string, messageId: string): boolean;
        /** Stops the turn a local request is in, scoped to this session and access. */
        interrupt(agent: string, channelId: string, messageId: string): Promise<void>;
        /** Asks again for a failed local request, scoped to this session and access. */
        retry(agent: string, channelId: string, messageId: string): void;
        workingSnapshot: () => string;
        subscribeWorking(listener: () => void): () => void;
        subscribe(listener: () => void): () => void;
        activate(): () => void;
    }>;
    receive(input: ObserverFrame, current: number): void;
    /** Trigger messages may arrive after telemetry. Resolve at content admission,
     * not on the freshness timer, without retaining or fetching more messages. */
    messagesChanged(events: readonly EventData[]): void;
    /** Public typing is scope/freshness evidence only, never ownership evidence. */
    channelEvents(events: readonly EventData[]): void;
    state(live: LiveSnapshot): void;
    accessChanged(): void;
    clear: () => void;
    dispose(): void;
};
export {};
