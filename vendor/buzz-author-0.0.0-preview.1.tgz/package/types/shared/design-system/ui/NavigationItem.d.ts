import { Button as BaseButton } from "@base-ui/react/button";
import type { ComponentProps, ReactNode } from "react";
/** One navigation surface for a primary row and independent sibling controls.
 * The primary NavigationItem still owns focus and aria-current. */
export declare function NavigationCard({ className, children, footer, body, tone, ...props }: ComponentProps<"div"> & {
    footer?: ReactNode;
    body?: ReactNode;
    tone?: "default" | "tonal" | "inset";
}): import("react").JSX.Element;
export declare function NavigationItem({ label, icon, trailing, selected, highlighted, inset, variant, multiline, ...props }: {
    label: ReactNode;
    icon?: ReactNode;
    trailing?: ReactNode;
    selected?: boolean;
    /** Transient picker focus; persistent navigation selection stays separate. */
    highlighted?: boolean;
    inset?: boolean;
    variant?: "row" | "pill" | "option" | "search" | "text";
    /** Stacked labels grow the row without clipping its primary target. */
    multiline?: boolean;
} & Omit<ComponentProps<typeof BaseButton>, "className" | "children">): import("react").JSX.Element;
