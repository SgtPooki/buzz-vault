export type NamingIdentity = {
    pubkey: string;
    name: string;
    isAgent?: boolean;
    ownerPubkey?: string;
};
/** A scope's naming input: its selected keys and the owners of selected
 * agents. Rows outside it only supply those owners' names. `rowsOf` returns
 * every row for a key. The name directory and this policy share this rule. */
export declare function scopeKeys(selection: Iterable<string>, rowsOf: (key: string) => Iterable<NamingIdentity>): Set<string>;
/** Display policy only. Neither a readable owner nor a key suffix grants authority. */
export declare function resolveIdentityNames(identities: readonly NamingIdentity[], viewer?: string, candidates?: readonly string[]): Map<string, {
    name: string;
    qualifier: string | undefined;
}>;
