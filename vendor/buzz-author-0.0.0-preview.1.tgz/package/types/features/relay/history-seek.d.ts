import { type WindowCursor, type WindowPage } from "./window";
/** Rows per seek read: the relay's window maximum. */
export declare const SEEK_PAGE = 200;
/** Relay reads one seek may spend before it gives up. */
export declare const SEEK_READS = 40;
export declare class SeekLimitError extends Error {
    constructor();
}
/** Rows strictly older than `seconds`: past every id in that second. */
export declare function ceilingCursor(seconds: number): WindowCursor;
/** One window page below `cursor` (null: the head). `full` adds aux and summaries. */
export type SeekRead = (cursor: WindowCursor | null, full: boolean) => Promise<WindowPage>;
export type Located = Readonly<{
    kind: "newest";
}>
/** `page` holds every row in [from, ceiling) and older context below it.
 * A null ceiling means `page` is the head page. */
 | Readonly<{
    kind: "segment";
    page: WindowPage;
    ceiling: number | null;
}>;
/**
 * Find a ceiling whose newest-first page reaches back past `from`, so that it
 * holds the first top-level row at or after `from`. Windows read only newest
 * first, so this probes ceilings: galloping a day at a time from `from`, or
 * from the head when `gallop` is false (the channel start), then bisecting
 * between the last empty and the first overflowing ceiling. Probes are bare;
 * the chosen ceiling is read once in full.
 */
export declare function locate(read: SeekRead, from: number, now: number, gallop: boolean): Promise<Located>;
