/** Transient, but not the owner's own cancellation. */
export declare function isRetryableRead(error: unknown): boolean;
/** One initial read and up to three quiet retries under session recovery's
 * first three ceilings (1/2/4 s) with equal jitter, none starting after 10 s.
 * Exhaustion rethrows the last failure. Use one owner per read path; the
 * caller owns its lifetime. */
export declare function retryRead<T>(read: (signal: AbortSignal) => Promise<T>, signal: AbortSignal, retryable?: (error: unknown) => boolean): Promise<T>;
