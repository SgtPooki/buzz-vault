import type { ChannelSummary, Profile } from "../relay/contracts";
import type { IncomingMessage } from "../relay/incoming";
import type { NotificationCategory } from "./preferences";
export type NotificationText = Readonly<{
    title: string;
    body: string;
}>;
type PreviewOptions = Readonly<{
    storedPreview?: boolean;
}>;
/** Flattened, bounded prose; empty when nothing displayable remains.
 * Stored previews have lost code/escape provenance and may have been cut. */
export declare function plainText(content: string, options?: PreviewOptions): string;
/** Bounded CommonMark text, not rendered HTML or a fetch of linked/attached content. */
export declare function messagePreview(content: string, options?: PreviewOptions): string;
/** Plugin text gets the same flattening and bounds; missing text keeps the category fallback. */
export declare function pluginNotificationText(input: Readonly<{
    title?: string;
    body?: string;
}>, label: string): NotificationText;
/** Names are optional cached enrichment; notifications never wait for profile reads. */
export declare function messageNotificationText(message: IncomingMessage, category: NotificationCategory, channel: ChannelSummary | undefined, profile: Profile | undefined, resolvedName?: string | undefined): NotificationText;
export {};
