import { Service, type Context } from "@deepseek-ai/cordis";
export type HostRequest = Readonly<{
    url: string;
    method?: "GET" | "HEAD" | "POST" | "PUT" | "PATCH" | "DELETE";
    headers?: Readonly<Record<string, string>>;
    body?: string;
    /** Native deadline in milliseconds, 1–180000. Defaults to 30000. */
    timeoutMs?: number;
}>;
/** A multipart POST of one local `.tar.gz` file in the home directory, with
 * text fields beside it, to an origin the plugin declares. */
export type HostUpload = Readonly<{
    url: string;
    headers?: Readonly<Record<string, string>>;
    fields?: Readonly<Record<string, string>>;
    file: Readonly<{
        /** The form field it is sent as. */
        field: string;
        /** An absolute path. */
        path: string;
        /** The file name the form gives it. */
        name: string;
        contentType: string;
    }>;
}>;
/** One in-memory multipart part plus bounded text fields. Desktop only. */
export type HostByteUpload = Readonly<{
    url: string;
    /** 1–256 ASCII letters/digits/dots/underscores/hyphens; no leading dot. */
    field: string;
    /** One filename with the same safe characters; no leading dot or path. */
    name: string;
    /** Exactly image/png, image/jpeg or image/webp, matching the bytes' signature. */
    contentType: string;
    /** At most 16 text fields, safe names, each value at most 8192 UTF-8 bytes. */
    fields?: Readonly<Record<string, string>>;
}>;
/** Raw bytes upload (PUT/POST) to a declared or dynamic public HTTPS destination. Desktop only. */
export type HostByteSend = Readonly<{
    url: string;
    method?: "PUT" | "POST";
    contentType?: string;
    timeoutMs?: number;
}>;
export type HostResponse = Readonly<{
    status: number;
    headers: Readonly<Record<string, string>>;
    body: string;
}>;
export type HostRequestOnceOptions = Readonly<{
    callId: string;
    /** Synchronous final caller check. Only literal true permits dispatch. */
    isEligible?: () => boolean;
}>;
/** GET-only raw bytes from an exact declared HTTPS origin. Desktop only. */
export type HostByteRequest = Readonly<{
    url: string;
    /** Required integer byte cap, 1–16777216. */
    maxBytes: number;
    /** 1–30000 milliseconds; defaults to 30000. */
    timeoutMs?: number;
}>;
export type HostByteResponse = Readonly<{
    status: number;
    headers: Readonly<Record<string, string>>;
    body: Uint8Array;
}>;
export type HostSavedBytes = Readonly<{
    path: string;
    size: number;
    sha256: string;
    /** Host wall-clock Unix milliseconds, not a deletion timer. */
    expiresAt: number;
}>;
/** Reusable NIP-OA proof for one agent key; preparing it does not submit it. */
export type NipOaAuthorization = readonly [
    "auth",
    ownerPubkey: string,
    conditions: string,
    signature: string
];
export type ProcessProtection = Readonly<{
    readOnlyPaths: readonly string[];
    hiddenPaths: readonly string[];
}>;
/** The variable a Buzz credential is handed over in. */
export declare const CREDENTIAL_ENV = "BUZZ_CREDENTIAL_PROVIDER";
export type HostProcessOptions = Readonly<{
    /** Follow the arguments the manifest declares. */
    args?: readonly string[];
    /** An absolute directory or one under home written `~/…`; created if missing. */
    cwd?: string;
    /** Added to the app's environment; `null` removes a variable. */
    env?: Readonly<Record<string, string | null>>;
    /** Run with one app-held MCP session and an agent-scoped `buzz` on PATH. */
    mcp?: Pick<HostMcpServer, "url" | "headers">;
    /** Native macOS containment for a protected worker and its descendants. */
    protection?: ProcessProtection;
    /** Hand it a Buzz credential (`BUZZ_CREDENTIAL_PROVIDER`) that acts for no
     * one until `actAs` names one of the plugin's agents. Not on Windows. */
    agentCredential?: boolean;
    /** Set by agent protection: the agent a protected engine is launched for.
     * Native checks that the agent's saved protection names this plugin. */
    protectedAgent?: Readonly<{
        pubkey: string;
        relay: string;
    }>;
    /** Secrets native code holds, set in its environment after `env`; one that
     * is not saved is left unset. Each is only for the processes it belongs
     * to: `anthropic-api-key` (`ANTHROPIC_API_KEY`) for Buzz's Claude. */
    secrets?: readonly "anthropic-api-key"[];
    onStdout?(data: string): void;
    onStderr?(data: string): void;
}>;
export type HostProcess = Readonly<{
    write(data: string): Promise<void>;
    /** Queue one complete streamed message without interleaving other writes. */
    writeStream?(data: AsyncIterable<string>): Promise<void>;
    /** Writes any final `data`, then closes stdin. */
    end(data?: string): Promise<void>;
    /** Asks it to stop, then kills it and its descendants. */
    kill(): Promise<void>;
    /** Only with `agentCredential`: lets its credential act as this agent of
     * the plugin's type from now on. A process acts as one agent only. */
    actAs?(agent: Readonly<{
        pubkey: string;
        relay: string;
    }>): Promise<void>;
    /** For a host several agents share: the `BUZZ_CREDENTIAL_PROVIDER` value
     * for only this agent's tool processes, never the host's own environment.
     * The same each call; revoked once the host exits. Undefined on Windows. */
    toolCredential?(agent: Readonly<{
        pubkey: string;
        relay: string;
    }>): Promise<string | undefined>;
    /** The exit code once it exits; null when a signal ended it. */
    exited: Promise<number | null>;
}>;
/** Answers one JSON-RPC message an agent sent: with the JSON-RPC response,
 * or `undefined` for a notification, which needs none. */
export type McpHandler = (message: unknown) => Promise<unknown>;
/** A loopback MCP server (Streamable HTTP) whose messages the plugin answers.
 * It belongs to the plugin and stops when the plugin unloads. */
export type HostMcpServer = Readonly<{
    /** `http://127.0.0.1:<port>/mcp` */
    url: string;
    /** What the agent must send with each request, as ACP's `mcpServers` and
     * MCP clients take them. */
    headers: readonly Readonly<{
        name: string;
        value: string;
    }>[];
    close(): Promise<void>;
    /** Resolves once it has stopped. */
    closed: Promise<void>;
    authorize?(request: McpAuthorization): Promise<void>;
}>;
export type McpAuthorization = Readonly<{
    callback: string;
    state: string;
    code_challenge: string;
    approval?: McpApproval;
    resume?: Readonly<{
        id: string;
        counter: number;
        proof: string;
    }>;
    durable_client?: string;
}>;
export type McpApproval = Readonly<{
    client: string;
    viewer: string;
    agent: string;
    community: string;
    scopes: readonly ("read" | "post" | "create" | "agent")[];
}>;
export type McpPairing = Readonly<{
    id: string;
    approval: McpApproval;
    expires_at: number;
}>;
/** Share one MCP session among cooperating clients holding the token.
 * This permits token reuse after initialization. The handler must bind identity
 * itself and grant every client the same authority. Defaults to false. */
export type HostMcpOptions = Readonly<{
    sharedSession?: boolean;
}>;
export interface Host {
    externalMcpPairing?(operation: "get" | "resume" | "revoke", request?: McpAuthorization): Promise<McpPairing | null>;
    denyMcpAuthorization?(request: McpAuthorization): Promise<void>;
    runCommand(id: string, input?: string): Promise<string | null>;
    /** Starts a process the manifest declares in `host.processes`. It lives until
     * it exits, is killed, or the plugin unloads. Desktop only. */
    spawn?: (id: string, options?: HostProcessOptions) => Promise<HostProcess>;
    /** Starts a loopback MCP server whose messages `handler` answers, for a
     * plugin whose manifest declares `host.mcp`. Desktop only. */
    serveMcp?: (handler: McpHandler, options?: HostMcpOptions) => Promise<HostMcpServer>;
    /** Reads a file of at most 50 MB, for a plugin whose manifest declares
     * `host.files`. `path` is absolute, `~/…`, or relative to `cwd`, which is
     * absolute or `~/…`. A missing file rejects with "No such file". Desktop
     * only. */
    readFile?: (path: string, options?: Readonly<{
        cwd?: string;
    }>) => Promise<Uint8Array>;
    /** `path`, absolute or `~/…`, as an absolute directory without symbolic
     * links, created if missing, for a plugin whose manifest declares
     * `host.files`. Desktop only. */
    resolveDirectory?: (path: string) => Promise<string>;
    request(input: HostRequest): Promise<HostResponse>;
    /** POST-only, desktop and compatible native host required. A repeated call
     * authority rejects with unknown outcome, never resubmits or caches success.
     * Blocks IPC-fallback resends only, not fresh calls or upstream retries.
     * Also send callId as a server idempotency key when the server supports it. */
    requestOnce?: (input: HostRequest, options: HostRequestOnceOptions) => Promise<HostResponse>;
    /** Protected multipart POST; no file grant, IPC fallback or automatic retry.
     * Copies 1–16777216 bytes before awaiting native authority. */
    uploadBytesOnce?: (bytes: Uint8Array, input: HostByteUpload, options: HostRequestOnceOptions) => Promise<HostResponse>;
    /** No automatic replay protection or text/array fallback. */
    requestBytes?: (input: HostByteRequest) => Promise<HostByteResponse>;
    /** Requires host.managedFiles, not host.files. Keep bytes immutable through
     * hashing/save. An ambiguous failure must not be automatically retried. */
    saveBytes?: (bytes: Uint8Array, input: Readonly<{
        sha256: string;
    }>) => Promise<HostSavedBytes>;
    /** Removes this plugin's own managed file. Await attachment sends first;
     * Conservatively refuses app-wide while any plugin's host.readFile call or
     * process named read/read-protected is active, regardless of program/path. */
    deleteManagedFile?: (path: string) => Promise<void>;
    /** Uploads a file as `request` sends a body. Desktop only. */
    upload?: (input: HostUpload) => Promise<HostResponse>;
    prepareRemoteAgentAuthorization?: (agentPubkey: string, signal?: AbortSignal) => Promise<NipOaAuthorization>;
}
declare module "@deepseek-ai/cordis" {
    interface Context {
        host: Host;
    }
}
/** The signed-in owner's NIP-OA proof for `agentPubkey`, from native
 * identity or the web relay proxy. */
export declare function prepareRemoteAgentAuthorization(agentPubkey: string, signal?: AbortSignal): Promise<NipOaAuthorization>;
export declare class HostService extends Service implements Host {
    constructor(context: Context);
    prepareRemoteAgentAuthorization(agentPubkey: string, signal?: AbortSignal): Promise<NipOaAuthorization>;
    runCommand(id: string, input?: string): Promise<string | null>;
    spawn(id: string, { onStdout, onStderr, ...options }?: HostProcessOptions): Promise<HostProcess>;
    serveMcp(handler: McpHandler, options?: HostMcpOptions): Promise<HostMcpServer>;
    denyMcpAuthorization(request: McpAuthorization): Promise<void>;
    externalMcpPairing(operation: "get" | "resume" | "revoke", request?: McpAuthorization): Promise<McpPairing | null>;
    readFile(path: string, { cwd }?: Readonly<{
        cwd?: string;
    }>): Promise<Uint8Array>;
    resolveDirectory(path: string): Promise<string>;
    request(input: HostRequest): Promise<HostResponse>;
    requestOnce(input: HostRequest, { callId, isEligible }: HostRequestOnceOptions): Promise<HostResponse>;
    uploadBytesOnce(bytes: Uint8Array, input: HostByteUpload, { callId, isEligible }: HostRequestOnceOptions): Promise<HostResponse>;
    sendBytesOnce(bytes: Uint8Array, input: HostByteSend, { callId, isEligible }: HostRequestOnceOptions): Promise<HostResponse>;
    requestBytes(input: HostByteRequest): Promise<HostByteResponse>;
    saveBytes(bytes: Uint8Array, { sha256 }: Readonly<{
        sha256: string;
    }>): Promise<HostSavedBytes>;
    deleteManagedFile(path: string): Promise<void>;
    upload(input: HostUpload): Promise<HostResponse>;
}
/** The reply to one HTTP body, which carries one message: MCP has no batches
 * since its 2025-06-18 revision. A handler that throws answers a request with
 * an internal error. */
export declare function answerMcp(handler: McpHandler, body: string): Promise<unknown>;
