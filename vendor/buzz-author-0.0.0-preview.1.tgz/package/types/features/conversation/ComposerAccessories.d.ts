import type { ComposerAccessory, ComposerAccessoryProps, ContributionReader } from "./contracts";
export declare function ComposerAccessories({ registry, placement, ...props }: ComposerAccessoryProps & {
    registry: ContributionReader<ComposerAccessory>;
    placement?: ComposerAccessory["placement"];
}): import("react").JSX.Element;
