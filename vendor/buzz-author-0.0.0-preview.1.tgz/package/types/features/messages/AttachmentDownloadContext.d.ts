/** Only a received-message surface opts plugin attachment content into saving. */
export declare const AttachmentDownloadContext: import("react").Context<boolean>;
