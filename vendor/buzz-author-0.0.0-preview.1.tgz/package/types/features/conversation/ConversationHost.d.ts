import type { Context } from "@deepseek-ai/cordis";
import { type ReactNode } from "react";
import type { ThreadPanelProps } from "../messages/ThreadPanel";
import type { MediaReview } from "./Conversation";
export type ConversationHostServices = Pick<Context, "panels" | "relay" | "navigation">;
export type ConversationInteractions = Required<Pick<ThreadPanelProps, "onOpenLink" | "canOpenLink" | "onOpenMediaReview">>;
type ConversationHostProps = Pick<ThreadPanelProps, "session" | "scope" | "channelId" | "channelName"> & {
    host: ConversationHostServices;
    threadId?: string | undefined;
    children(interactions: ConversationInteractions, mediaReview: MediaReview | undefined): ReactNode;
};
export declare function ConversationHost({ host, session, scope, channelId, channelName, threadId, children, }: ConversationHostProps): import("react").JSX.Element;
export {};
