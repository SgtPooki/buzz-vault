import type { UploadedAttachment } from "../relay/attachments";
import type { ComposerSession } from "./composer-session";
import { type AttachmentDraft, type DraftAttachment } from "./attachment-draft";
/** Where a send is going: its conversation's name and, unless only its own
 * entry point opens it (a huddle), a link that opens it. */
export type Destination = Readonly<{
    name: string;
    link?: string;
}>;
type Notice = Readonly<{
    id: string;
    title: string;
    description?: string;
    destination: Destination;
    retry?: () => void;
}>;
export type BackgroundUploads = Readonly<{
    uploading: boolean;
    phase: "Preparing upload" | "Uploading" | "Finishing upload";
    /** Fraction of bytes sent, or null while the host reports no byte counts. */
    progress: number | null;
    /** The send Cancel stops, and how many other sends are running. */
    destination: Destination | undefined;
    others: number;
    /** False while every listed send is cancelled but not yet settled. */
    cancellable: boolean;
    notices: readonly Notice[];
    host: object | undefined;
}>;
/** Takes admitted files after Send; files upload in order, then publish once.
 * Every unpublished outcome hands the files back to `recover`. */
export declare function sendInBackground(session: ComposerSession, owner: string, channelId: string, destination: Destination, files: readonly DraftAttachment[], publish: (uploaded: readonly UploadedAttachment[]) => void | Promise<void>, recover: (files: readonly DraftAttachment[], preparationError?: unknown) => boolean | "conflict", source?: AttachmentDraft): void;
/** Desktop's Cancel stops the newest send and restores it like a failure. */
export declare function cancelBackgroundUpload(session: ComposerSession): void;
/** Like Desktop, a conversation cannot send again until its upload settles. */
export declare function useBackgroundSendPending(session: ComposerSession, owner: string): boolean;
export declare function dismissBackgroundUploadNotice(session: ComposerSession, id: string): void;
/** Every composer shows progress; only the first mounted one hosts notices. */
export declare function useBackgroundUploads(session: ComposerSession): {
    uploading: boolean;
    phase: "Preparing upload" | "Uploading" | "Finishing upload";
    progress: number | null;
    destination: Destination | undefined;
    others: number;
    cancellable: boolean;
    host: object | undefined;
    notices: readonly Readonly<{
        id: string;
        title: string;
        description?: string;
        destination: Destination;
        retry?: () => void;
    }>[];
};
export {};
