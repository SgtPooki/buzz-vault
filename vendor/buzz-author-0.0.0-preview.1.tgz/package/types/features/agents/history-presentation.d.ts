import type { Navigation } from "../navigation/controller";
import { type OpenTarget } from "../navigation/targets";
export type HistorySelection = Readonly<{
    side: "settings" | "instructions";
    id: string;
}>;
export type HistoryPresentation = {
    active?: boolean | undefined;
    selected?: HistorySelection | undefined;
    select(selected?: HistorySelection): void;
};
/** Presentation identifiers only; the current config store still owns access. */
export declare function historySelection(value: unknown): HistorySelection | undefined;
export declare const historySelectionKey: ({ side, id }: HistorySelection) => string;
/** Use the host's navigation owner, never a separate dialog history stack. */
export declare function historyPresentation(navigation: Navigation, selected: HistorySelection | undefined, target: (selected?: HistorySelection) => OpenTarget, active?: boolean): HistoryPresentation;
