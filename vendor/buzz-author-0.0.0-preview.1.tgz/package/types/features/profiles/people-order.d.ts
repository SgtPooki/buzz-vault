type Person = {
    name: string;
    pubkey: string;
};
/** Match quality by the shared name rule, then name, then key. */
export declare function peopleOrder(query: string): (a: Person, b: Person) => number;
export {};
