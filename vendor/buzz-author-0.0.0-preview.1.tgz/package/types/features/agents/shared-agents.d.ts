import type { EventData } from "../relay/events";
export type SharedAgent = {
    /** `owner:d`, unique per publisher and catalog slug. */
    id: string;
    name: string;
    owner: string;
    picture?: string;
    model: string;
    runtime?: string;
    provider?: string;
    instructions: string;
};
/** The agents a community's catalog events currently share, by name. NIP-33
 * picks the head per (owner, d) first, so an unshared or invalid replacement
 * hides older shared heads rather than reviving them. */
export declare function sharedAgents(events: readonly EventData[]): SharedAgent[];
