import type { NameProvider, NamingPolicy } from "./service";
import type { LocalAgents } from "../agents/local";
/** Local agent names win only in their community. Names never grant control. */
export declare function createNameProvider(policy: NamingPolicy, local?: LocalAgents): NameProvider;
