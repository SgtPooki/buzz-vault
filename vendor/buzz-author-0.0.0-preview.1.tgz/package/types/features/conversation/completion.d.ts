import type { Contribution } from "../../plugins/contributions";
import type { ComposerCompletion, ComposerObservation, CompletionContext, CompletionQuery, CompletionResult } from "./contracts";
export declare function matchCompletion(providers: readonly Contribution<ComposerCompletion>[], observation: ComposerObservation, context: CompletionContext, resolved?: readonly Readonly<{
    start: number;
    end: number;
}>[]): {
    provider: Contribution<ComposerCompletion>;
    query: CompletionQuery;
} | undefined;
/** Copy edit primitives so later provider mutation cannot retarget a displayed choice. */
export declare function completionResult(result: CompletionResult): CompletionResult;
/**
 * How long a pending mention waits for the evidence Space needed, counted
 * once per name: the provider bounds its own `CompletionPending.resolve` by
 * it (one membership read, one profile batch, one inventory read and one
 * directory page, each a single relay round trip with no typing debounce),
 * and the host holds each longer name a chip extends into to the same bound.
 * Expiry returns the name to prose. Bounds both the chip and a send that
 * waits on it.
 */
export declare const MENTION_RESOLVE_TIMEOUT_MS = 8000;
