import type { RelayWriter } from "../relay/transport";
import type { EventData, ReadFilter, RelayEvent } from "../relay/events";
export declare const ARTIFACT_KIND = 45010;
export type ArtifactType = "buzz.agent.settings" | "buzz.agent.instructions" | "buzz.team";
export declare const ARTIFACT_MAX_CONTENT_BYTES = 131072;
export declare const SETTINGS_MAX_CONTENT_BYTES = 65535;
/** The largest complete signed event the relay takes: its default 512 KiB
 * WebSocket frame less the `["EVENT",…]` wrapper. Mirrors
 * `ARTIFACT_MAX_EVENT_BYTES` in `src-tauri/src/relay.rs`. */
export declare const ARTIFACT_MAX_EVENT_BYTES: number;
/** RFC 4122 UUIDv5 of `name` in `namespace`. */
export declare function uuidv5(namespace: string, name: string): Promise<string>;
/** The artifact's immutable `d`: UUIDv5 of the type in the channel's namespace. */
export declare const artifactD: (type: ArtifactType, channel: string) => Promise<string>;
export type Expected = Readonly<{
    channel: string;
    type: ArtifactType;
    d: string;
    /** For `buzz.team`: the selected team's id, from `expectedTeam`. */
    team?: string;
}>;
/** A team config channel's subject label (NIP-AP "Config channels"). */
export declare function teamLabel(team: string): Promise<string>;
/** The team id to expect in a channel, once its subject label is proven to be
 * the channel's. Throws for a malformed id or a label from another team. */
export declare function expectedTeam(team: string, channelLabel: string): Promise<string>;
export declare const artifactOp: (event: EventData) => string | undefined;
export declare const artifactPrev: (event: EventData) => string | undefined;
/** Why a revision is invalid for its config channel, or undefined when valid
 * (NIP-AP "Config artifacts"). A deletion is valid with empty content. */
export declare function artifactProblem(event: EventData, expected: Expected): "Artifact content contains U+0000" | "Artifact content is not JSON" | "Artifact content is not an object" | "Artifact content is too large" | "Artifact home mismatch" | "Artifact identity mismatch" | "Artifact type mismatch" | "Instructions contain U+0000" | "Instructions text missing" | "Malformed deletion" | "Malformed team" | "Not an artifact" | "Settings missing" | "Team does not match this config channel" | "Too many tags" | "Unknown artifact operation" | "Unknown artifact version" | "Unsupported artifact envelope" | undefined;
/** A returned revision checked against the selected channel, `d` and type
 * before anything installs it: one that fails is the invalid head. Every path
 * that installs a head (sync, save, migration, recovery) goes through this. */
export declare const checkedHead: (event: RelayEvent, expected: Expected) => {
    readonly kind: "head";
    readonly event: import("nostr-tools").VerifiedEvent;
    readonly problem: "Artifact content contains U+0000" | "Artifact content is not JSON" | "Artifact content is not an object" | "Artifact content is too large" | "Artifact home mismatch" | "Artifact identity mismatch" | "Artifact type mismatch" | "Instructions contain U+0000" | "Instructions text missing" | "Malformed deletion" | "Malformed team" | "Not an artifact" | "Settings missing" | "Team does not match this config channel" | "Too many tags" | "Unknown artifact operation" | "Unknown artifact version" | "Unsupported artifact envelope";
} | {
    readonly problem?: never;
    readonly kind: "head";
    readonly event: import("nostr-tools").VerifiedEvent;
};
/** One revision to sign. `content` is the complete snapshot; `extra` carries
 * preserved client tags (e.g. `team`). */
export declare function artifactTemplate(input: Expected & {
    op: "create" | "update" | "restore";
    title: string;
    content: string;
    prev?: string;
    extra?: readonly (readonly string[])[];
}): {
    kind: number;
    created_at: number;
    content: string;
    tags: string[][];
};
/** Bytes of the complete signed event as sent, checked against
 * `ARTIFACT_MAX_EVENT_BYTES` before dispatch. */
export declare const signedEventBytes: (event: RelayEvent) => number;
/** The relay's answer to one query, and nothing else: signature-verified,
 * access-checked, in the relay's order, with no merged live observations or
 * local outgoing events. Ordinary `session.read` merges both and so cannot
 * stand in for it. */
export type SnapshotRead = (filters: readonly ReadFilter[], options: {
    signal?: AbortSignal | undefined;
}) => Promise<readonly RelayEvent[]>;
/** The explicit current-heads query. The relay's artifact parser takes only
 * `artifact`, `kinds`, `limit`, `offset` and `#tag` keys, and already reads
 * from the writer pool, so it carries no `consistency`. */
export declare const currentFilter: (channel: string) => ReadFilter;
/** Current heads in a channel, by `d`. Omits deletions and redacted heads; a
 * returned head is authoritative even when its history is unreadable. Two
 * heads for one `d`, or a full page, decide nothing: undefined. */
export declare function readCurrent(read: SnapshotRead, channel: string, signal?: AbortSignal): Promise<Map<string, import("nostr-tools").VerifiedEvent> | undefined>;
/** The head by `d` in `channel`, including a deletion. Empty, or anything but
 * one revision of `d`, decides nothing. The relay leaves system channels out
 * of any read whose `#h` does not name them (NIP-CL), members included. */
export declare function readHead(read: SnapshotRead, channel: string, d: string, signal?: AbortSignal): Promise<import("nostr-tools").VerifiedEvent | undefined>;
export type Refusal = "conflict" | "duplicate" | "permission" | "archived" | "too-large" | "invalid" | "rate-limited" | "unknown";
/** A relay refusal by its machine-readable prefix, never by HTTP status alone. */
export declare function refusal(message: string): Refusal;
export type Delivery = Readonly<{
    status: "accepted";
    event: RelayEvent;
}> | Readonly<{
    status: "refused";
    event: RelayEvent;
    refusal: Refusal;
    message: string;
}> | Readonly<{
    status: "uncertain";
    event: RelayEvent;
    message: string;
}>;
/** Sends one signed revision. Only an OK or duplicate-OK proves acceptance; a
 * failure without a typed refusal leaves it uncertain, never rejected. An
 * event over the relay's size limit (`maxEventBytes`, from its NIP-11
 * document) is refused before dispatch. */
export declare function deliver(writer: RelayWriter, event: RelayEvent, signal: AbortSignal, maxEventBytes?: number): Promise<Delivery>;
/** After acceptance, whether the accepted revision is the head. An older
 * accepted replay is superseded and never installed; no readable head leaves
 * the caller with acceptance only. */
export declare function settle(read: SnapshotRead, event: RelayEvent, signal?: AbortSignal): Promise<{
    status: "accepted-unavailable";
    head?: never;
} | {
    status: "current";
    head: import("nostr-tools").VerifiedEvent;
} | {
    status: "superseded";
    head: import("nostr-tools").VerifiedEvent;
}>;
