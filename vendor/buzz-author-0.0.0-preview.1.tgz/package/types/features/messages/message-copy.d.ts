import type { ChannelMessage } from "../relay/contracts";
import { profileMentionParts } from "./profile-mentions";
export declare function messageCopyText(row: ChannelMessage, profiles: Parameters<typeof profileMentionParts>[1], agents: Parameters<typeof profileMentionParts>[2]): string;
export declare function messageCopyLink(row: ChannelMessage, scope: string | undefined): string | undefined;
