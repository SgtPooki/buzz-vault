import type { AgentLibrary, AgentLibraryReader } from "./library";
/** Preserve local names/artwork; add relay-only keys. Names never join identities. */
export declare function combineInventory(local: AgentLibrary, relay: AgentLibrary): AgentLibrary;
/** A failed source must not erase the other source's usable inventory. */
export declare function inventoryReader(local: AgentLibraryReader | undefined, relay: AgentLibraryReader): AgentLibraryReader;
