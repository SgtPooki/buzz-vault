import type { ChannelMessage } from "../relay/contracts";
/** Only consecutive agent-only messages on one local day fold together.
 * Human messages, public agent replies and membership notices stay visible. */
export declare function activityRuns(rows: readonly ChannelMessage[], requests?: ReadonlyMap<string, string>): ChannelMessage[][];
