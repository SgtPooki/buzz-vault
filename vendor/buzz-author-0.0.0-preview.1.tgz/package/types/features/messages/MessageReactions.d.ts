import type { ComposerTool, ContributionReader, InlineRenderer } from "../conversation/contracts";
import type { ChannelMessage, Profile } from "../relay/contracts";
import type { RelaySession } from "../relay/session";
type Props = {
    row: ChannelMessage;
    session: RelaySession;
    scope: string;
    disabled: boolean;
    tools: ContributionReader<ComposerTool>;
    inline: ContributionReader<InlineRenderer>;
};
/** The emoji contribution owns the single reaction-picker action. */
export declare function MessageReactionControls(props: Props): import("react").JSX.Element;
/** Always mounted under the message so failed add/remove operations stay recoverable. */
export declare function MessageReactions(props: Props & {
    onFocusedRemoval?: () => void;
    profiles?: ReadonlyMap<string, Profile>;
}): import("react").JSX.Element;
export {};
