import type { ReactNode } from "react";
/** Live-work text sheen. The caller decides when work is live; text stays readable and unchanged for assistive tech. */
export declare function ShimmerText({ active, children, }: {
    active?: boolean;
    children: ReactNode;
}): import("react").JSX.Element;
