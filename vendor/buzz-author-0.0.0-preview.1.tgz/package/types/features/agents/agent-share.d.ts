import { type EventData } from "../relay/events";
import type { RelaySession } from "../relay/session";
import type { Agent, RegisteredAgentType } from "./service";
import type { SharedAgent } from "./shared-agents";
/** A shared agent apart from who shared it. */
export type SharedDefinition = Omit<SharedAgent, "id" | "owner">;
export declare const MAX_PNG_BYTES: number;
/** Refuses a name or instructions block/buzz would refuse. */
export declare function checkText(name: string, instructions: string): void;
/** What sharing or exporting `agent` publishes. */
export declare function shareable(agent: Agent, type: RegisteredAgentType | undefined): SharedDefinition;
/** A kind 30175 body, in NIP-AP field order. Agents here run on stock
 * transport, which a shared head names. */
export declare function catalogContent(definition: SharedDefinition): string;
/** The owner's newest catalog head for the agent, which is addressed by its
 * pubkey. The relay shows an author their own unshared heads. */
export declare function catalogHead(session: Pick<RelaySession, "read">, owner: string, pubkey: string, signal: AbortSignal): Promise<EventData | undefined>;
export declare const isShared: (head: EventData | undefined) => boolean;
/** Replaces `head` with `content`, shared or not, and settles with the new head
 * once the relay accepts it. Unshared, the relay keeps it from everyone but its
 * author. */
export declare function publishShare(session: Pick<RelaySession, "outbox">, pubkey: string, content: string, shared: boolean, head: EventData | undefined, signal: AbortSignal): Promise<EventData>;
/** Takes a deleted agent's catalog share down: a shared head is replaced
 * by its content without the tag, which supersedes it whatever its clock, and
 * this settles once a fresh read no longer finds it shared. */
export declare function unshare(session: Pick<RelaySession, "read" | "outbox">, owner: string, pubkey: string, signal: AbortSignal): Promise<void>;
/** A buzz-agent-snapshot v1 `.agent.json` without memory. */
export declare function snapshotJson(definition: SharedDefinition): string;
/** A buzz-agent-snapshot v1 `.agent.png`: `artwork`, a PNG, with the manifest
 * in a `buzz_agent_snapshot` tEXt chunk and none of the artwork's metadata. */
export declare function snapshotPng(definition: SharedDefinition, artwork?: Uint8Array<ArrayBuffer>): Blob;
/** Reads an `.agent.json` or `.agent.png` snapshot, refusing an oversized one
 * before reading it in. What a Buzz agent has no place for, such as memory or
 * an inline avatar, stays behind. */
export declare function readSnapshot(file: Blob): Promise<SharedDefinition>;
