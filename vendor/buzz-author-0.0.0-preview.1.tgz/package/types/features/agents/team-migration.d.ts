import type { AgentStore } from "./store";
import type { TeamSent } from "./team-ops";
export declare const TEAM_MOVES_KEY = "buzz.agents.teams.migration.v1";
/** A move under way: its community, fixed before the first write.
 * `attempted`: what a try sent in its first save, which may have created the
 * relay team; none once that save was definitely refused. `created` once this
 * device's create is confirmed. */
export type TeamMove = Readonly<{
    community: string;
    failed?: true;
    attempted?: TeamSent;
    created?: true;
}>;
/** Why a team stays on this device. */
export type LocalReason = "communities" | "unsupported" | "failed";
/** Where a team or agent's config lives, for its sync status line.
 * `conflict`: a different copy of the team is already in that community. */
export type SyncState = Readonly<{
    synced: string;
}> | Readonly<{
    local: LocalReason | undefined;
}> | Readonly<{
    conflict: string;
}>;
/** Where a team of `members` moves: the one community every member is the
 * owner's agent in, unless the team's move began in another. Staying, the
 * community it would move to, if any. */
export declare function moveHome(members: readonly string[], homesOf: (pubkey: string) => readonly string[], move: TeamMove | undefined): Readonly<{
    home: string;
}> | Readonly<{
    stay: "communities";
}> | Readonly<{
    stay: "none";
    home?: string;
}>;
/** The moves under way, by local team id. Writes run one at a time, each
 * saving what memory holds then; a refused one puts back only its own
 * entry, as last saved. */
export declare class TeamMoves {
    private readonly storage;
    private moves;
    private saved;
    private writing;
    constructor(storage: AgentStore);
    get: (id: string) => TeamMove | undefined;
    /** Saves `move` for team `id`, or that it is done; settles once saved. */
    set(id: string, move: TeamMove | undefined): Promise<void>;
}
/** A sync status line: where it lives, and why it is only here. */
export declare function syncText(state: SyncState | undefined, of: "team" | "agent"): SyncLine | undefined;
export type SyncLine = Readonly<{
    title: string;
    reason?: string;
}>;
