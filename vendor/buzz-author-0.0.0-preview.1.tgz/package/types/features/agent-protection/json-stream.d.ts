/** A replayable text source. Reading is pull-based; consumers own model capacity. */
export type TextSource = Readonly<{
    read(): AsyncIterable<string>;
}>;
export type ReviewText = string | TextSource;
export declare const TEXT_CHUNK_UNITS: number;
export declare const isTextSource: (value: unknown) => value is TextSource;
export declare function textPieces(text: string): Generator<string, void, unknown>;
/** JSON encoding without constructing a second whole serialized payload. A
 * TextSource is a JSON string, escaped piece by piece. Inputs are JSON values;
 * sources must emit complete Unicode scalars, as TextDecoder's streaming mode does. */
export declare function jsonPieces(value: unknown): AsyncGenerator<string>;
/** Coalesce tiny JSON tokens into bounded writes. */
export declare function jsonLines(value: unknown): AsyncGenerator<string>;
type Writer = {
    write(data: string): Promise<void>;
    writeStream?(data: AsyncIterable<string>): Promise<void>;
};
export declare function writeJSON(process: Writer, value: unknown): Promise<void>;
/** Own object snapshots while keeping trusted replay sources out of JSON cloning. */
export declare function snapshotJSON(value: unknown): unknown;
export {};
