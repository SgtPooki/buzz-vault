import { Service, type Context } from "@deepseek-ai/cordis";
import type { ComponentType } from "react";
import type { ChannelSummary } from "../relay/contracts";
import type { RelaySession } from "../relay/session";
import { type Contribution, type MatchOrder } from "../../plugins/contributions";
export type PanelContext = Readonly<{
    /** Originating conversation, not a claim of thread-level scope or access. */
    channelId: string;
    /** Thread root of the message the panel was opened from, when there is one. */
    rootId?: string;
    canOpen(target: string): boolean;
    /**
     * Open a target through the host. A tab replaces itself; a channel drawer or
     * side column opens the target as a tab. False after this opening is retired.
     */
    open(target: string): boolean;
    /** Drill into a child while the channel host retains the previous view. */
    push?(target: string): boolean;
}>;
/** Public presentation context, not authentication or a live selection service. */
export type ChannelPanelContext = Readonly<{
    scope: string;
    channelId: string;
    channelName: string;
    viewer: string;
    relayUrl: string;
    threadId?: string;
}>;
export type ChannelLauncherProps = {
    context: ChannelPanelContext;
    pressed: boolean;
    /** Open the current conversation’s host-owned member picker. */
    openMembers?: (() => void) | undefined;
    /** Toggles this exact contribution in the page-owned channel panel. */
    toggle(target: string): void;
    /** False after this page binding or exact contribution is retired. */
    available(): boolean;
    /** Presentation only; the page re-resolves targets when opening. */
    canOpen(target: string): boolean;
    /** Open another target, such as a panel URL, as a tab in this channel.
     * False after this page binding or exact contribution is retired. */
    open(target: string): boolean;
};
export type PanelProps = {
    /** Supplied only by a channel presentation; sessions decide when to capture it. */
    channelContext?: ChannelPanelContext | undefined;
    close(): void;
    target: string;
    context?: PanelContext | undefined;
};
export type Panel = Readonly<{
    id: string;
    title: string;
    matches: (url: string) => boolean;
    /** Claim strength when several panels match a target; see `MatchOrder`. */
    order?: MatchOrder | undefined;
    launcher?: Readonly<{
        icon: string;
        target: string;
    }>;
    /** Optional live controls beside shell search; lifetime remains plugin-owned. */
    toolbar?: ComponentType;
    channelLauncher?: ComponentType<ChannelLauncherProps>;
    /** Optional Channels menu placement; eligibility is presentation-only, not access. */
    channelMenu?: Readonly<{
        label: string;
        eligible(channel: ChannelSummary, session: RelaySession): boolean;
    }>;
    /**
     * Channel launchers default to the bottom drawer; side reuses the companion
     * column; tab opens a tab in the channel's side pane beside its threads.
     */
    channelPlacement?: "bottom" | "side" | "tab";
    /** Tabs opened from links stay until closed, like a channel tool's, instead
     * of giving way to the next link or thread. */
    keepOpen?: boolean;
    /** Mount tab content on first selection, then retain it for the workspace visit.
     * Component-provided titles and local detail tabs are also deferred. */
    deferUntilShown?: boolean;
    component: ComponentType<PanelProps>;
}>;
export type RegisteredPanel = Contribution<Panel>;
export type PanelOpening = {
    channelId: string;
    /** Thread root of the message the opening link was in. */
    rootId?: string;
    panel: RegisteredPanel;
    target: string;
    channelContext?: ChannelPanelContext;
};
/** The panel a link opens, kept in the thread it was opened from. */
export declare const panelOpening: (panels: Pick<Panels, "resolve">, channelId: string, target: string, rootId?: string) => PanelOpening | undefined;
/** A target to open beside a conversation, as if the viewer clicked a link
 * to it there. */
export type PanelOpenRequest = Readonly<{
    target: string;
    channelId: string;
    /** The thread it is opened from, absent at the channel's top level. */
    rootId?: string;
}>;
export type Panels = {
    register(panel: Panel): void;
    resolve(target: string): RegisteredPanel | undefined;
    snapshot(): readonly RegisteredPanel[];
    subscribe(listener: () => void): () => void;
    /** Opens `request.target` beside its conversation if a page shows that
     * channel now; false when none does or no panel handles the target. */
    requestOpen(request: PanelOpenRequest): boolean;
    /** A page showing conversations answers open requests while it does. */
    handleOpenRequests(handler: (request: PanelOpenRequest) => boolean): () => void;
};
declare module "@deepseek-ai/cordis" {
    interface Context {
        panels: Panels;
    }
}
export declare class PanelsService extends Service implements Panels {
    private readonly panels;
    constructor(ctx: Context);
    private readonly openHandlers;
    snapshot: () => readonly Readonly<Readonly<{
        id: string;
        title: string;
        matches: (url: string) => boolean;
        /** Claim strength when several panels match a target; see `MatchOrder`. */
        order?: MatchOrder | undefined;
        launcher?: Readonly<{
            icon: string;
            target: string;
        }>;
        /** Optional live controls beside shell search; lifetime remains plugin-owned. */
        toolbar?: ComponentType;
        channelLauncher?: ComponentType<ChannelLauncherProps>;
        /** Optional Channels menu placement; eligibility is presentation-only, not access. */
        channelMenu?: Readonly<{
            label: string;
            eligible(channel: ChannelSummary, session: RelaySession): boolean;
        }>;
        /**
         * Channel launchers default to the bottom drawer; side reuses the companion
         * column; tab opens a tab in the channel's side pane beside its threads.
         */
        channelPlacement?: "bottom" | "side" | "tab";
        /** Tabs opened from links stay until closed, like a channel tool's, instead
         * of giving way to the next link or thread. */
        keepOpen?: boolean;
        /** Mount tab content on first selection, then retain it for the workspace visit.
         * Component-provided titles and local detail tabs are also deferred. */
        deferUntilShown?: boolean;
        component: ComponentType<PanelProps>;
    }> & {
        key: string;
        pluginId: string;
        revision: string;
    }>[];
    subscribe: (listener: () => void) => () => void;
    requestOpen: (request: PanelOpenRequest) => boolean;
    handleOpenRequests: (handler: (request: PanelOpenRequest) => boolean) => () => void;
    resolve: (target: string) => Readonly<Readonly<{
        id: string;
        title: string;
        matches: (url: string) => boolean;
        /** Claim strength when several panels match a target; see `MatchOrder`. */
        order?: MatchOrder | undefined;
        launcher?: Readonly<{
            icon: string;
            target: string;
        }>;
        /** Optional live controls beside shell search; lifetime remains plugin-owned. */
        toolbar?: ComponentType;
        channelLauncher?: ComponentType<ChannelLauncherProps>;
        /** Optional Channels menu placement; eligibility is presentation-only, not access. */
        channelMenu?: Readonly<{
            label: string;
            eligible(channel: ChannelSummary, session: RelaySession): boolean;
        }>;
        /**
         * Channel launchers default to the bottom drawer; side reuses the companion
         * column; tab opens a tab in the channel's side pane beside its threads.
         */
        channelPlacement?: "bottom" | "side" | "tab";
        /** Tabs opened from links stay until closed, like a channel tool's, instead
         * of giving way to the next link or thread. */
        keepOpen?: boolean;
        /** Mount tab content on first selection, then retain it for the workspace visit.
         * Component-provided titles and local detail tabs are also deferred. */
        deferUntilShown?: boolean;
        component: ComponentType<PanelProps>;
    }> & {
        key: string;
        pluginId: string;
        revision: string;
    }> | undefined;
    register(panel: Panel): void;
}
