import type { RecoveryStatus } from "./recovery";
import type { LiveSnapshot } from "./live";
/** The parts of a session's live view that recovery classifies. */
export type LiveRecoveryView = LiveSnapshot & Readonly<{
    roster: Readonly<{
        state: string;
        transient?: true;
    }>;
    heads: readonly Readonly<{
        channelId?: string;
        state: string;
        transient?: true;
    }>[];
    previews?: "checking" | "suspended";
}>;
/** A route failure that a later attempt can clear. Anything not known to
 * need action counts: relays use other and unprefixed reasons for outages,
 * and a capped retry costs little next to a live view that never recovers. */
export declare function isTransientLiveError(reason: string | undefined): boolean;
/** How the live layer looks to session recovery. Only failures a retry can
 * fix count as failed. A sign-in error or a denial is settled here and stays
 * visible in live status instead; the live layer retries it slowly itself. */
export declare function liveRecoveryStatus(view: LiveRecoveryView): RecoveryStatus;
type LiveRead = Readonly<{
    state: string;
    transient?: true;
}>;
/** True while session recovery retries the roster read (failed or busy in
 * liveRecoveryStatus), so recovery reports a list error. A denial is not. */
export declare const rosterRecovering: (roster: LiveRead) => boolean;
/** The same for one channel's timeline: true while the live source is not
 * settled for that channel. That covers its head read failing transiently or
 * in flight, and the handoff after a dropped stream: catch-up entries are
 * cleared until the channel's route re-establishes, which reads its head
 * again. */
export declare function headRecovering(view: LiveRecoveryView, channelId: string): boolean;
export {};
