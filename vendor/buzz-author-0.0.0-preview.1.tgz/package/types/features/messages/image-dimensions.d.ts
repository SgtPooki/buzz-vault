import type { Attachment } from "../relay/contracts";
import type { RelaySession } from "../relay/session";
type Dimensions = NonNullable<Attachment["dimensions"]>;
export declare function imageDimensions(session: RelaySession | undefined, source: string | undefined): Readonly<{
    width: number;
    height: number;
}> | undefined;
export declare function rememberImageDimensions(session: RelaySession | undefined, source: string, dimensions: Dimensions): void;
export {};
