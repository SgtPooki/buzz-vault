export declare function migrateAgentFlag(flags: Record<string, boolean>): void;
