import type { AgentLibrary } from "./library";
import type { Profile } from "../relay/contracts";
/** Exact keys from self-declared profile hints plus the local Buzz library.
 * Display-only evidence, not proof of ownership, membership or authority. */
export declare function knownAgentPubkeys(profiles: ReadonlyMap<string, Profile>, library?: AgentLibrary): ReadonlySet<string>;
