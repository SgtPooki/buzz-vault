import type { LocalAgentSource } from "../agents/local-activity";
import type { LocalAgents } from "../agents/local";
import type { IdentityNames } from "../identity-names/service";
import type { PresenceActivity } from "../presence/activity";
import type { Context } from "@deepseek-ai/cordis";
import { type RelaySession } from "./session";
import type { ReadTransport } from "./transport";
import { type CommunityRefusal } from "./http-admission";
export type RelaySnapshot = Readonly<{
    status: "disconnected" | "connecting" | "ready" | "error";
    generation: number;
    /** The persistence partition, `origin:viewer`. */
    scope?: string;
    /** The community's normalized origin, as `scope` was built from. */
    origin?: string;
    session: RelaySession;
    viewer?: string;
    error?: string;
    /** A usable device snapshot while the real transport is connecting/unavailable. */
    cached?: true;
    /** Only local disk bootstrap is pending; never waits for the network. */
    restoring?: true;
    /** This error is transient: the service reconnects without anyone acting. */
    retrying?: true;
    /** The community refused this account; not a connection problem. */
    denied?: true;
    /** Why, when the relay said: its sign-in ended, or it has no access. */
    refusal?: CommunityRefusal;
}>;
export type RelayData = {
    snapshot(): RelaySnapshot;
    subscribe(listener: () => void): () => void;
    retry(): void;
    disconnect(): void;
    clearCache(): Promise<void>;
};
declare module "@deepseek-ai/cordis" {
    interface Context {
        relay: RelayData;
    }
}
/** App-owned session. Plugins receive read models, never a signer or transport.
 * Reconnection replaces the session and invalidates all old async work. */
export declare function provideRelay(ctx: Context, connect?: (signal: AbortSignal) => Promise<ReadTransport>, presenceActivity?: PresenceActivity, identityNames?: IdentityNames, agentChoices?: LocalAgents, resume?: {
    viewer: string;
    scope: string;
}, localAgents?: LocalAgentSource, verifyStored?: ReadTransport["verifyStored"]): RelayData & {
    /** The federated session changed to signed in: retry what it refused. */
    reauthorize(): void;
};
