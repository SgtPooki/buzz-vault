import type { ChannelDetailsDraft } from "../relay/channel-details-protocol";
export declare const generalAccessOptions: {
    readonly private: {
        readonly value: "private";
        readonly label: "Private";
        readonly description: "Only people you add can access.";
    };
    readonly "view-only": {
        readonly value: "view-only";
        readonly label: "View only";
        readonly description: "Anyone in the community can read.";
    };
    readonly public: {
        readonly value: "public";
        readonly label: "Public";
        readonly description: "Anyone in the community can participate.";
    };
};
export type GeneralAccess = keyof typeof generalAccessOptions;
type Policy = Pick<ChannelDetailsDraft, "visibility" | "joinRole">;
export declare function generalAccessValue(policy: Policy): GeneralAccess;
/** Private retains the admission default; open policies state it explicitly. */
export declare function generalAccessPolicy(access: GeneralAccess, joinRole: Policy["joinRole"]): Policy;
export {};
