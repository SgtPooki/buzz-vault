/** The host validates the source again and owns authenticated bytes and clipboard. */
export declare function copyNativeImage(source: string): Promise<void>;
