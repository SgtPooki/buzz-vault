import type { ChannelMessage, ChannelSummary } from "../relay/contracts";
import type { RelaySession } from "../relay/session";
import type { PortableAgent } from "./native";
import type { Agents, RegisteredAgentType } from "./service";
export declare function connectionDraft(candidate: PortableAgent, types: readonly RegisteredAgentType[]): {
    type: string;
    config: unknown;
} | undefined;
/** Latest explicit mention per agent, limited to the viewer's delivered messages. */
export declare function connectionMentions(rows: readonly ChannelMessage[], viewer: string): Map<string, Readonly<{
    id: string;
    channelId: string;
    delivery?: import("../relay/outbox").Delivery | undefined;
    deliveryError?: string | undefined;
    authorId: string;
    signerId?: string | undefined;
    workflowOwnerId?: string | undefined;
    createdAt: number;
    createdAtMs?: number;
    content: string;
    sourceContent?: string;
    agentEnvelope?: true;
    audience?: "agents";
    request?: string;
    notice?: "execution-failure";
    diff?: Readonly<{
        filePath?: string | undefined;
        repoUrl?: string | undefined;
        commitSha?: string | undefined;
        description?: string | undefined;
        truncated: boolean;
    }>;
    membership?: import("../relay/contracts").MembershipChange;
    pluginRequest?: Readonly<{
        id: string;
    }>;
    huddle?: Readonly<{
        room: string;
        state: "started" | "ended";
        endedAt?: number;
    }>;
    edited?: true;
    attachmentSeams?: readonly number[];
    mentions: readonly string[];
    mentionReferences?: readonly string[];
    attachmentSourceId?: string;
    attachments: readonly import("../relay/contracts").Attachment[];
    emoji?: readonly import("../relay/emoji").CustomEmoji[];
    reactions: readonly import("../relay/contracts").MessageReaction[];
    threadRootId?: string | undefined;
    replyParentId?: string | undefined;
    mediaTargetUrl?: string | undefined;
    sentFromThread?: Readonly<{
        rootId: string;
        excerpt?: string | undefined;
    }> | undefined;
    replyCount: number;
    participants: readonly string[];
}>>;
/** A local setup message: never a relay event or an agent-authored response. */
export declare function AgentConnectionSetup({ session, channel, rows, }: {
    session: RelaySession;
    channel: ChannelSummary | undefined;
    rows?: readonly ChannelMessage[];
}): import("react").JSX.Element | null;
export declare function AgentConnectionForm({ agents, candidate, scope, onDismiss, onStart, onFinish, preview, onSendAgain, }: {
    agents: Agents;
    candidate: PortableAgent;
    scope: string;
    onDismiss?: () => void;
    onStart?: () => void;
    onFinish?: (success: boolean, error?: string) => void;
    preview?: boolean;
    onSendAgain?: (() => Promise<void>) | undefined;
}): import("react").JSX.Element;
