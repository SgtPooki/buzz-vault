export type MentionRecipient = Readonly<{
    pubkey: string;
    name: string;
}>;
export type DraftRecipient = MentionRecipient & Readonly<{
    start: number;
    end: number;
}>;
export type ComposerSnapshot = {
    version: 1;
    content: unknown;
};
/** A name Space committed before the chooser could decide. The editor resolves
 * it off-screen into a recipient or back into prose; it is never a recipient. */
export type PendingMention = Readonly<{
    id: string;
    name: string;
    start: number;
    end: number;
}>;
export type MentionDraft = {
    text: string;
    /** Chat links staged above the editor; serialized with the caption. */
    chatCards?: readonly string[];
    /** GIF image Markdown staged in the attachment row; sent after the caption. */
    gifs?: readonly string[];
    recipients: readonly DraftRecipient[];
    /** Projection of the live document only; `mentionDraft()` never restores one. */
    pending?: readonly PendingMention[];
    document?: ComposerSnapshot;
};
export declare const mentionBoundary: (text: string, end: number) => boolean;
/** A key typed straight after a name that selects it as Space does (mentions
 * README §5): Space, or closing punctuation, which stays after the mention in
 * place of the space. Tab, Enter and a click select the highlighted row. */
export declare const mentionTerminator: (key: string) => boolean;
export declare const MAX_DRAFT_GIFS = 10;
/** The lone image Markdown a staged GIF keeps, as the picker writes it. */
export declare function stageableGif(value: unknown): value is string;
/** Old text-only drafts remain text-only: restoring prose never creates notifications. */
export declare function mentionDraft(value: unknown): MentionDraft;
/** What counts as a draft everywhere: text, an attached chat or GIF, or `files`.
 * A typed tag is text the person put there; the composer no longer saves
 * tags of its own, and the ones earlier releases saved are not content. */
export declare function hasDraftContent(value: MentionDraft, files?: number): boolean;
/** A remembered-agent follow-up that a release through preview.177.1 saved
 * as the draft: selected recipients and nothing else, without the editor
 * snapshot every typed draft carries. Relay history seeds it now. */
export declare function legacyFollowupDraft(value: MentionDraft): boolean;
/** Selected recipients and nothing else: no prose outside their spans and no
 * attached chat or GIF. */
export declare function addressingOnly(value: MentionDraft): boolean;
/** Prefill exact, already-selected identities; never infer recipients from prose. */
export declare function followupDraft(recipients: readonly MentionRecipient[]): MentionDraft;
