export declare function supportsImageCopy(): boolean;
export declare function copyImageToClipboard(image: HTMLImageElement): Promise<void>;
