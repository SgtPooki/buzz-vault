export type SettingValue = string | number | boolean;
/** The exact values a setting takes: no aliases, case folding or clamping. */
export type SettingSchema = Readonly<{
    type: "string";
    enum: readonly string[];
}> | Readonly<{
    type: "boolean";
}> | Readonly<{
    type: "integer";
    minimum: number;
    maximum: number;
    multipleOf: number;
}>;
export type DeviceSetting = Readonly<{
    /** Stable, `area.name`. */
    key: string;
    description: string;
    schema: SettingSchema;
    /** When a change takes effect, if not at once. */
    applies?: string;
    /** The live value, and why it is not saved on this device when it isn't. */
    read(): Readonly<{
        value: SettingValue;
        unsaved?: string | null;
    }>;
    /** Applies and saves `value`, which the schema has already admitted. */
    write(value: SettingValue): void;
    /** False once its owner has stopped, when a write would change nothing. */
    live?(): boolean;
}>;
export type SettingState = Readonly<{
    key: string;
    description: string;
    schema: SettingSchema;
    applies?: string;
    value: SettingValue;
    saved: boolean;
    problem?: string;
}>;
export type DeviceSettings = ReturnType<typeof createDeviceSettings>;
export declare function createDeviceSettings(definitions: readonly DeviceSetting[]): {
    list: () => Readonly<{
        key: string;
        description: string;
        schema: SettingSchema;
        applies?: string;
        value: SettingValue;
        saved: boolean;
        problem?: string;
    }>[];
    get: (key: unknown) => Readonly<{
        key: string;
        description: string;
        schema: SettingSchema;
        applies?: string;
        value: SettingValue;
        saved: boolean;
        problem?: string;
    }>;
    /** Sets `key` to `value` when it is exactly one of its values and reads
     * it back; throws otherwise, having changed nothing. Synchronous, so a
     * check just before it holds until it returns. */
    set(key: unknown, value: unknown): SettingState;
};
