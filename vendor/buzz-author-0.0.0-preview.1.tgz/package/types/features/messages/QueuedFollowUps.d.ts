import type { RelaySession } from "../relay/session";
export declare function QueuedFollowUps({ session, channelId, disabled, focusComposer, onEdit, }: {
    session: RelaySession;
    channelId: string;
    disabled: boolean;
    focusComposer(): void;
    onEdit?(id: string): void;
}): import("react").JSX.Element | null;
