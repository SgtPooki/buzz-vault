import type { UploadedAttachment } from "../relay/attachments";
import type { MentionPicks } from "../relay/messages";
export type FollowUpMessage = {
    channelId: string;
    text: string;
    recipients: readonly string[];
    attachments: readonly UploadedAttachment[];
    references: readonly string[];
    picks: MentionPicks;
};
export type SavedFollowUp = FollowUpMessage & {
    id: string;
    createdAt: number;
    sending?: true;
};
export type FollowUpHandoff = {
    id: string;
    message?: string;
    recipients: readonly string[];
    complete?: true;
    owner?: string;
};
export declare const followUpRecovery: (id: string) => {
    key: string;
    value: string;
};
/** Separate view records avoid overwriting another conversation/window's queue. */
export declare function followUpStorage(scope: string): {
    owner(): Promise<string>;
    isLive(handoff: FollowUpHandoff): Promise<boolean>;
    retire(channelId: string): void;
    load(): SavedFollowUp[];
    has(id: string): boolean;
    sending(id: string, sending: boolean): void;
    isSending(id: string): boolean;
    save(value: SavedFollowUp): void;
    remove(id: string): void;
    handoff(channelId: string): FollowUpHandoff | null;
    claim(channelId: string, handoff: FollowUpHandoff): void;
    lockChat<T>(channelId: string, run: () => Promise<T>): Promise<T>;
    tryLock(id: string, run: () => void | Promise<void>): Promise<void>;
    lock<T>(id: string, run: () => Promise<T>): Promise<T>;
};
