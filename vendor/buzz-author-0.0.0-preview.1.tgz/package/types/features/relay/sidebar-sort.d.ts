export type SidebarSortMode = "alpha" | "recent" | `plugin:${string}`;
export declare function isSidebarSortMode(value: unknown): value is SidebarSortMode;
export declare function sidebarSortNeedsActivity(mode: SidebarSortMode): boolean;
