import type { Profile } from "./contracts";
import type { ProfileQueries } from "./profile-directory";
/** Narrow external-store projection. The source may notify broadly; downstream
 * observers are notified only when one of their referenced profile values changes.
 * A replacement selection may start from its predecessor's snapshot, keeping
 * that identity while the selected values are unchanged. */
export declare function selectProfiles(queries: ProfileQueries, ids: readonly string[], previous?: ReadonlyMap<string, Profile>): {
    snapshot: () => ReadonlyMap<string, Readonly<{
        verified?: import("./verified-profile").VerifiedProfile;
        name: string;
        nameIsFallback?: true;
        username?: string;
        picture?: string;
        about?: string;
        nip05?: string;
        isAgent?: true;
        ownerPubkey?: string;
    }>>;
    subscribe(listener: () => void): () => void;
};
