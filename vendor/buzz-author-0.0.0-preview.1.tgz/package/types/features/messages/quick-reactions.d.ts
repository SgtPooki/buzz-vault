/** Clear shortcut preferences saved by older versions when leaving a community. */
export declare function forgetQuickReactions(scope: string): void;
