import type { VerifiedEvent } from "nostr-tools";
/** NIP-AR sync (docs/nips/NIP-AR.md "Sync" in block/buzz): a REQ with one
 * `"artifact": "current"` filter. `#h` is required; paging keys are refused. */
export type ArtifactSyncFilter = Readonly<{
    artifact: "current";
    kinds?: readonly [45010];
    "#h": readonly string[];
    [tag: `#${string}`]: readonly string[] | undefined;
}>;
export declare const ARTIFACT_REVISION_KIND = 45010;
export declare const ARTIFACT_REMOVAL_KIND = 45011;
/** The relay's own `#h` bound for one sync. */
export declare const ARTIFACT_SYNC_MAX_CHANNELS = 256;
/** Open syncs per relay session. The session and the browser broker share it. */
export declare const ARTIFACT_SYNC_MAX_VIEWS = 32;
/** Low-level sink for one REQ on one socket. No retry: the caller owns restart. */
export type ArtifactSyncSink = {
    event(event: VerifiedEvent): void;
    eose(): void;
    /** Relay CLOSED reason, or `disconnected: ...` when the socket went away. */
    closed(reason: string): void;
};
/** Validate and copy a plugin-supplied filter. Throws on anything the relay
 * would refuse, so a bad filter fails at the call site, not as a CLOSED. */
export declare function artifactSyncFilter(input: unknown): ArtifactSyncFilter;
