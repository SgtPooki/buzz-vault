import type { ConversationWake, Trigger } from "../agents/service";
import type { EventData } from "../relay/events";
export type { ConversationWake } from "../agents/service";
export type PluginTrigger = Extract<Trigger, {
    type: "plugin";
}>;
/** The wake as the mention a harness routes by: its channel and thread, and
 * its time. Local only: it is never signed or sent, and its id is the wake's
 * own, which nothing may publish. A harness replies, types and reports in the
 * thread's root, as for a reply there. */
export declare const wakeAnchor: (wake: ConversationWake) => EventData;
/** Whether a wake has a conversation to go to. One with no thread goes only to
 * a Solo chat or an explicitly channel-addressed subscription. Other plugin
 * wakes require a thread, so they never answer at the synthetic anchor. */
export declare const wakeLands: (wake: ConversationWake, topLevel: boolean) => boolean;
/** `text` that is not Buzz's own: its lines cannot open the turn's event or
 * steer section, which a turn with a wake in place of its event has none of. */
export declare const unframed: (text: string) => string;
/** The section a wake's turn has in place of `<buzz-event>`. */
export declare function wakeSection(wake: ConversationWake): string;
