/** Budgets of the development broker's single memory query. */
export declare const MEMORY_EVENT_LIMIT = 256;
export declare const MEMORY_WIRE_BYTES: number;
export declare const MEMORY_TEXT_BYTES: number;
export interface MemoryEntry {
    slug: string;
    body: string;
    eventId: string;
    createdAt: number;
}
export interface MemoryListing {
    entries: readonly MemoryEntry[];
    /** Deleted entries' tombstones, which a write recreating one must follow. */
    deleted?: readonly Readonly<{
        slug: string;
        createdAt: number;
    }>[];
    partial: boolean;
}
/** Reads every entry, or only entry `slug` when given. With `onPage`, a
 * reader may report the entries each page adds or changes as it lands. */
export type MemoryReader = (agent: string, signal: AbortSignal, slug?: string, onPage?: (page: MemoryListing) => void) => Promise<MemoryListing>;
export type MemorySnapshot = Readonly<{
    /** `loading` may carry the entries read so far. */
    status: "idle" | "blocked" | "loading" | "ready" | "error" | "denied" | "unavailable";
    listing?: MemoryListing;
}>;
export declare function memoryAgent(agent: unknown, viewer: string): agent is string;
/** NIP-AE address grammar, shared by host evidence and renderer DTO validation. */
export declare function memorySlug(slug: unknown): slug is string;
/** Bound bytes before parsing ciphertext or plaintext responses. */
export declare function memoryResponseText(response: Response): Promise<string>;
/** Forgets every kept listing, fencing reads still in flight from keeping
 * theirs. Sessions, views and runtime reads carry on. */
export declare function forgetMemoryListings(): void;
/** Forgets kept listings whenever the selected community changes: a retained
 * session keeps its owner, but its listings must not outlive the selection. */
export declare function forgetMemoryListingsOnSelection(communities: {
    snapshot(): {
        selected: string | null;
    };
    subscribe(listener: () => void): () => void;
}): () => void;
/** Validate the host DTO before retaining plaintext, including aggregate size. */
export declare function memoryListing(input: unknown): MemoryListing;
/** Merges each streamed page into one listing: a page names its slugs' newest
 * heads, so a later page's entry replaces an earlier one. `cached` entries
 * only fill in until fresh ones arrive; they give way, oldest first, to keep
 * the listing within budget. Each entry is measured once. */
export declare function mergePage(cached: MemoryListing | undefined): (page: MemoryListing) => MemoryListing;
/** How long a closed view's last listing stays in memory, so reopening it
 * shows that listing at once while it reads again. Never stored anywhere. */
export declare const MEMORY_CACHE_MS = 30000;
/** Each mounted consumer owns a view; session retirement revokes every view
 * and drops the listings kept for reopening. */
export declare function createAgentMemories(source: MemoryReader | undefined, viewer: string, available: () => boolean, notify?: (listener: () => void) => void): {
    capability: Readonly<{
        open: (agent: string) => {
            snapshot: () => Readonly<{
                /** `loading` may carry the entries read so far. */
                status: "idle" | "blocked" | "loading" | "ready" | "error" | "denied" | "unavailable";
                listing?: MemoryListing;
            }>;
            subscribe(listener: () => void): () => void;
            refresh(): Promise<void>;
            clear: () => void;
            dispose(): void;
        };
        read: (agent: string, signal: AbortSignal, slug?: string) => Promise<Readonly<{
            /** Deleted entries' tombstones, which a write recreating one must follow. */
            deleted?: readonly Readonly<{
                slug: string;
                createdAt: number;
            }>[];
            partial: boolean;
            entries: readonly MemoryEntry[];
        }>>;
    }>;
    clear(): void;
    dispose(): void;
};
