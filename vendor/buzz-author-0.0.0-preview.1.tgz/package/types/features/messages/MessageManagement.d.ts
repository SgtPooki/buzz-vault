import { type ReactNode } from "react";
import type { ChannelMessage } from "../relay/contracts";
import type { RelaySession } from "../relay/session";
import type { MessageAttention } from "../relay/unread";
type MessageVisit = Readonly<{
    session: RelaySession;
    channelId: string | undefined;
    token: object;
    entryMessageIds: ReadonlySet<string>;
    entryHistoryComplete: boolean;
    entryReadRevision: number;
    entryAttention: ReadonlyMap<string, Pick<MessageAttention, "unread" | "forced"> | null>;
    active: boolean;
    ready: boolean;
    failed: boolean;
}>;
/** The channel visit that owns automatic reading and its entry reconciliation. */
export declare function useMessageVisit(session: RelaySession, channelId: string): MessageVisit | null | undefined;
export declare function useMessageDeletion(): ((row: ChannelMessage, done?: (focus: boolean) => void) => void) | undefined;
/**
 * Selected-message keys act as the message menu does, read when the key is
 * pressed. Delete covers your own messages; the menu also deletes for agent
 * owners, which needs ownership evidence a key cannot wait for.
 */
export declare function useMessageKeyActions(session: RelaySession): {
    canDelete(row: ChannelMessage): boolean;
    remove(row: ChannelMessage): void;
    canMarkUnread(row: ChannelMessage): boolean;
    markUnread(row: ChannelMessage): void;
} | undefined;
/** Recovery stays outside virtualized rows; each conversation has one edit destination. */
export declare function MessageManagement({ session, channelId, active, children, }: {
    session: RelaySession;
    channelId?: string | undefined;
    active?: boolean | undefined;
    children: ReactNode;
}): import("react").JSX.Element;
export declare function MessageReadStateItem({ row, session, }: {
    row: ChannelMessage;
    session: RelaySession;
}): import("react").JSX.Element | null;
export declare function MessageManagementItems({ row, session, }: {
    row: ChannelMessage;
    session: RelaySession;
}): import("react").JSX.Element;
/** Recovery survives a removed row, closed dialog, navigation and restored outbox. */
export declare function MessageManagementStatus(): import("react").JSX.Element | null;
export {};
