import { type BackupFailureKind } from "./backup-failure";
import type { Identity } from "./service";
type Send = <T>(command: string, args?: Record<string, unknown>) => Promise<T>;
/** Hands the native uploader's `builderlab` slot a NIP-FI session: only its
 * public `revision` crosses IPC, and native resolves the token itself. `null`
 * hands the slot back. Resolves to the ticket of the backup pass this handoff
 * starts, or `null` when none will (or the handoff was refused). Never
 * rejects. */
export declare function handoffFederatedBackupSession(revision: string | null, send?: Send): Promise<number | null>;
/** What the native uploader last did for this device's key. `seq` orders
 * statuses; a pass numbered at or above a handoff's ticket started after it. */
export type IdentityManagement = Readonly<{
    pubkey: string;
    policy: "self-managed" | "organization-managed";
    initialBackupConfirmed: boolean;
}>;
export type BackupStatus = Readonly<{
    seq: number;
    pass: number;
    builderlab: boolean;
    management?: IdentityManagement;
} & ({
    status: "idle" | "running" | "complete";
} | {
    status: "waiting";
    reason: "no_consent" | "no_session" | "not_linked";
} | {
    status: "failed";
    kind: "busy" | "signed_out" | "not_offered" | "other_key_linked" | "invalid_service" | "refused" | "unreachable" | "unconfirmed" | "storage";
})>;
/** Nothing is registered until the first `subscribe` or `ready()`. The channel is
 * watched before the snapshot is read and the higher `seq` wins, so a transition
 * between the two is never lost. */
export declare function createBackupStatus(send?: Send): {
    snapshot: () => BackupStatus | undefined;
    ready: () => Promise<Readonly<{
        seq: number;
        pass: number;
        builderlab: boolean;
        management?: IdentityManagement;
    } & {
        status: "idle" | "running" | "complete";
    }> | Readonly<{
        seq: number;
        pass: number;
        builderlab: boolean;
        management?: IdentityManagement;
    } & {
        status: "waiting";
        reason: "no_consent" | "no_session" | "not_linked";
    }> | Readonly<{
        seq: number;
        pass: number;
        builderlab: boolean;
        management?: IdentityManagement;
    } & {
        status: "failed";
        kind: "busy" | "signed_out" | "not_offered" | "other_key_linked" | "invalid_service" | "refused" | "unreachable" | "unconfirmed" | "storage";
    }>>;
    retry: () => Promise<unknown>;
    refresh(): Promise<BackupStatus>;
    subscribe(listener: () => void): () => void;
    dispose(): void;
};
/** A first-run backup that did not complete, with the table's copy as its message. */
export declare class BackupError extends Error {
    readonly kind: BackupFailureKind;
    readonly retryable: boolean;
    constructor(kind: BackupFailureKind);
}
/**
 * Backs `pubkey` up through the native uploader, the only thing that runs a
 * pass: consent on, then the first-run sign-in's NIP-FI session revision
 * handed to the shared `builderlab` slot, whose ticket names the pass to
 * wait for. The first status at or past it that is not `running` answers, or
 * `timeout` does. Consent stays on after a failure, so a later Builderlab
 * sign-in may finish what the user asked for. Continue without backup keeps
 * what was saved: consent after `not_offered`, and no choice on a build that
 * can't back up to Builderlab, which fails before saving one, so
 * `BackupConsent` fills it in once the app opens. The revision is the session
 * the Builderlab plugin hands over too, so after a completed pass it stays in
 * the slot, at the cost of a fresh pass. On any other exit after the handoff
 * the slot is emptied, and Try again hands it over again; a settled pass is
 * not running, so that publishes nothing and the outcome stays visible.
 * Rejects with a `BackupError`.
 */
export declare function backUpWith(identity: Pick<Identity, "backup" | "setBackupChoice">, pubkey: string, revision: string, { timeout, after, send, }?: {
    timeout?: number;
    after?: (ms: number, signal: AbortSignal) => Promise<void>;
    send?: Send;
}): Promise<void>;
export {};
