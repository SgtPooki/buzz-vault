import type { EventData, ReadFilter, RelayEvent } from "./events";
import type { Delivery, OutgoingEvent } from "./outbox";
export type VisibleEvent = EventData & Readonly<{
    delivery?: Delivery;
    error?: string | undefined;
}>;
/** Local eligibility for ordinary NIP-01 filters. Server-ranked search/feed results
 * cannot be inferred locally, so those require a feature-specific projection. */
export declare function matchesEvent(event: EventData, filter: ReadFilter): boolean;
/** A single merge rule for finite reads and subscribed filtered views. */
export declare function projectEvents(remote: readonly RelayEvent[], local: readonly OutgoingEvent[], filters: readonly ReadFilter[], previous?: readonly VisibleEvent[]): readonly VisibleEvent[];
/** Bounded retained evidence for owned views; eviction is chronological, not response-arrival order. */
export declare function retainEvents(events: readonly RelayEvent[]): readonly RelayEvent[];
