import { type Node as EditorNode } from "prosemirror-model";
/** `text` reads well outside the app; `markdown` keeps identity locators and
 * the block syntax the composer understands; `html` is the semantic `text/html`
 * flavor. */
export type CopyFormat = "text" | "markdown" | "html";
/** A spoiler's `||` in the `text/html` flavor: visible text to other
 * consumers, marked so `copyDocument` drops it and authored pipes stay. */
export declare const spoilerDelimiter = "<span data-spoiler-delimiter=\"\">||</span>";
/** Serialize every range of a live selection; ranges join like lines. */
export declare function serializeSelection(selection: Selection, format: CopyFormat): string;
/** Walk a DOM tree, clipped to `range` when given. The DOM is untrusted data:
 * identity travels only on validated `nostr:`, `buzz:` and credential-free
 * `http:` and `https:` destinations, and only when a chip's whole text is selected.
 * Unknown elements degrade to their text. */
export declare function serializeNode(node: Node, format: CopyFormat, range?: Range): string;
/** Engines omit computed `user-select: none` chrome from copies; so do we. */
export declare function unselectable(element: Element): boolean;
/** The editor document this app's semantic HTML parses to: the nodes a paste
 * inserts and the source `markdown` serializes. Only the semantic HTML emitted
 * above reaches the editor parser. Anchors become source tokens, not
 * recipients; the paste host still owns mention acceptance. */
export declare function copyDocument(node: Node, range?: Range): EditorNode;
/** Timeline and thread surfaces share one document listener. */
export declare function useMessageSelectionCopy(): void;
