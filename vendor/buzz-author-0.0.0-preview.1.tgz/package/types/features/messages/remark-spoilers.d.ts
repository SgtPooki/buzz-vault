import type { Handle } from "mdast-util-to-markdown";
declare module "mdast" {
    interface Spoiler extends Parent {
        type: "spoiler";
        children: PhrasingContent[];
    }
    interface PhrasingContentMap {
        spoiler: Spoiler;
    }
    interface RootContentMap {
        spoiler: Spoiler;
    }
}
declare module "mdast-util-to-markdown" {
    interface ConstructNameMap {
        spoiler: "spoiler";
    }
}
export declare const spoilerMarkdown: Handle;
type Node = {
    type: string;
    value?: string;
    children?: Node[];
    data?: {
        hName: string;
        hProperties: Record<string, string>;
    };
};
/** Only source-verified delimiters are protected before Markdown parsing. Escaped
 * pipes, entities, code and table syntax can never become spoilers after decoding. */
export declare function remarkSpoilers(delimiter: string, hideUnclosed?: boolean): (tree: Node) => void;
export {};
