import type { EventData } from "./events";
/** NIP-25: the last valid event reference is the reaction's target. */
export declare function reactionTarget(event: Pick<EventData, "tags">): string | undefined;
