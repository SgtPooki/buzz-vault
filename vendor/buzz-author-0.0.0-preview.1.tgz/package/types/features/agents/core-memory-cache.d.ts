import type { AgentReads } from "./reads";
/** Forgets every cache's copy of each agent's `core` memory for one community
 * and viewer (`origin:viewer`). A read still under way cannot put it back. */
export declare function forgetCoreMemory(scope: string): void;
export declare class CoreMemoryCache {
    /** The reads of each agent's community, while it can be read. */
    private readonly reads;
    private readonly memoryReads;
    /** Each entry's latest writer; an older read finishing later is dropped. */
    private readonly writers;
    private writer;
    private readonly latest;
    constructor(
    /** The reads of each agent's community, while it can be read. */
    reads: (pubkey: string) => AgentReads | undefined);
    /** Drops the in-memory copies under `prefix` and fences reads under way. */
    forget(prefix: string): void;
    /** The agent's `core` memory: its text, `null` when it has none, or
     * undefined when it could not be read. The cached copy needs no relay
     * request; with none cached yet, this waits on one read. Rejects only when
     * `signal` aborts. */
    core(pubkey: string, signal?: AbortSignal): Promise<string | null | undefined>;
    /** Reads it again for the agent's next start, which does not wait on it; a
     * failure only leaves the cached copy as it is. Settles when it is done. */
    refresh(pubkey: string): Promise<void>;
    /** Keeps what the agent just wrote, ahead of any read still under way. */
    wrote(pubkey: string, slug: string, body: string | null): void;
    /** Reads and keeps the `core` memory, unless a partial listing missed it or
     * a later read or write started since. Undefined when the connection was
     * replaced or the agent left it: a new one may read as someone else. */
    private read;
    private claim;
    private key;
}
