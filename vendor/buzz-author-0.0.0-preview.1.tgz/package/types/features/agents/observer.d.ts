import { type RelayEvent } from "../relay/events.ts";
export declare const ACTIVITY_HISTORY_AGE_MS: number;
/** Host-projected telemetry. Never a signed RelayEvent or a general decrypt API. */
export declare const OBSERVER_KIND = 24200;
export declare const OBSERVER_PLAINTEXT_BYTES = 65535;
/** Terminal wire outcomes shared by the live lifecycle and transcript. Missing
 * outcome is the original local-agent completion contract. */
export declare function terminalOutcome(kind: string, outcome: unknown): "ended" | "error" | "stopped" | "unknown" | undefined;
export type ObserverFrame = Readonly<{
    id: string;
    agent: string;
    createdAt: number;
    plaintext: string;
    /** Original owner-encrypted wire envelope; plaintext is never persisted. */
    envelope?: RelayEvent;
}>;
export declare function observerFrame(value: unknown): ObserverFrame;
export declare function observerGeneration(value: unknown): number | null;
