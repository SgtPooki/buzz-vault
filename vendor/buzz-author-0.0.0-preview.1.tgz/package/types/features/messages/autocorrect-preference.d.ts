import type { DeviceSetting } from "../../shared/device-settings";
/** Device-local opt-in to native spelling correction in the message composer. */
export declare function messageAutocorrectPreference(): boolean;
export declare function useMessageAutocorrectPreference(): {
    enabled: boolean;
    unsaved: boolean;
};
export declare function setMessageAutocorrectPreference(enabled: boolean): void;
/** The composer's spelling-correction opt-in as a device setting. */
export declare const autocorrectSetting: DeviceSetting;
