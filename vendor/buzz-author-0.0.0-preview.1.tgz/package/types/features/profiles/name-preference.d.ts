import type { VerifiedProfile } from "../relay/verified-profile";
/** How this device shows people a community has verified. */
export type NamePreference = "username" | "full-name";
/** Device-local; the community's verified display name (the username) by default. */
export declare function namePreference(): NamePreference;
export declare function subscribeNamePreference(listener: () => void): () => void;
export declare function useNamePreference(): NamePreference;
export declare function setNamePreference(value: NamePreference): void;
/** The name a verified person goes by on this device. */
export declare function verifiedLabel(verified: Pick<VerifiedProfile, "displayName" | "fullName">, preference?: NamePreference): string;
/**
 * Shown beside a verified person's `label` (their name on this device, before
 * any namesake qualifier): whichever verified name it is not, if any.
 */
export declare function otherVerifiedName(label: string, verified: {
    username?: string | undefined;
    fullName?: string | undefined;
}): string | undefined;
