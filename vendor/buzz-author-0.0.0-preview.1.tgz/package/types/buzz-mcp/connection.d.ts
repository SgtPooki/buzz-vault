import type { HostMcpServer, McpHandler } from "../features/host/service";
export declare function connectMcp(serve: (handler: McpHandler) => Promise<HostMcpServer>, createHandler: (signal: AbortSignal) => McpHandler, signal: AbortSignal): Promise<HostMcpServer>;
