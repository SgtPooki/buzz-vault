export declare function activityOutcomeLabel(state: string): "Couldn’t finish" | "Stopped" | undefined;
export declare function activityOutcomeReason(state: string, reason?: string): string;
/** Confirmed failure and cancellation share geometry, with distinct meaning. */
export declare function ActivityOutcome({ state, name, }: {
    state: string;
    name?: string | undefined;
}): import("react").JSX.Element | null;
