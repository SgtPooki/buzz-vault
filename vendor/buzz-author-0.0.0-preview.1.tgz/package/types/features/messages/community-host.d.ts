/** The host a community goes by, from its `wss://host` relay or `https://host` origin. */
export declare function communityHost(relay: string): string | undefined;
