import type { AgentStore } from "./state";
/** Converts every stored keyword watch in place, in the legacy shared record
 * and in each agent's own record. A failure must not stop startup, so each
 * failed save is only logged. */
export declare function migrateWatchKeywords(storage: AgentStore, now?: number): Promise<void>;
