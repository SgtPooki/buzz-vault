/** One automatic recovery owner for a relay session's background reads.
 *
 * Each source reports whether it currently shows a failure. While any source
 * fails, recovery retries every failed source with a capped exponential delay.
 * It never gives up. A wake, network or success signal retries at once.
 *
 * Sources are background reads only. User actions (sends, moves, deletes) own
 * their own Retry because repeating them silently could repeat a user intent. */
export type RecoveryStatus = "failed" | "busy" | "settled";
export type RecoverySource = Readonly<{
    status(): RecoveryStatus;
    subscribe(listener: () => void): () => void;
    retry(): void;
    /** Credentials changed: read again after any read already in flight, even
     * one its status does not show (a ready catalog revalidating). Without it,
     * recovery waits out a `busy` read before retrying. */
    reauthorize?(): void;
}>;
export type RecoverySnapshot = Readonly<{
    /** True while at least one source shows a failure. */
    recovering: boolean;
    /** Backoff index. retryNow restarts it; it does not hide the notice. */
    attempt: number;
    /** True once recovery has lasted RECOVERY_NOTICE_DELAY_MS, until every
     * source settles. Kept apart from `attempt` so a manual or signal retry
     * keeps the notice up. */
    shown: boolean;
    /** Counts credential changes (retryAll). A finite read owned outside
     * recovery retries its failure when this moves; see useReauthorizedRetry. */
    reauthorized: number;
}>;
export type RelayRecovery = Readonly<{
    snapshot(): RecoverySnapshot;
    subscribe(listener: () => void): () => void;
    /** Retry failed sources now and restart the delay sequence. `except` skips
     * a source that already owns its own recovery for the triggering event. */
    retryNow(except?: RecoverySource): void;
    /** Credentials changed: retry every source, settled ones included, since a
     * changed credential can clear a refusal recovery deliberately leaves alone.
     * A source busy with a read begun under the old credentials retries again
     * once that read settles, so joining it cannot keep its stale refusal. */
    retryAll(): void;
    dispose(): void;
}>;
/** A background read's state as recovery sees it. Only failures a retry can
 * fix enter recovery; a denial or a deterministic failure stays visible on its
 * own surface (see isTransientFailure). */
export declare const loadState: (state: Readonly<{
    status: string;
    transient?: true | undefined;
}>) => RecoveryStatus;
/** A refusal that federated sign-in can clear: the relay wanted a token. */
export declare const isSignInRefusal: (error: unknown) => boolean;
/** Calls `retry` once credentials change after generation `sent` (a request's
 * `reauthorized` when sent); returns its cancel. */
export declare function reauthorizedOnce(recovery: RelayRecovery, sent: number, retry: () => void): () => void;
export declare const RECOVERY_DELAYS_MS: readonly number[];
/** Recovery shows its notice only once it lasts this long, so a socket blip,
 * a wake from sleep or a failure that the first retries fix stays quiet. Its
 * own timer, not a retry, starts it: a retry that hangs still shows the notice. */
export declare const RECOVERY_NOTICE_DELAY_MS = 30000;
export declare function createRecovery(sources: readonly RecoverySource[], timers?: Readonly<{
    setTimeout(callback: () => void, ms: number): unknown;
    clearTimeout(handle: unknown): void;
}>): RelayRecovery;
