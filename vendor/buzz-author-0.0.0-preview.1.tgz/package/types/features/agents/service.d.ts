import { type AgentExecution, type AgentExecutionBinding, type AgentExecutionProvider, type AgentExecutionSession } from "./execution";
import type { JsonValue } from "../navigation/targets";
import type { ExternalScope } from "./external-connection";
import { type HarnessKit } from "../agent-harness/kit";
import type { HostMcpServer } from "../host/service";
import { type AgentProtection, type ProtectionBinding } from "../agent-protection/service";
import { type SettingsSchema, type Subject } from "./agent-config";
import { type Mode } from "./agent-start";
import { type ConfigBase, type Side } from "./community-config";
import type { Expected, SnapshotRead } from "./agent-config-artifacts";
import type { revertTemplate, SettingsCheck } from "./agent-config-history";
import type { RevertOutcome } from "./AgentConfigHistory";
import { type AgentHook, type AgentHookContext, type AgentHookDispatchOptions } from "./hooks";
import { type AgentStore } from "./state";
import { Service, type Context } from "@deepseek-ai/cordis";
import type { ComponentType, ReactNode } from "react";
import type { DefinedIcon } from "../../shared/design-system/icons";
import { type Contribution } from "../../plugins/contributions";
import { type SyncState } from "./team-migration";
import type { LocalAgentsSnapshot } from "./local";
import type { Communities } from "../communities/service";
import { type NipOaAuthorization } from "../host/service";
import { type RelayEvent } from "../relay/events";
import { channelTabs } from "../../bundled/channels/useChannelTabState";
import type { RelayData } from "../relay/service";
import { type AttentionObject, type AttentionValue, type EventWatch, type Interest, type TimerState, type TimerWatch } from "./attention";
import type { ClassifierAvailability, Shown, WatchFilter, WatchSummary, WriteOptions } from "./attention-objects";
import { type ClassifierOutcome } from "./classifier";
import type { Decisions } from "../decisions/service";
import { type AgentEventTemplate, type Carry, type AgentsNative, type AgentMedia, type AgentUpload, type GitAuth, type OldTeam, type PortableAgents, type PortSource } from "./native";
import { type AgentKey } from "./membership";
import { type AgentRecord, type SkippedObject, type Team } from "./store";
import { type AddedTool } from "../../buzz-mcp/session-tools";
import type { AgentPlugins } from "../../plugins/requests";
import type { DeviceSettings } from "../../shared/device-settings";
/** Where an agent runs: `here`, with its key on this device; `hosted`, by its
 * type's provider; or `elsewhere`, on another of the owner's devices. Only an
 * agent here has attention, timers and config; the others never run here. */
export type AgentPlace = "here" | "hosted" | "elsewhere";
/** One of the viewer's agents, in the community at `relay`. An agent may be
 * in several communities, each with an `Agent` of its own. */
export type Agent<Config = unknown> = Readonly<{
    /** Its membership in this community, which names it in every call here
     * and keys whatever is kept for it, such as its sessions. */
    key: AgentKey;
    /** Its identity, the same in each of its communities. */
    pubkey: string;
    name: string;
    /** Its picture in this community. */
    picture?: string;
    /** The agent type's key, `pluginId/typeId`. */
    type: string;
    owner: string;
    relay: string;
    place: AgentPlace;
    /** A hosted agent its provider made whose setup has not finished; `finish`
     * continues it. */
    unfinished?: true;
    /** Imported, but whether it is still archived in its community could not
     * be checked; `unarchive` tries again. */
    archiveUnchecked?: true;
    /** Its Delete, or its Remove from this community, did not finish: it is
     * stopped here until that runs again. */
    deleting?: true;
    protection?: ProtectionBinding;
    protectionRevision?: number;
    /** Saved execution selection for this membership on this device. */
    executionBinding?: AgentExecutionBinding;
    attention: Readonly<Record<string, AttentionObject>>;
    /** Stored attention objects that are invalid or over a limit, by slug. */
    skipped: Readonly<Record<string, SkippedObject>>;
    /** Run state of its timers, by slug; written only by the runtime. */
    timers: Readonly<Record<string, TimerState>>;
    sourceRuns?: Readonly<Record<string, string>>;
    attentionHistory?: AgentRecord["attentionHistory"];
    /** Whether its watches and timers wake it: true while a plugin shows
     * Attention. Off keeps every object. */
    attentionEnabled: boolean;
    /** Its type's settings, the same in each of its communities. */
    config: Config;
    /** The synced head each synced side's editor opens; Save revises it. */
    configBase?: ConfigBase;
    /** Why a synced side can't be read here; its field is then not shown. */
    configProblem?: string;
}>;
export type AgentChange<Config = unknown> = Readonly<{
    name?: string;
    /** An HTTPS image URL; `null` or empty removes the picture. */
    picture?: string | null;
    config?: Config;
    /** @deprecated A no-op: Attention runs for every agent while a plugin
     * shows it. Still stored, but nothing reads it. */
    attentionEnabled?: boolean;
    /** Slug to new value; `null` deletes the object. */
    attention?: Readonly<Record<string, AttentionValue | null>>;
    /** Rejects an Attention edit if any displayed object changed before saving. */
    attentionExpected?: Readonly<Record<string, AttentionObject>>;
    /** Sets only a watch's enabled state, if the displayed object is still current. */
    watchEnabled?: Readonly<Record<string, Readonly<{
        enabled: boolean;
        expected: AttentionObject;
    }>>>;
    /** Timers in `attention` to start over: a new schedule from their
     * `armed_at`, with no occurrences used. */
    restart?: readonly string[];
    /** The `configBase` of the agent the editor opened: Save revises it. */
    base?: ConfigBase;
}>;
/** What a type's read-only peek receives. */
export type AgentPeekProps<Config = unknown> = {
    agent: Agent<Config>;
};
export type AgentSettingsHost = Readonly<{
    /** A labelled Type control supplied only by the Agents build view.
     * An optional provider action sits beside the harness choice. */
    typeControl?: (dirty: boolean, action?: ReactNode) => ReactNode;
    /** Host-owned type change committed with the target type's settings draft. */
    pendingSave?: (config?: unknown) => Promise<void>;
}>;
/** What each of a type's settings tabs receives. A type writes only its own
 * config; the app owns the name and attention. */
/** The message's conversation a profile was opened from: its channel, and its
 * thread root when the message had one. Which session that is stays the type's
 * own rule. */
export type AgentConversation = Readonly<{
    channelId: string;
    rootId?: string;
}>;
/** A panel's ask for a conversation's transcript. `opening` identifies it: a
 * new number is a new opening, even of the conversation already shown. */
export type TranscriptRequest = Readonly<{
    opening: number;
    done(): void;
}>;
export type AgentViewProps<Config = unknown> = {
    agent: Agent<Config>;
    /** Where the agent was opened from, when it was opened from a conversation. */
    conversation?: AgentConversation;
    /** Present while the panel asks to show that conversation's transcript
     * first: an Activity tab does so if it knows it then, or once its lookup
     * finds it unless the reader acts first, and calls `done` once it has
     * decided, so the panel asks only once. */
    initialTranscript?: TranscriptRequest;
    /** Closes the panel showing the tab. */
    close?: () => void;
    /** Opens a channel, or a thread by its root, in the agent's community;
     * absent where the host can't open one. */
    openConversation?: (channelId: string, threadRootId?: string) => void;
    /** Replaces the type's whole config. Spread `agent.config` to change one
     * field, or tabs that each save a part will erase each other's fields. A
     * hosted type's tabs save to its provider instead; for them this rejects.
     * A tab that reconciles incoming config can supply its matching configBase;
     * otherwise the host retains the last revision it opened or saved. */
    save(config: Config, options?: {
        base: ConfigBase;
    }): Promise<void>;
    /** Host identity/retype framing for a Settings tab. Other surfaces omit it. */
    settingsHost?: AgentSettingsHost;
    /** Optional presentation split for providers that declare splitSettings. */
    settingsSection?: "identity" | "runtime";
    /** Host management rows, shown before provider diagnostics. */
    settingsContent?: ReactNode;
};
/** What a type's part of the New agent dialog receives: the new agent's
 * starting config, from `defaults`, to fill in. The app owns its key, name and
 * picture around it. */
export type AgentCreateProps<Config = unknown> = {
    /** Existing agent when editing saved config or rendering a library card. */
    agent?: Agent<Config>;
    openSettings?: () => void;
    /** Model fields may use the compact card treatment in the library. */
    modelAppearance?: "glass-ghost" | "inverted";
    /** Reports whether the displayed provider/model selection is usable, including defaults. */
    onReadyChange?: (ready: boolean) => void;
    /** Hide effort editing in streamlined connection setup. */
    showEffort?: boolean;
    config: Config;
    /** `suggested` fills choices the person has not made yet, such as a
     * provider's recommended model, without counting as a started draft.
     * The creation dialog honors it for CreateConfiguration. */
    onChange(config: Config, options?: {
        suggested?: boolean;
    }): void;
    disabled: boolean;
};
export type AgentTab<Config = unknown> = Readonly<{
    id: string;
    title: string;
    /** Lets the Agents build view place host-owned Type controls in this tab. */
    role?: "settings" | "activity";
    /** Supports separate identity and runtime settings presentations. */
    splitSettings?: boolean;
    /** Reconciles incoming config and supplies its matching save base. Keeps
     * this editor mounted through config unavailability to preserve drafts. */
    reconcilesConfig?: boolean;
    component: ComponentType<AgentViewProps<Config>>;
}>;
/** A tab a plugin adds to the settings of every agent shown on this device,
 * whatever its type or place, or only those `when` accepts: a tab for local
 * agents only says so in its `when`. It reads the agent and saves through the
 * plugin's own `agents`. */
export type AgentAddedTab = Readonly<{
    id: string;
    title: string;
    component: ComponentType<{
        agent: Agent;
        /** Opens a link, such as a profile, where the tab is shown; false when it
         * can't there. Absent where the tab can open nothing. */
        open?: ((target: string) => boolean) | undefined;
        /** Whether `open` can open this link, so the tab shows it as text if not. */
        canOpen?: ((target: string) => boolean) | undefined;
    }>;
    /** Whether the tab shows for this agent; absent, it shows for each. */
    when?: (agent: Agent) => boolean;
    /** Calls `listener` when `when` may answer differently. */
    subscribe?: (listener: () => void) => () => void;
}>;
export type RegisteredAgentAddedTab = Contribution<AgentAddedTab>;
/** One of an agent's conversation sessions on this device. Without `root` it
 * is the channel's one session: a channel-scoped agent's, a DM's or a Solo
 * chat's; with it, the thread's. `at` is when it last took in a message
 * or ended a turn, in milliseconds. `status` is the type's latest
 * observation of it while running here, such as "Working", "Idle" or a
 * failed turn's outcome; absent means unobserved, not idle. */
export type AgentSession = Readonly<{
    channelId: string;
    root?: string;
    at?: number;
    status?: string;
}>;
/** Read-only: reading never starts, stops or changes a session. */
export type AgentSessions = Readonly<{
    list(agent: AgentKey): readonly AgentSession[];
    subscribe(listener: () => void): () => void;
}>;
/** Token counts as the harness reported them. An absent count is unknown, not
 * zero. `input` excludes the cache counts; together they are the prompt. */
export type TokenCounts = Readonly<{
    input?: number;
    output?: number;
    cacheRead?: number;
    cacheWrite?: number;
    /** Of `cacheWrite`, those cached for an hour rather than five minutes. */
    cacheWrite1h?: number;
}>;
/** One model request of a session, as the harness recorded it. */
export type UsageObservation = Readonly<{
    /** The harness's id for the request, when it records one; unique within
     * the session. */
    requestId?: string;
    /** When the harness recorded the request, in milliseconds. */
    at: number;
    model: string;
    tokens: TokenCounts;
    /** USD the harness itself recorded, and how it says it got it, e.g.
     * goose's `estimated`; absent when it records none. */
    cost?: Readonly<{
        usd: number;
        source: string;
    }>;
}>;
/**
 * A snapshot of one harness session an agent ran on this device: all its
 * usage, its descendants' (subagents') included, so a consumer never adds a
 * child session again. `channelId` and `root` say where in Buzz it started,
 * when the session records it.
 *
 * A snapshot without `gaps` is complete: it replaces whatever a consumer kept
 * for the session. An incomplete one should leave the consumer's previous
 * snapshot in place and report the gap. A session missing from a later read
 * is not deleted: its source may be gone, not its usage.
 */
export type SessionUsage = Readonly<{
    /** The harness's own session id, opaque to others. */
    id: string;
    /** Equal for two reads that saw the same usage. Opaque and unordered: it
     * says whether a snapshot changed, not which is newer. */
    revision: string;
    /** What the read could not see, e.g. a subagent's vanished file. */
    gaps: readonly string[];
    channelId?: string;
    root?: string;
    title?: string;
    startedAt: number;
    lastAt: number;
    observations: readonly UsageObservation[];
}>;
/** A conversation to wake an agent in, and what to tell it there. `root` is
 * the thread's root event id; leave it out for a Solo chat. */
export type AgentWake = Readonly<{
    channel: string;
    root?: string;
    text: string;
}>;
/** The conversation a self-handoff came from: no channel for a watch's or
 * timer's standalone turn. `external` for an external app acting as the
 * agent, which has no conversation of its own. */
export type HandoffSource = Readonly<{
    channel?: string;
    root?: string;
} | {
    external: true;
}>;
/** A wake the agent sends itself, `from` another of its conversations. */
export type AgentHandoff = AgentWake & Readonly<{
    from: HandoffSource;
}>;
/** The agent as `run` holds it. A run's handle works for as long as the
 * agent exists; one from `Agents.handle` fails each call while `handle`
 * would not return it, and for good once the agent's type or its plugin is
 * replaced, so ask for a new one then. */
export type AgentHandle = Readonly<{
    key: AgentKey;
    protection?: AgentProtection | undefined;
    pubkey: string;
    /** Its community, as the `wss://` origin its native row names. */
    relay: string;
    name: string;
    owner: string;
    /** Installed local types and owner-reviewed creation requests. */
    agentTypes?(): readonly Readonly<{
        key: string;
        title: string;
    }>[];
    createAgent?(input: AgentCreationInput): Promise<Readonly<{
        requestId: string;
        saved: false;
    }>>;
    /** Owner-reviewed changes to one of the owner's agents here. */
    updateAgent?(input: AgentUpdateInput): Promise<Readonly<{
        requestId: string;
        saved: false;
    }>>;
    /** The owner's agents here, or the one with this pubkey or name. */
    readAgents?(agent?: string): Promise<AgentReadout | readonly AgentReadout[]>;
    /** The owner's teams the Agents page shows here, or the one with this id
     * or name. */
    readTeams?(team?: string): Promise<TeamReadout | readonly TeamReadout[]>;
    /** Owner-reviewed name and instructions changes to one of those teams. */
    updateTeam?(input: TeamUpdateInput): Promise<Readonly<{
        requestId: string;
        saved: false;
    }>>;
    /** This device's plugins, as the agent may read and change them. */
    plugins?: AgentPlugins | undefined;
    /** On a run's handle only: wakes this agent in another of its
     * conversations, as `Agents.wake` would, telling it the wake is its own. */
    handoff?(handoff: AgentHandoff): void;
    /** Rechecks an operation lifetime after channel startup, before signing. */
    publish(event: AgentEventTemplate, check?: () => void): Promise<RelayEvent>;
    /** Reads the community as the agent, seeing only what it may see. */
    query(filters: readonly object[]): Promise<RelayEvent[]>;
    effectiveEdit(id: string, channel: string): Promise<RelayEvent>;
    /** Finds profiles by `name` or `display_name`, as the agent, best match
     * first. `undefined` when its community has no profile name search. */
    searchProfiles(query: string, limit: number): Promise<RelayEvent[] | undefined>;
    /** Uploads base64 `data`, a file of any type its community accepts, as
     * the agent. `mime` is a hint; the community decides the type. */
    upload(data: string, mime: string): Promise<AgentUpload>;
    /** Saves one of its community's media blobs, of any type, by URL or
     * `sha256[.ext]`, to a local file for the agent. */
    media(url: string): Promise<AgentMedia>;
    /** Repository `repo` of `owner` in its community: its URL, and the Git
     * header that authorizes it there as the agent for a minute. */
    gitAuth(owner: string, repo: string): Promise<GitAuth>;
    /** Writes memory entry `slug`, newer than the entry it replaces (`after`,
     * that entry's `createdAt`, or 0); a `null` body deletes it. The owner
     * reads it back. */
    remember(slug: string, body: string | null, after: number): Promise<RelayEvent>;
    /** The owner's channel templates on this device, each with the agents it
     * adds that are the owner's agents in this agent's community. */
    templates(): readonly Readonly<{
        name: string;
        canvas: string;
        agents: readonly string[];
    }>[];
    /** The owner's thread tabs on this device in the agent's community;
     * undefined while it is not connected. */
    tabs(): ReturnType<typeof channelTabs> | undefined;
    /** On a run's handle only: Buzz settings on this device. */
    settings?: DeviceSettings;
    /** Takes notes for this conversation, oldest first. A thread session passes
     * its root; a channel session omits it and takes all notes in the channel. */
    notes?(channelId: string, root?: string): readonly string[];
    /** Puts back notes taken for a turn that never began, ahead of any left
     * since, targeting the same conversation that took them. */
    restoreNotes?(channelId: string, notes: readonly string[], root?: string): void;
    /** The agent's own attention, one object at a time. */
    attention: AgentAttention;
}>;
/** What an agent reads and writes of its attention. Every read is current,
 * so a long run sees Attention turn off and the classifier's state change. */
export type AgentAttention = Readonly<{
    /** False while no plugin shows Attention: none of its objects wakes the
     * agent. The handle still reads and writes them; the attention tools refuse
     * every call while it is off. */
    enabled(): boolean;
    /** Whether a watch's classifier can run now. Classifiers can be saved
     * either way; one that cannot run lets every event pass. */
    classifier(): ClassifierAvailability;
    /** One object and its expected-state token. `interest` scopes the read:
     * an object of another Interest is `wrong-scope`. */
    show(slug: string, interest?: string): Promise<Shown>;
    interests(search?: string): readonly string[];
    watches(filter?: WatchFilter): readonly WatchSummary[];
    /** Replaces, or with `null` removes, one object; returns it as shown after
     * the write. Throws an AttentionError when refused. */
    write(slug: string, value: AttentionValue | null, options: WriteOptions, 
    /** Rechecked when the queued mutation is applied, including after token calculation. */
    check?: () => void): Promise<Shown>;
}>;
export type { ClassifierOutcome } from "./classifier";
export type CaughtUp = Readonly<{
    event: RelayEvent;
    classifier?: ClassifierOutcome;
}>;
/** A local wake delivered in a conversation, never a signed message: a
 * plugin's (`Agents.wake`), the agent's own `from` another of its
 * conversations (the `self_handoff` tool), or Attention's. */
export type ConversationWake = Readonly<{
    channel: string;
    root?: string;
    /** Explicit channel-level delivery when no thread is saved. */
    topLevel?: true;
    text: string;
    id: string;
    at: number;
} & ({
    type: "plugin";
    plugin: string;
} | {
    type: "plugin";
    from: HandoffSource;
} | {
    type: "attention";
})>;
export type Trigger = 
/** Directly addressed: a chat message that mentions the agent. `resumed`
 * when its turn was working as the app closed or reloaded, which stopped it
 * partway, and the owner chose to resume it (see `AgentType.resumes`). */
Readonly<{
    type: "mention";
    event: RelayEvent;
    resumed?: true;
}> | ConversationWake
/** One matching watch; an event that matches several runs once for each. */
 | Readonly<{
    type: "watch";
    event: RelayEvent;
    slug: string;
    watch: EventWatch;
    /** Absent when the watch names an Interest that does not exist. */
    interest?: Interest;
    /** Set when the watch has a classifier: its answers, or why it did
     * not run or failed. An event the classifier cannot check passes
     * rather than lose a match, and the agent is told why. */
    classifier?: ClassifierOutcome;
}>
/** Events one watch missed while the agent was offline, delivered together
 * once it is back: oldest first, from one channel unless it watches "all". */
 | Readonly<{
    type: "catch-up";
    slug: string;
    watch: EventWatch;
    /** Absent when the watch names an Interest that does not exist. */
    interest?: Interest;
    /** Each with its classifier outcome when the watch has a classifier;
     * only the events it passed are here. */
    events: readonly CaughtUp[];
    /** Older missed events were skipped: catch-up reads a bounded window. */
    skipped?: boolean;
}> | Readonly<{
    type: "source";
    interest?: Interest;
    slug: string;
    watch: import("./attention").SourceWatch;
    plugin: string;
    text: string;
    classifier?: ClassifierOutcome;
}> | Readonly<{
    type: "timer";
    slug: string;
    timer: TimerWatch;
    /** Absent when the timer names an Interest that does not exist. */
    interest?: Interest;
    /** This is its last allowed occurrence. */
    spent: boolean;
}>;
/** A turn with no conversation and nothing saved, such as for a watch or a
 * timer. */
export type StandaloneTurn<Config = unknown> = Readonly<{
    /** The watch's or timer's delivery. */
    delivery: Delivery<Config>;
    /** Names the turn, for status views. */
    key: string;
    /** Aborts when the agent is removed, its type is replaced, or
     * STANDALONE_DEADLINE_MS after the turn starts (agent-harness/standalone).
     * Unlike the delivery's signal, it does not count time spent waiting in
     * the lane. A harness waits for readiness under it and stops its turn when
     * it aborts. */
    signal: AbortSignal;
    /** The turn's whole prompt, asked once the harness is ready to start it.
     * Undefined means it is no longer wanted, so no turn starts. */
    prompt(): Promise<string | undefined>;
}>;
/** How a standalone turn ended. */
export type TurnResult = Readonly<{
    ok: boolean;
    error?: string;
}>;
export type Delivery<Config = unknown> = Readonly<{
    trigger: Trigger;
    /** The live route's channel; absent when the wire scope was ambiguous. */
    channelId?: string;
    agent: AgentHandle;
    /** The agent's config when this run started. */
    config: Config;
    /** The synced config revisions this run started from; empty when local. */
    revisions?: readonly string[];
    /** The synced settings in `config`. A launch shows an error instead of
     * replacing one its runtime doesn't offer with a default (NIP-AP). */
    synced?: Readonly<Record<string, string>>;
    /** The model the owner asked for in the triggering message: one of the
     * type's `models`. Absent means the agent's own model. */
    model?: string;
    /** The effort level the owner asked for in the triggering message: one of
     * that model's `efforts`. Absent means the agent's own default. */
    effort?: string;
    /** A section for each team the agent is on, with the team's name, roster and
     * instructions, to follow the agent's own instructions. Absent without one. */
    team?: string;
    /** Aborts on the run's deadline, or when the agent is removed or its type is
     * replaced. Advisory: the handle keeps working, so finishing up is harmless. */
    signal: AbortSignal;
    /** Keeps the run counted as working after `run` returns, until `done`
     * settles, for a type that hands its work off and returns early. `done`
     * resolving `{ ok: false, error }` fails the request; `{ ok: true,
     * stopped: true }` says the owner's Stop ended its turn. */
    workingUntil(done: PromiseLike<unknown>): void;
    /** Optional presentation evidence supplied by the harness, not inferred by the UI. */
    step?(tool: string, target?: string): void;
    /** The plugin declined this request; no work or successful outcome is implied. */
    ignored?(): void;
    /** The harness acknowledged this exact request. Not proof of model consumption. */
    acknowledged?(): void;
    /** A newer acknowledged request owns this turn's activity; hide this message's
     * bubble without claiming success or changing the execution outcome. */
    superseded?(): void;
    /** Offers the owner Stop on this request's activity: `stop` stops the turn
     * the request is in, and resolves once the harness has asked it to. The
     * turn still settles what it handed to `workingUntil`. */
    interruptible?(stop: () => Promise<void>): void;
    /** The harness's own title for this mention's conversation. The host may
     * name a Solo chat with it once; the type need not know whether it did. */
    named?(title: string): void;
    /** Rebuilds an addressed subscription prompt after harness readiness or a queue wait. */
    wakeText?(): Promise<string | undefined>;
    /** Whether the trigger should still run, asked again now. False once the
     * agent is removed or its type replaced; for a watch or timer, also once
     * attention was turned off or its object disabled or removed; and for a
     * watch, once it was changed or its event no longer matches. A type that queues a
     * watch's or timer's work asks before it starts that work. */
    current(): boolean;
}>;
export type Effort = Readonly<{
    id: string;
    label: string;
}>;
/** An immediate session action: `compact` summarizes its history to free
 * context, and `new` starts a new session. */
export type SessionAction = "compact" | "new";
/** Immediate controls for an existing conversation; separate from run picks. */
export type SessionControlAction = SessionAction | "interrupt";
export type SessionPlace = Readonly<{
    channelId: string;
    root?: string;
}>;
export type SessionState = "idle" | "active" | "compacting" | "unavailable";
export type AgentMigrationSetting = Readonly<{
    id: string;
    label: string;
    isOverride: boolean;
    /** Matching keys mean this override has the same effect after migration. */
    unchangedKey?: string;
}>;
/** A model with its effort levels, lowest first. */
export type Model = Readonly<{
    id: string;
    label: string;
    efforts: readonly Effort[];
    /** The effort a run on it uses without a pick, when known. */
    effort?: string;
}>;
/** The models an owner can pick from, and the id of the one used without a pick. */
export type Models = Readonly<{
    current: string;
    models: readonly Model[];
    /** Send displayed defaults as per-turn picks even when untouched. Opt in only
     * when explicit defaults preserve this provider's running-turn semantics. */
    sendDefaults?: boolean;
}>;
export type AgentProviderSnapshot = Readonly<{
    readiness: "checking" | "ready" | "attention";
    /** Action copy; null keeps Harness defaults status-only, undefined uses setup copy. */
    attentionLabel?: string | null;
    /** Supporting status text, separate from the attention action. */
    attentionDescription?: string;
    /** Installation and sign-in work must be cancelled before its dialog closes. */
    blocking?: boolean;
}>;
export type AgentProvider = Readonly<{
    snapshot(): AgentProviderSnapshot;
    subscribe(listener: () => void): () => void;
    /** Refreshes device-wide readiness without changing installation or auth. */
    check(): void | Promise<void>;
    /** Handles the current attention state directly; absent opens DialogBody. */
    attentionAction?: (() => void) | undefined;
    /** Provider-owned recovery/progress controls and optional saved defaults. */
    DialogBody: ComponentType<{
        onClose(): void;
    }>;
    /** Compact device default picker; persistence remains provider-owned. */
    DefaultControl?: ComponentType<{
        onConfigure(): void;
    }>;
}>;
/** The artifact types an agent's config channel binding has made synced. */
export type ConfigBinding = Readonly<{
    settings?: Readonly<{
        mode: Mode;
        subject: Subject;
    }>;
    instructions?: Readonly<{
        mode: Mode;
        subject: Subject;
    }>;
}>;
/** A room audio pipe, not authorization to run tools. The harness obtains its
 * own AgentHandle and applies its ordinary per-turn authorization. */
export type AgentVoiceSeat<Config = unknown> = Readonly<{
    agent: Agent<Config>;
    /** Always channel-scoped, regardless of the harness setting; never invent a root. */
    conversation: Readonly<{
        channelId: string;
    }>;
    signal: AbortSignal;
    /** Final lines only: h-tag-only agent posts; own events never trigger this agent. */
    transcript(speaker: "owner" | "agent", text: string): Promise<void>;
    /** 48 kHz mono; native accepts exactly 960 finite samples with |s| <= 1,
     * dropping frames when its capacity-5 queue is full. */
    output(samples: number[]): Promise<void>;
    /** Idempotent disconnect notification, ignored after signal aborts. */
    ended(error?: Error): void;
    /** Presentation only; never authorizes work. */
    thinking?(active: boolean): void;
} & Pick<Delivery<Config>, "config" | "revisions" | "synced" | "team">>;
/** Host pipe before the agents service resolves launch settings and transcript policy. */
export type AgentVoicePipe = Omit<AgentVoiceSeat, "config" | "revisions" | "synced" | "team" | "transcript">;
type HostedAgentType = Omit<AgentType, "voice"> & {
    voice?(seat: AgentVoicePipe): Promise<AgentVoiceConnection>;
};
export type AgentVoiceConnection = Readonly<{
    /** Owner-only 48 kHz mono frames of up to 5760 samples (native plays out 10 ms frames). Borrowed for this call. */
    input(samples: number[]): void;
    /** Host aborts signal, then awaits close to finish teardown. Idempotent. */
    close(): void | Promise<void>;
}>;
export type AgentType<Config = unknown> = {
    /** Huddles supplies a running agent owned by the current viewer.
     * Full-duplex voice on the existing room conversation; abort closes the pipe. */
    voice?(seat: AgentVoiceSeat<Config>): Promise<AgentVoiceConnection>;
    /** Native callback events this harness exposes to plugins. */
    hooks?: Readonly<{
        events: readonly string[];
    }>;
    id: string;
    title: string;
    description?: string;
    /** Decorative design-system mark shown with this type in host-owned choices. */
    icon?: DefinedIcon;
    /** A new agent's starting config and attention objects. */
    defaults(): Readonly<{
        config: Config;
        attention?: Readonly<Record<string, AttentionValue>>;
    }>;
    /** A brought-over agent's config: `config` from `defaults` with whatever of
     * `carry` the type has a place for. Without it, all of `carry` stays behind. */
    adopt?(carry: Carry, config: Config): Config;
    /** Recognize a published catalog runtime and seed this type's import draft.
     * Return undefined when its runtime/provider cannot be preserved by this type. */
    importShared?(source: {
        runtime?: string;
        provider?: string;
        model: string;
    }): Config | undefined;
    /** The inverse of `importShared`: the catalog runtime, provider and model a
     * share or export of `config` records. Without it, its agents are not shared. */
    exportShared?(config: Config): Readonly<{
        runtime: string;
        provider?: string;
        model: string;
    }>;
    /** What of `config` another type may adopt when the agent changes type.
     * Without it, all of its settings stay behind. */
    carry?(config: Config): Carry;
    /** Describes harness settings for a type-change preview. Rendered labels
     * never determine migration behavior. */
    describeMigration?(config: Config): readonly AgentMigrationSetting[];
    /** Brief runtime consequence of leaving this type. */
    migrationWarning?: string;
    /** One short line under the agent's name, e.g. its model; defaults to the title. */
    summary?(agent: Agent<Config>): string;
    /** A read-only glance shown when the agent is selected in the grid. */
    Peek?: ComponentType<AgentPeekProps<Config>>;
    /** The type's choices in the New agent dialog, such as model and
     * instructions; the new agent starts with the config it settles on. */
    Create?: ComponentType<AgentCreateProps<Config>>;
    /** Optional creation configuration group. The type places the host's Harness
     * row alongside its own controls and keeps discovery/recovery with them.
     * Takes precedence over CreateModel in the creation dialog. Report readiness
     * of the displayed choices through onReadyChange, independently of edits;
     * the dialog waits for true before allowing creation. */
    CreateConfiguration?: ComponentType<AgentCreateProps<Config> & {
        harnessControl: ReactNode;
        onReadyChange?: (ready: boolean) => void;
    }>;
    /** Compact provider-owned action beside Harness. Readiness belongs to
     * CreateConfiguration; this slot only presents the provider's action. */
    CreateAction?: ComponentType<{
        /** The agent being edited, as CreateConfiguration has it. */
        agent?: AgentCreateProps<Config>["agent"];
        disabled: boolean;
    }>;
    /** Provider-owned account notice, pinned outside the agent's tab content.
     * Return null when no account notice is needed. The active settings view may
     * replace this slot through the AgentSaveFooter context's setPanelNotice(content),
     * including when the type does not supply a PanelFooter.
     * clearing it with null on cleanup; the host retains outgoing content through exit.
     * By default a notice dims identity artwork and closes name/avatar editors.
     * Ordinary load/save notices must set data-agent-access-required="false" on
     * their outer DOM element to opt out of those access effects. Both kinds share
     * host-owned placement and measured scroll space. */
    PanelFooter?: ComponentType;
    /** Provider-owned gate for name/avatar editing, independent of messaging.
     * Report unavailable access so the host can retire open profile editors. */
    ProfileActions?: ComponentType<{
        children: ReactNode;
        onUnavailable?: () => void;
    }>;
    /** Compact model field for creation and library cards; the type owns discovery and configuration. */
    CreateModel?: ComponentType<AgentCreateProps<Config>>;
    /** CreateModel reports onReadyChange; opt in to inline connection setup.
     * Omit for older controls: users must choose another harness for that flow. */
    createModelReportsReadiness?: boolean;
    /** Compact Thinking control for creation; the type owns its values and default representation. */
    CreateThinking?: ComponentType<AgentCreateProps<Config>>;
    /** Device-wide readiness and management. Agents supplies the menu row,
     * provider identity, modal framing and focus behavior. */
    provider?: AgentProvider;
    /** The type's settings tabs, in order. */
    tabs?: readonly AgentTab<Config>[];
    /** Each agent's sessions, for views across agents. */
    sessions?: AgentSessions;
    /** Models and effort levels the owner can pick for the next run while
     * mentioning the agent. Discovery may be async but must not start a turn.
     * The picks reach that run as `Delivery.model` and `Delivery.effort`. */
    models?(agent: Agent<Config>): Models | Promise<Models>;
    /** Offers immediate controls for the agent's session scope: under `channel`
     * a channel's top-level message joins the channel's one session, and under
     * `thread` it starts a thread of its own, with no session to act on. A DM or
     * Solo chat is one session either way. */
    sessionControls?: {
        scope(agent: Agent<Config>): "thread" | "channel";
        state(agent: Agent<Config>, place: SessionPlace): SessionState;
        run(agent: Agent<Config>, place: SessionPlace, action: SessionControlAction): Promise<void>;
        subscribe(listener: () => void): () => void;
    };
    /** Read-only: snapshots of the sessions the agent ran from Buzz on this
     * device with activity since `since` (milliseconds). `since` only bounds
     * activity time; it is no checkpoint, and a session last active before it
     * that the harness later corrected is not read again. Reading never starts,
     * stops or changes a session; rejects when `signal` aborts. */
    usage?(agent: Agent<Config>, options: Readonly<{
        since: number;
        signal: AbortSignal;
    }>): Promise<readonly SessionUsage[]>;
    /** The settings that sync across devices and how they merge into this
     * device's config. Without it, the type's settings never sync. */
    syncedSettings?: Readonly<{
        schema: SettingsSchema;
        withSynced(config: Config, settings: Readonly<Record<string, string>>): Config;
    }>;
    /** Runtime routes its supported security boundaries through AgentHandle.protection. */
    protection?: true;
    /** Uses the agent's saved execution target for native process and file I/O. */
    execution?: true;
    /** Why protected runs must stop when this runtime cannot enforce the contract. */
    protectionUnavailable?: string;
    /** Fully retires native sessions for this membership key before policy changes. */
    retire?(key: string): Promise<void>;
    run?(delivery: Delivery<Config>): void | Promise<void>;
    /** Runs a standalone turn and settles when it ends, stopping it when
     * `turn.signal` aborts. With it, the host runs watches and timers as
     * standalone turns in their Interest's lane, and `run` gets only mentions. */
    runOnce?(turn: StandaloneTurn<Config>): Promise<TurnResult>;
    /** Reads a file for an unprotected agent outside its turns, as its tools
     * read one they send: relative to its saved workspace, where it runs.
     * Rejects where only a conversation's session has a place to read it, as
     * on an execution target. Without it, its agents read none there. */
    readFile?(agent: Agent<Config>, path: string, signal: AbortSignal): Promise<Uint8Array>;
    /** Per-run deadline in milliseconds, up to 30 minutes; defaults to 60 seconds. */
    timeoutMs?: number;
    /** Its turns run in this page, so closing or reloading the app stops them.
     * With this, a mention turn still working then is kept, and given to `run`
     * again marked `resumed` if the owner chooses to resume it, to carry on in
     * the conversation's saved session, or in a new one shown the conversation. */
    resumes?: boolean;
    /** Makes the type hosted: its provider runs each agent, so it has no `run`,
     * `models` or `timeoutMs`, and its agents have no attention. */
    remote?: RemoteAgentType;
};
/** A hosted type's provider: it holds each agent's key and runs it. The app
 * calls these in order to create one (`provision`, then `activate`) and owns
 * the owner's agent list; every step is asked again after a failure, so each
 * must be safe to repeat. `community` is the agent's `wss://` community. */
export type RemoteAgentType = Readonly<{
    /** Makes the agent and resolves with its pubkey and the picture it was
     * made with, which a retried creation keeps. Not yet its owner's. */
    provision(input: Readonly<{
        name: string;
        /** An HTTPS image URL. */
        picture?: string;
        community: string;
        config?: unknown;
        signal: AbortSignal;
    }>): Promise<Readonly<{
        pubkey: string;
        picture?: string;
    }>>;
    /** Hands over the owner's attestation (NIP-OA), which the agent attaches to
     * what it signs. The provider publishes its profile with the name and
     * picture it was made with, and starts it. */
    activate(input: Readonly<{
        pubkey: string;
        name: string;
        community: string;
        auth: NipOaAuthorization;
        config?: unknown;
        signal: AbortSignal;
    }>): Promise<void>;
    /** Publishes its profile with this name and picture (an HTTPS image URL). */
    profile(input: Readonly<{
        pubkey: string;
        community: string;
        name: string;
        picture?: string;
        signal: AbortSignal;
    }>): Promise<void>;
    /** Stops the turn it is running in one conversation, named by its channel
     * and thread root (a top-level message's own id). False when nothing there
     * was running. Without it, its turns offer no Stop. */
    interrupt?(input: Readonly<{
        pubkey: string;
        community: string;
        channelId: string;
        threadRootId: string;
        signal: AbortSignal;
    }>): Promise<boolean>;
    /** Reads and replaces the instructions its provider holds for the agent,
     * so a plugin can edit them as a local agent's are. `set` rejects what the
     * provider refuses, such as instructions too long. Without it, its
     * instructions can only be edited in the provider's own settings. */
    instructions?: Readonly<{
        get(input: Readonly<{
            pubkey: string;
            community: string;
            signal: AbortSignal;
        }>): Promise<string>;
        set(input: Readonly<{
            pubkey: string;
            community: string;
            instructions: string;
            signal: AbortSignal;
        }>): Promise<void>;
    }>;
    /** Stops it and deletes its key. An agent already gone counts as removed. */
    remove(input: Readonly<{
        pubkey: string;
        community: string;
        signal: AbortSignal;
    }>): Promise<void>;
}>;
/** A hosted agent's instructions, read and replaced through its provider. */
export type HostedInstructions = Readonly<{
    get(signal?: AbortSignal): Promise<string>;
    /** Replaces them only while the provider still holds `base`, the copy the
     * caller last read; otherwise it rejects and replaces nothing, so an edit
     * saved elsewhere is never overwritten from an older copy. */
    set(instructions: string, base: string, signal?: AbortSignal): Promise<void>;
}>;
/** A hosted agent's instructions changed since the caller read them. */
export declare const HOSTED_INSTRUCTIONS_CHANGED = "Its instructions were changed elsewhere. Check the latest, then try again.";
export type RegisteredAgentType = Contribution<HostedAgentType>;
export type RetypePreview = Readonly<{
    /** Destination settings after applying the target type's migration policy. */
    config: unknown;
    moved: readonly (keyof Carry)[];
    dropped: readonly (keyof Carry)[];
    settings: readonly Readonly<{
        id: string;
        label: string;
        outcome: "reset" | "dropped";
    }>[];
}>;
/** A proposal's picture: uploads it once the proposal is valid, giving its
 * HTTPS image URL. */
export type ProposedPicture = () => Promise<string>;
type AgentCreation = Readonly<{
    type: string;
    name: string;
    instructions?: string;
}>;
/** A requested agent. */
export type AgentCreationInput = AgentCreation & Readonly<{
    picture?: ProposedPicture;
}>;
/** An unsaved creation request; `picture` is an HTTPS image URL. Only the
 * owner-facing review may approve it. */
export type AgentCreationRequest = AgentCreation & Readonly<{
    picture?: string;
    id: string;
    requester: string;
    requesterName: string;
    owner: string;
    community: string;
}>;
/** Proposed changes; absent fields stay as they are. `picture` is an HTTPS
 * image URL. */
export type AgentUpdate = Readonly<{
    name?: string;
    type?: string;
    instructions?: string;
    picture?: string;
}>;
/** `agent` is a pubkey or the exact name of one of the owner's agents here. */
export type AgentUpdateInput = Omit<AgentUpdate, "picture"> & Readonly<{
    agent: string;
    picture?: ProposedPicture;
}>;
/** An unsaved change request. Only the owner-facing review may approve it. */
export type AgentUpdateRequest = AgentUpdate & Readonly<{
    id: string;
    requester: string;
    requesterName: string;
    owner: string;
    community: string;
    agent: string;
    agentName: string;
    /** Its type when requested, shown as what the review changes from. */
    agentType: string;
}>;
/** What `agent_read` shows of one of the owner's agents. Instructions are
 * null for a type that has none. An agent hosted or on another device shows
 * its synced instructions when the owner can read them here, and otherwise
 * has `unavailable` instead, saying why. */
export type AgentReadout = Readonly<{
    pubkey: string;
    name: string;
    type: string;
} & ({
    instructions: string | null;
    synced: boolean;
    revision?: string;
} | {
    unavailable: string;
})>;
/** What `team_read` shows of one of the owner's teams. */
export type TeamReadout = Readonly<{
    id: string;
    name: string;
    instructions: string;
    members: readonly Readonly<{
        pubkey: string;
        name: string;
    }>[];
    synced: boolean;
    revision?: string;
}>;
/** `team` is the id or exact name of one of the owner's teams here. Members
 * never change by request. */
export type TeamUpdateInput = Readonly<{
    team: string;
    name?: string;
    instructions?: string;
}>;
/** An unsaved team change request. Only the owner-facing review may approve
 * it, and only while the team is as it was when requested. */
export type TeamUpdateRequest = Readonly<{
    id: string;
    requester: string;
    requesterName: string;
    owner: string;
    community: string;
    team: string;
    /** The team as it was requested over. */
    base: Pick<Team, "name" | "instructions" | "revision">;
    name?: string;
    instructions?: string;
}>;
export type AgentsSnapshot = Readonly<{
    status: "unavailable" | "loading" | "ready" | "error";
    /** Whether a watch's classifier can run on this device now. */
    classifier: ClassifierAvailability;
    /** The selected community's agents, while it is connected. */
    agents: readonly Agent[];
    /** Every agent kept running here, whichever community is selected: the
     * viewer's agents in each joined community not disconnected, but none
     * whose Delete or Remove there is unfinished. */
    running: readonly Agent[];
    /** Running agents that were working when the app last closed or reloaded,
     * until the owner resumes or forgets those turns. */
    interrupted: readonly Agent[];
    /** The owner's teams on this device, which every community shares, and
     * each synced team with a confirmed copy. */
    teams: readonly Team[];
    /** Whether the selected community's config channels are up, so a new team
     * made there syncs. What `teamHere` says of a new team changes with it. */
    syncsTeams?: boolean;
    error?: string;
}>;
export type { Carry, Team };
export type TeamChange = Omit<Team, "id" | "revision"> & Readonly<{
    id?: string;
    /** The team as its editor opened it, the base a synced Save revises. */
    opened?: Team;
    /** A new team's id, made once by its editor so every retry is the same
     * team. */
    draft?: string;
}>;
/** What `port` imports: an identity an earlier agent system saved on this
 * machine, or an agent a community member shared. */
export type PortInput = Readonly<{
    source: PortSource;
    pubkey: string;
    type: string;
    config?: unknown;
    scope?: string;
} | {
    source: "shared";
    type: string;
    name: string;
    /** An HTTPS image URL. */
    picture?: string;
    instructions?: string;
    config?: unknown;
}>;
/** What Import can bring over, and the agents already in Yours. */
export type FoundAgents = PortableAgents & Readonly<{
    here: readonly string[];
}>;
/** What importing an old Buzz team did. Members that came are kept even when
 * others, or the team itself, did not. */
export type TeamPort = Readonly<{
    /** The team that was saved, including an existing team cleaned to zero
     * members. Absent when no team was saved. */
    team?: Team;
    imported: readonly Agent[];
    failed: readonly Readonly<{
        name: string;
        error: string;
    }>[];
    /** Members already here in another community, left off the team. */
    elsewhere: readonly string[];
    /** Members another account on this device has, left off the team. */
    foreign: readonly string[];
    /** The team could not be saved, though its members were imported. */
    teamError?: Readonly<{
        name: string;
    }>;
    /** What did not come over with the members that were imported. */
    notes?: readonly string[];
}>;
/** An imported agent, and what did not come over with it. */
export type Ported = Readonly<{
    agent: Agent;
    notes: readonly string[];
}>;
export type NewAgent = Readonly<{
    type: string;
    name: string;
    /** An HTTPS image URL. */
    picture?: string;
    /** Its starting config, from the type's `Create`; else the type's defaults.
     * Hosted setup retains it until the provider has applied it. */
    config?: unknown;
}>;
export type Agents = {
    registerExecution(provider: AgentExecutionProvider): void;
    /** Select the adapter while the agent is idle. This is write-once. */
    bindExecution(agent: AgentKey, binding: Readonly<{
        id: string;
        config?: JsonValue;
    }>): Promise<void>;
    executionBinding(agent: AgentKey): AgentExecutionBinding | undefined;
    inspectExecution(agent: AgentKey): Promise<AgentExecutionBinding | undefined>;
    /** Only the agent's native harness can open its bound target. */
    execution(agent: AgentKey, session: AgentExecutionSession): Promise<AgentExecution | undefined>;
    registerHook(hook: AgentHook): void;
    /** Dispatches hooks for this plugin's agent types in contribution order. */
    dispatchHook(harness: string, event: string, input: unknown, context: AgentHookContext, options: AgentHookDispatchOptions): Promise<unknown>;
    /** Registers a deterministic source owned by this plugin. Attention controls
     * its lifetime; output goes privately to the watch's saved conversation.
     * The provider key is pluginId/id. Local agents only. */
    addAttentionSource(source: import("./attention-sources").AttentionSource): void;
    /** Active providers, including those contributed by other plugins. */
    attentionProviders(): readonly Readonly<{
        provider: string;
        description?: string;
        configExample?: Readonly<Record<string, unknown>>;
        builtIn?: boolean;
    }>[];
    /** How the watch's provider shows it, when the provider presents its watches. */
    presentWatch(watch: import("./attention").SourceWatch, title: string): import("./attention-sources").SourcePresentation | undefined;
    register<Config>(type: AgentType<Config>): void;
    types(): readonly RegisteredAgentType[];
    /** Adds a tab to the settings of every agent running on this device,
     * whatever its type, or of those its `when` accepts, after Activity. It
     * shows while the plugin is on. */
    registerTab(tab: AgentAddedTab): void;
    /** The tabs active plugins add now. */
    addedTabs(): readonly RegisteredAgentAddedTab[];
    /** Says the calling plugin shows Attention. Agents' Attention runs on this
     * device only while such a plugin is on; with none, it is off for every
     * agent. */
    controlAttention(): void;
    /** Adds a tool to every agent session in the app, beside the Buzz tools.
     * The tool acts as the agent, like the rest of a trusted plugin's code
     * acts as its owner. A session lists
     * the tools there are when it starts, and one that cannot take a changed
     * list is replaced when it is next used. */
    addTool(tool: AddedTool): void;
    /** The tools active plugins add now. A name is only ever one plugin's. */
    tools(): readonly AddedTool[];
    /** The Buzz side of a turn for an agent type a plugin brings: where a
     * delivery goes, the bundled harnesses' prompts, the agent's Buzz tools as
     * an MCP handler, and its replies. */
    readonly harness: HarnessKit;
    /** Wakes an agent this copy of the app runs in one of its conversations,
     * as a mention there would, but with no message: the agent is told `text`
     * comes from this plugin, not its owner, and is data. Throws when this copy does not run the agent or its queue is full;
     * like a mention, a queued wake is dropped if the agent stops running here. */
    wake(agent: AgentKey, wake: AgentWake): void;
    snapshot(): AgentsSnapshot;
    subscribe(listener: () => void): () => void;
    /** Calls `listener` when a turn this copy of the app runs for the agent
     * reports a new step, as its harness names them. */
    subscribeSteps(agent: AgentKey, listener: () => void): () => void;
    /** Gives each `interrupted` agent again the turns it was working on, each
     * once its community connects. */
    resumeInterrupted(): void;
    /** Forgets the turns `interrupted` agents were working on. */
    dismissInterrupted(): void;
    /** The agent of this pubkey in the selected community, if it is an agent. */
    find(pubkey: string): Agent | undefined;
    /** The agent as `run` holds it, outside any run: for one of the calling
     * plugin's types while this copy of the app runs it, its type is not
     * changing and its community is live, else undefined. A type whose agents
     * act on something other than a message, such as a call, publishes with
     * it; like any type whose agents run here, it has `run`. A kept handle
     * throws once this no longer holds, so ask again when acting. */
    handle(agent: AgentKey): AgentHandle | undefined;
    canConnectExternal(agent: AgentKey): boolean;
    /** Creates a separate owner-approved external grant in the selected community. */
    connectExternal(agent: AgentKey, signal: AbortSignal, connected: () => void, scopes: readonly ExternalScope[]): Promise<HostMcpServer>;
    /** The owner's connection to a running agent's community, which need not be
     * the selected one: read the agent's conversations through this. */
    relay(agent: AgentKey): RelayData | undefined;
    /** The agent's `core` memory, as this device keeps it current: its text,
     * `null` when it has none, or undefined when it could not be read. A start
     * reads it here, which needs no relay request once this device has read it
     * once; the host refreshes it, so no agent type does. Rejects only when
     * `signal` aborts. */
    core(agent: AgentKey, signal?: AbortSignal): Promise<string | null | undefined>;
    /** Where agent types keep what they save for an agent, such as its
     * sessions. Every program that runs this machine's agents shares it, so
     * keep each agent's state under its own `key`, which is its membership's
     * in one community. A write is saved only once its promise settles. */
    readonly storage: AgentStore;
    /** Makes an agent of `type` in the selected community: here, or with a
     * hosted type at its provider. A hosted one whose setup then fails is kept
     * as `unfinished`. */
    create(input: NewAgent): Promise<Agent>;
    /** Local, unsaved requests; closing a review discards its request. */
    creationRequests(): readonly AgentCreationRequest[];
    dismissCreation(id: string): void;
    /** Creates only after the owner reviews the usual creation form. */
    approveCreation(id: string, input: NewAgent): Promise<Agent>;
    /** Local, unsaved change requests; closing a review discards its request. */
    updateRequests(): readonly AgentUpdateRequest[];
    dismissUpdate(id: string): void;
    /** Saves the owner-reviewed edit form, the agent's settings with the
     * request's changes, to the request's agent. */
    approveUpdate(id: string, input: NewAgent): Promise<void>;
    /** Local, unsaved team change requests; closing a review discards one. */
    teamUpdateRequests(): readonly TeamUpdateRequest[];
    dismissTeamUpdate(id: string): void;
    /** Saves the owner-reviewed name and instructions to the request's team,
     * refused once the team changed since the request. */
    approveTeamUpdate(id: string, input: Pick<Team, "name" | "instructions">): Promise<void>;
    /** Continues an unfinished hosted agent's setup. */
    finish(pubkey: string): Promise<Agent>;
    /** Identities earlier agent systems saved on this machine that are not
     * Agents yet, old Buzz's teams with all their members, and which of those
     * members are already in Yours. */
    portable(): Promise<FoundAgents>;
    /** Imports one as an agent of `type` in the selected community: an identity
     * from `portable` keeps its key, name and picture, and a shared agent gets a
     * new key with its name and picture. Either keeps whatever of its
     * instructions and workspace the type adopts; its other settings stay behind. */
    port(input: PortInput): Promise<Ported>;
    /** Imports an old Buzz team from `portable`, as read now, into the selected
     * community: each member not here yet as an agent of `type`, then the team's
     * copy there with every member here. A team imported before keeps its name,
     * instructions and members here. */
    portTeam(input: Readonly<{
        id: string;
        type: string;
    }>): Promise<TeamPort>;
    /** Saves the owner's change. Its name and config change in every
     * community the agent is in; its picture and attention only in this one. */
    save(agent: AgentKey, change: AgentChange): Promise<void>;
    /** The History of each of the agent's synced config sides; undefined while
     * none syncs here. */
    configHistory(agent: AgentKey): ConfigHistory | undefined;
    /** The History of a synced team's name and instructions; undefined for a
     * team kept only on this device. */
    teamHistory(id: string): ConfigHistory | undefined;
    /** Previews the destination config and transferable settings the same
     * migration used by `retype` will produce, without changing the agent. */
    previewRetype(agent: AgentKey, type: string): RetypePreview;
    /** Makes it an agent of `type` in every community it is in, keeping its
     * identity and attention. Its new config is the type's defaults with
     * whatever the old type carries and the new one adopts, or the reviewed
     * destination draft; returns what of the old config stayed behind.
     * Refused mid-turn. */
    retype(agent: AgentKey, type: string, change?: Readonly<{
        config: unknown;
    }>): Promise<readonly (keyof Carry)[]>;
    /** Stops it for good, leaves its channels and archives it in its
     * community, and only then deletes its record, key and settings. When that
     * cannot finish, as offline, nothing is deleted and nothing retries it: it
     * stays listed and stopped, and this rejects saying so; Delete again runs it
     * all again. Called while one runs, it joins it. A hosted agent is archived,
     * leaves its channels and is removed from its provider before this resolves.
     * One on another device is deleted there. An agent here leaves every
     * community it is in this way, one at a time; one whose community cannot
     * be reached stays, and the rejection names it. */
    remove(agent: AgentKey): Promise<void>;
    /** The communities the owner's agent `pubkey` is in on this device, as
     * Delete leaves them: each one's origin, whether it is connected, and
     * whether a Delete or Remove there started and hasn't finished. */
    memberships(pubkey: string): readonly Readonly<{
        key: AgentKey;
        origin: string;
        connected: boolean;
        deleting?: true;
    }>[];
    /** Deletes the agent from a community Delete cannot reach without leaving
     * it there: it may stay in that community's channels. */
    forget(agent: AgentKey): Promise<void>;
    /** The owner's agents on this device that the selected community can add:
     * each in one of its other communities, by its home there. */
    joinable(): readonly Agent[];
    /** Adds one of the owner's agents from another community to the selected
     * one, with the same key, name, type and settings; its attention and
     * conversations here are its own. */
    join(agent: AgentKey): Promise<Ported>;
    /** Takes the agent out of its community, as Delete does, and keeps it in
     * its others. Refused for its last one, which only Delete leaves. */
    leave(agent: AgentKey): Promise<void>;
    /** Whether the owner can stop a hosted agent's turns through its provider. */
    interruptible(agent: AgentKey): boolean;
    /** A hosted agent's instructions, through its provider; undefined unless
     * the agent is hosted here and its provider offers them. Each call stops
     * with the agent's community connection. */
    hostedInstructions(agent: AgentKey): HostedInstructions | undefined;
    /** Session controls are available only in the copy holding this agent. */
    sessionState(agent: AgentKey, place: SessionPlace): SessionState;
    session(agent: AgentKey, place: SessionPlace, action: SessionControlAction): Promise<void>;
    /** Has a hosted agent's provider stop its turn in one conversation. False
     * when nothing there was running. */
    interrupt(agent: AgentKey, place: Readonly<{
        channelId: string;
        threadRootId: string;
    }>): Promise<boolean>;
    /** Leaves private context for the agent's next turn in a conversation: text at
     * the end of that turn's prompt that nobody else sees, such as what the
     * owner did since its last turn. False unless this copy runs the agent,
     * so the plugin can say it another way. Notes are not saved: one left
     * when the app quits is gone. Pass a thread root for a thread conversation;
     * omit it for a channel conversation, including Solo chats. Thread sessions
     * never take notes addressed only to their channel. */
    note(agent: AgentKey, channelId: string, text: string, root?: string): boolean;
    /** Unarchives an imported agent whose archive state was not checked, as
     * import does, keeping its key and settings. Resolves with what is left. */
    unarchive(agent: AgentKey): Promise<string | undefined>;
    /** Whether a watch's classifier can run on this device now. */
    classifier(): ClassifierAvailability;
    /** Creates a team, or replaces the one with `id`. Members, by pubkey, must
     * be agents on this device or, for a synced team, its home community's
     * hosted agents whose setup finished. Each community has the members that
     * are in it. */
    saveTeam(team: TeamChange): Promise<Team>;
    /** Whether Save puts the team with `id`, or the new team `draft`, in
     * `community`, by default the selected one: a synced team homed there, or a
     * new team where it syncs. Only such a team can have that community's
     * hosted agents. */
    teamHere(team: Pick<TeamChange, "id" | "draft">, community?: string): boolean;
    /** Deletes the team; its agents are untouched. */
    removeTeam(id: string): Promise<void>;
    /** Keeps the local team with `id` from moving to its community, as while
     * its editor has unsaved changes, until the returned release. */
    holdTeam(id: string): () => void;
    /** Where the team's config lives, for its status line. */
    teamSync(id: string): SyncState;
    /** Where the agent's config lives here, for its status line; undefined
     * for a hosted agent, or while its first copy is being made or checked. */
    agentSync(agent: AgentKey): SyncState | undefined;
};
export type ConfigHistory = Readonly<{
    read: SnapshotRead;
    sides: readonly Readonly<{
        side: Side;
        expected: Expected;
        head: RelayEvent | undefined;
        version: number;
    }>[];
    /** What a settings revision must fit to be reverted to. */
    settings?: SettingsCheck;
    /** Saves a revert or restore of `side`, as History builds it. */
    revise(side: Side, template: ReturnType<typeof revertTemplate>): Promise<RevertOutcome>;
}>;
declare module "@deepseek-ai/cordis" {
    interface Context {
        agents: Agents;
    }
}
/** The team sections for agent `self`: each team it is on, its members that
 * still exist by name and npub (by npub alone where `agents` has no name),
 * and the team's instructions. */
export declare function teamPrompt(teams: readonly Team[], agents: readonly Readonly<{
    pubkey: string;
    name?: string;
}>[], self: string): string;
export { fromOwner } from "./owner-attestation";
/** What Agents needs of the communities: the viewer, the selected one, and
 * a connection to any joined one without selecting it. */
export type AgentCommunities = Pick<Communities, "snapshot" | "subscribe" | "open">;
export declare class AgentsService extends Service implements Agents {
    private readonly communities;
    private readonly native;
    readonly storage: AgentStore;
    private readonly authorize;
    private readonly localActivity;
    /** Runs watch classifiers on this device's decision backend. */
    private readonly decisions;
    /** Which artifact types an agent has synced, from its config channel
     * binding. Unset, every agent starts `local`. */
    private readonly bindingFor?;
    /** The Buzz settings on this device that agents' runs can change. */
    private readonly deviceSettings?;
    private readonly executions;
    private checkExecution;
    private checkExecutionType;
    registerExecution(provider: AgentExecutionProvider): void;
    bindExecution(key: AgentKey, binding: Readonly<{
        id: string;
        config?: JsonValue;
    }>): Promise<void>;
    executionBinding(key: AgentKey): Readonly<{
        provider: string;
        config?: JsonValue;
    }> | undefined;
    inspectExecution(key: AgentKey): Promise<Readonly<{
        provider: string;
        config?: JsonValue;
    }> | undefined>;
    execution(key: AgentKey, session: AgentExecutionSession): Promise<AgentExecution | undefined>;
    private readonly hookContributions;
    registerHook(hook: AgentHook): void;
    dispatchHook(harness: string, event: string, input: unknown, context: AgentHookContext, options: AgentHookDispatchOptions): Promise<unknown>;
    private readonly contributions;
    private readonly tabContributions;
    private readonly attentionControls;
    private readonly addedTools;
    /** Every added tool's name, its plugin active or still starting. */
    private readonly toolNames;
    private readonly attentionSources;
    private readonly sourceTails;
    private readonly listeners;
    private requests;
    private updates;
    private teamUpdates;
    private readonly approving;
    /** Every saved membership, deleted ones included: native's list is the
     * agent list, and `records` only adds settings to it. */
    private identities;
    /** Each membership's settings as saved, by key, and as the owner and the
     * agent see them. Its home record also keeps the agent's config. */
    private records;
    /** Each membership's last change in its queue, until it settles. */
    private readonly changes;
    /** How many changes other than timer progress each membership has queued. */
    private readonly changing;
    /** Each membership's timer progress that is not saved yet. */
    private readonly progressing;
    private teamList;
    /** Synced teams as discovery last found them, by home community. */
    private readonly syncedTeams;
    private readonly teamMoves;
    /** Local teams with a move running. */
    private readonly moving;
    /** Local teams kept from moving, as while their editor has a draft: how
     * many holds each has. */
    private readonly held;
    /** Teams whose last hold went while a move of them ran: tried again once
     * it ends. */
    private readonly unheld;
    /** Local teams whose community already has a different copy, by id: the
     * community. */
    private readonly conflicts;
    /** The account whose synced teams `state.teams` shows. */
    private teamsFor;
    /** Each new synced team's home, fixed at its first Save, by draft id. */
    private readonly teamDrafts;
    private state;
    /** By origin, so each agent listens in its own community, selected or not. */
    private bound;
    private readonly runners;
    private readonly coreMemory;
    /** Counts list requests, so only the latest one is applied. */
    private listed;
    /** Each running cleanup of a deleted membership, by key, how to stop it,
     * and whether it finished. */
    private cleaning;
    /** Memberships a re-import or add is taking back; no cleanup starts for
     * them. */
    private reclaiming;
    /** Durable reviewed settings awaiting an observed native installation. */
    private importDrafts;
    /** Memberships, imported or added, whose archive state could not be
     * checked yet, saved so Retry survives a restart until a check confirms
     * the state. */
    private unarchiving;
    /** Each Delete running, by pubkey, so pressing it again joins it. */
    private deleting;
    /** The synced settings head each agent last tried to take its type from. */
    private followedType;
    /** Agents whose type is changing here. No community attaches them
     * meanwhile, even one whose config comes up mid-change, so none moves
     * their settings in under the old type. */
    private retyping;
    /** Each Remove from a community running, by key, as `deleting`. */
    private leaving;
    private unfinished;
    /** The viewer's agent records in each community, by origin, as last read
     * from its live session and written since. */
    private listings;
    /** Memberships whose record is being written, so a sync writes each once. */
    private listing;
    /** By origin until its records are first read: the listings written or
     * removed meanwhile, which the read must not undo. */
    private edits;
    /** By origin, the binding whose read of its records is under way. */
    private reading;
    /** Hosted agents whose setup, save or delete is running, so one waits for
     * the others. */
    private busy;
    /** Hosted and elsewhere agents as last shown, kept while unchanged. */
    private shown;
    /** By origin: the agents last said to be online there, and when. */
    private presence;
    /** Confirmed synced config copies, the only synced launch source. */
    private readonly configStore;
    /** Each bound community's config channels, while config sync is on. */
    private readonly communityConfigs;
    /** Origins whose presence is being sent. */
    private announcing;
    private readonly protection;
    constructor(ctx: Context, communities: AgentCommunities, native?: AgentsNative | undefined, storage?: AgentStore, authorize?: (pubkey: string, signal: AbortSignal) => Promise<NipOaAuthorization>, localActivity?: {
        reader: import("./local-activity").LocalAgentSource;
        begin(input: Omit<import("./local-activity").LocalWork, "state" | "startedAt" | "publishing" | "replyMessages" | "publishedMessageIds" | "error" | "dismissed" | "stoppable" | "retryable">, retry?: () => void): {
            channelId: string;
            started: () => void;
            confirmSolo: (conversationName?: string) => void;
            sending: () => () => void;
            reply: (messageId: string) => void;
            supersede: () => void;
            step: (tool: string, target?: string) => void;
            finish: (result: import("./local-activity").WorkOutcome) => void;
            interruptible: (stop: () => Promise<void>) => void;
            remove: () => void;
        };
        clear(scope?: string, agent?: string): void;
    }, 
    /** Runs watch classifiers on this device's decision backend. */
    decisions?: Decisions | undefined, 
    /** Which artifact types an agent has synced, from its config channel
     * binding. Unset, every agent starts `local`. */
    bindingFor?: ((agent: Agent) => ConfigBinding) | undefined, 
    /** The Buzz settings on this device that agents' runs can change. */
    deviceSettings?: DeviceSettings | undefined);
    register<Config>(type: AgentType<Config>): void;
    types: () => readonly Readonly<Omit<AgentType<unknown>, "voice"> & {
        voice?(seat: AgentVoicePipe): Promise<AgentVoiceConnection>;
    } & {
        key: string;
        pluginId: string;
        revision: string;
    }>[];
    registerTab(tab: AgentAddedTab): void;
    addedTabs: () => readonly Readonly<Readonly<{
        id: string;
        title: string;
        component: ComponentType<{
            agent: Agent;
            /** Opens a link, such as a profile, where the tab is shown; false when it
             * can't there. Absent where the tab can open nothing. */
            open?: ((target: string) => boolean) | undefined;
            /** Whether `open` can open this link, so the tab shows it as text if not. */
            canOpen?: ((target: string) => boolean) | undefined;
        }>;
        /** Whether the tab shows for this agent; absent, it shows for each. */
        when?: (agent: Agent) => boolean;
        /** Calls `listener` when `when` may answer differently. */
        subscribe?: (listener: () => void) => () => void;
    }> & {
        key: string;
        pluginId: string;
        revision: string;
    }>[];
    controlAttention(): void;
    /** Whether a plugin that shows Attention is on, so Attention may run. */
    private attentionShown;
    addTool(tool: AddedTool): void;
    addAttentionSource(source: import("./attention-sources").AttentionSource): void;
    private attentionProvider;
    attentionProviders: () => {
        provider: string;
        builtIn?: boolean;
        description?: string;
        configExample?: any;
    }[];
    presentWatch: (watch: import("./attention").SourceWatch, title: string) => Readonly<{
        type: string;
        icon?: DefinedIcon;
        target?: string;
        subtitle?: string;
        link?: Readonly<{
            href: string;
            title: string;
        }>;
        details?: ComponentType;
    }> | undefined;
    private history;
    private startAttentionSource;
    tools: () => readonly Readonly<Readonly<{
        name: string;
        description: string;
        inputSchema: Readonly<Record<string, unknown>>;
        call(client: import("../../buzz-mcp/client").BuzzClient, context: import("../../buzz-mcp/client").Context, args: Record<string, unknown>): Promise<import("../../buzz-mcp/tools").Reply>;
    }> & {
        id: string;
    } & {
        key: string;
        pluginId: string;
        revision: string;
    }>[];
    readonly harness: Readonly<{
        conversation(delivery: Delivery, scope: import("../agent-harness/kit").HarnessScope): Promise<import("../agent-harness/kit").HarnessConversation | undefined>;
        systemPrompt(delivery: Delivery, options: Readonly<{
            scope: import("../agent-harness/kit").HarnessScope;
            cwd: string;
            instructions: string;
            tools?: boolean;
        }>): Promise<string>;
        turnPrompt(delivery: Delivery, conversation: import("../agent-harness/kit").HarnessConversation, options?: Readonly<{
            cursor?: string;
        }>): Promise<import("../agent-harness/kit").HarnessPrompt>;
        standalonePrompt(agent: AgentHandle, text: string): string;
        tools(agent: AgentHandle, conversation?: import("../agent-harness/kit").HarnessConversation, options?: Readonly<{
            read?(path: string): Promise<Uint8Array>;
        }>): import("../host/service").McpHandler;
        reply(agent: AgentHandle, conversation: import("../agent-harness/kit").HarnessConversation, text: string, options?: Readonly<{
            notifyOwner?: boolean;
        }>): Promise<void>;
    }>;
    wake(key: AgentKey, wake: AgentWake): void;
    private wakeIn;
    snapshot: () => Readonly<{
        status: "unavailable" | "loading" | "ready" | "error";
        /** Whether a watch's classifier can run on this device now. */
        classifier: ClassifierAvailability;
        /** The selected community's agents, while it is connected. */
        agents: readonly Agent[];
        /** Every agent kept running here, whichever community is selected: the
         * viewer's agents in each joined community not disconnected, but none
         * whose Delete or Remove there is unfinished. */
        running: readonly Agent[];
        /** Running agents that were working when the app last closed or reloaded,
         * until the owner resumes or forgets those turns. */
        interrupted: readonly Agent[];
        /** The owner's teams on this device, which every community shares, and
         * each synced team with a confirmed copy. */
        teams: readonly Team[];
        /** Whether the selected community's config channels are up, so a new team
         * made there syncs. What `teamHere` says of a new team changes with it. */
        syncsTeams?: boolean;
        error?: string;
    }>;
    subscribeSteps: (agent: AgentKey, listener: () => void) => () => void;
    subscribe: (listener: () => void) => () => void;
    resumeInterrupted: () => void;
    dismissInterrupted: () => void;
    /** The agents the notice names, and only they, are resumed or forgotten. */
    private interruptedKeys;
    find: (pubkey: string) => Readonly<{
        /** Its membership in this community, which names it in every call here
         * and keys whatever is kept for it, such as its sessions. */
        key: AgentKey;
        /** Its identity, the same in each of its communities. */
        pubkey: string;
        name: string;
        /** Its picture in this community. */
        picture?: string;
        /** The agent type's key, `pluginId/typeId`. */
        type: string;
        owner: string;
        relay: string;
        place: AgentPlace;
        /** A hosted agent its provider made whose setup has not finished; `finish`
         * continues it. */
        unfinished?: true;
        /** Imported, but whether it is still archived in its community could not
         * be checked; `unarchive` tries again. */
        archiveUnchecked?: true;
        /** Its Delete, or its Remove from this community, did not finish: it is
         * stopped here until that runs again. */
        deleting?: true;
        protection?: Readonly<{
            provider: string;
            policy: unknown;
        }>;
        protectionRevision?: number;
        /** Saved execution selection for this membership on this device. */
        executionBinding?: Readonly<{
            provider: string;
            config?: JsonValue;
        }>;
        attention: Readonly<Record<string, Readonly<{
            slug: string;
            value: AttentionValue;
            modifiedAt: number;
        }>>>;
        /** Stored attention objects that are invalid or over a limit, by slug. */
        skipped: Readonly<Record<string, Readonly<{
            slug: string;
            value: unknown;
            modifiedAt: number;
            problem: string;
        }>>>;
        /** Run state of its timers, by slug; written only by the runtime. */
        timers: Readonly<Record<string, Readonly<{
            armedAt: number;
            nextDue: number;
            used: number;
        }>>>;
        sourceRuns?: Readonly<Record<string, string>>;
        attentionHistory?: AgentRecord["attentionHistory"];
        /** Whether its watches and timers wake it: true while a plugin shows
         * Attention. Off keeps every object. */
        attentionEnabled: boolean;
        /** Its type's settings, the same in each of its communities. */
        config: unknown;
        /** The synced head each synced side's editor opens; Save revises it. */
        configBase?: ConfigBase;
        /** Why a synced side can't be read here; its field is then not shown. */
        configProblem?: string;
    }> | undefined;
    handle(key: AgentKey): Readonly<{
        key: AgentKey;
        protection?: AgentProtection | undefined;
        pubkey: string;
        /** Its community, as the `wss://` origin its native row names. */
        relay: string;
        name: string;
        owner: string;
        /** Installed local types and owner-reviewed creation requests. */
        agentTypes?(): readonly Readonly<{
            key: string;
            title: string;
        }>[];
        createAgent?(input: AgentCreationInput): Promise<Readonly<{
            requestId: string;
            saved: false;
        }>>;
        /** Owner-reviewed changes to one of the owner's agents here. */
        updateAgent?(input: AgentUpdateInput): Promise<Readonly<{
            requestId: string;
            saved: false;
        }>>;
        /** The owner's agents here, or the one with this pubkey or name. */
        readAgents?(agent?: string): Promise<AgentReadout | readonly AgentReadout[]>;
        /** The owner's teams the Agents page shows here, or the one with this id
         * or name. */
        readTeams?(team?: string): Promise<TeamReadout | readonly TeamReadout[]>;
        /** Owner-reviewed name and instructions changes to one of those teams. */
        updateTeam?(input: TeamUpdateInput): Promise<Readonly<{
            requestId: string;
            saved: false;
        }>>;
        /** This device's plugins, as the agent may read and change them. */
        plugins?: AgentPlugins | undefined;
        /** On a run's handle only: wakes this agent in another of its
         * conversations, as `Agents.wake` would, telling it the wake is its own. */
        handoff?(handoff: AgentHandoff): void;
        /** Rechecks an operation lifetime after channel startup, before signing. */
        publish(event: AgentEventTemplate, check?: () => void): Promise<RelayEvent>;
        /** Reads the community as the agent, seeing only what it may see. */
        query(filters: readonly object[]): Promise<RelayEvent[]>;
        effectiveEdit(id: string, channel: string): Promise<RelayEvent>;
        /** Finds profiles by `name` or `display_name`, as the agent, best match
         * first. `undefined` when its community has no profile name search. */
        searchProfiles(query: string, limit: number): Promise<RelayEvent[] | undefined>;
        /** Uploads base64 `data`, a file of any type its community accepts, as
         * the agent. `mime` is a hint; the community decides the type. */
        upload(data: string, mime: string): Promise<AgentUpload>;
        /** Saves one of its community's media blobs, of any type, by URL or
         * `sha256[.ext]`, to a local file for the agent. */
        media(url: string): Promise<AgentMedia>;
        /** Repository `repo` of `owner` in its community: its URL, and the Git
         * header that authorizes it there as the agent for a minute. */
        gitAuth(owner: string, repo: string): Promise<GitAuth>;
        /** Writes memory entry `slug`, newer than the entry it replaces (`after`,
         * that entry's `createdAt`, or 0); a `null` body deletes it. The owner
         * reads it back. */
        remember(slug: string, body: string | null, after: number): Promise<RelayEvent>;
        /** The owner's channel templates on this device, each with the agents it
         * adds that are the owner's agents in this agent's community. */
        templates(): readonly Readonly<{
            name: string;
            canvas: string;
            agents: readonly string[];
        }>[];
        /** The owner's thread tabs on this device in the agent's community;
         * undefined while it is not connected. */
        tabs(): ReturnType<typeof channelTabs> | undefined;
        /** On a run's handle only: Buzz settings on this device. */
        settings?: DeviceSettings;
        /** Takes notes for this conversation, oldest first. A thread session passes
         * its root; a channel session omits it and takes all notes in the channel. */
        notes?(channelId: string, root?: string): readonly string[];
        /** Puts back notes taken for a turn that never began, ahead of any left
         * since, targeting the same conversation that took them. */
        restoreNotes?(channelId: string, notes: readonly string[], root?: string): void;
        /** The agent's own attention, one object at a time. */
        attention: AgentAttention;
    }> | undefined;
    canConnectExternal(key: AgentKey): any;
    connectExternal(key: AgentKey, signal: AbortSignal, connected: () => void, scopes: readonly ExternalScope[]): Promise<Readonly<{
        url: string;
        headers: readonly Readonly<{
            name: string;
            value: string;
        }>[];
        close: () => Promise<void>;
        closed: Promise<void>;
        authorize?: (request: import("../host/service").McpAuthorization) => Promise<void>;
    }>>;
    note(key: AgentKey, channelId: string, text: string, root?: string): boolean;
    relay: (key: AgentKey) => RelayData | undefined;
    core: (key: AgentKey, signal?: AbortSignal) => Promise<string | null | undefined>;
    private localCache;
    /** Local identities in every community, plus completed hosted choices in the
     * selected community. Hosted choices grant no local custody. */
    local: () => LocalAgentsSnapshot;
    create({ type, name, picture, config }: NewAgent): Promise<Readonly<{
        /** Its membership in this community, which names it in every call here
         * and keys whatever is kept for it, such as its sessions. */
        key: AgentKey;
        /** Its identity, the same in each of its communities. */
        pubkey: string;
        name: string;
        /** Its picture in this community. */
        picture?: string;
        /** The agent type's key, `pluginId/typeId`. */
        type: string;
        owner: string;
        relay: string;
        place: AgentPlace;
        /** A hosted agent its provider made whose setup has not finished; `finish`
         * continues it. */
        unfinished?: true;
        /** Imported, but whether it is still archived in its community could not
         * be checked; `unarchive` tries again. */
        archiveUnchecked?: true;
        /** Its Delete, or its Remove from this community, did not finish: it is
         * stopped here until that runs again. */
        deleting?: true;
        protection?: Readonly<{
            provider: string;
            policy: unknown;
        }>;
        protectionRevision?: number;
        /** Saved execution selection for this membership on this device. */
        executionBinding?: Readonly<{
            provider: string;
            config?: JsonValue;
        }>;
        attention: Readonly<Record<string, Readonly<{
            slug: string;
            value: AttentionValue;
            modifiedAt: number;
        }>>>;
        /** Stored attention objects that are invalid or over a limit, by slug. */
        skipped: Readonly<Record<string, Readonly<{
            slug: string;
            value: unknown;
            modifiedAt: number;
            problem: string;
        }>>>;
        /** Run state of its timers, by slug; written only by the runtime. */
        timers: Readonly<Record<string, Readonly<{
            armedAt: number;
            nextDue: number;
            used: number;
        }>>>;
        sourceRuns?: Readonly<Record<string, string>>;
        attentionHistory?: AgentRecord["attentionHistory"];
        /** Whether its watches and timers wake it: true while a plugin shows
         * Attention. Off keeps every object. */
        attentionEnabled: boolean;
        /** Its type's settings, the same in each of its communities. */
        config: unknown;
        /** The synced head each synced side's editor opens; Save revises it. */
        configBase?: ConfigBase;
        /** Why a synced side can't be read here; its field is then not shown. */
        configProblem?: string;
    }>>;
    creationRequests: () => readonly AgentCreationRequest[];
    dismissCreation: (id: string) => void;
    approveCreation(id: string, input: NewAgent): Promise<Readonly<{
        /** Its membership in this community, which names it in every call here
         * and keys whatever is kept for it, such as its sessions. */
        key: AgentKey;
        /** Its identity, the same in each of its communities. */
        pubkey: string;
        name: string;
        /** Its picture in this community. */
        picture?: string;
        /** The agent type's key, `pluginId/typeId`. */
        type: string;
        owner: string;
        relay: string;
        place: AgentPlace;
        /** A hosted agent its provider made whose setup has not finished; `finish`
         * continues it. */
        unfinished?: true;
        /** Imported, but whether it is still archived in its community could not
         * be checked; `unarchive` tries again. */
        archiveUnchecked?: true;
        /** Its Delete, or its Remove from this community, did not finish: it is
         * stopped here until that runs again. */
        deleting?: true;
        protection?: Readonly<{
            provider: string;
            policy: unknown;
        }>;
        protectionRevision?: number;
        /** Saved execution selection for this membership on this device. */
        executionBinding?: Readonly<{
            provider: string;
            config?: JsonValue;
        }>;
        attention: Readonly<Record<string, Readonly<{
            slug: string;
            value: AttentionValue;
            modifiedAt: number;
        }>>>;
        /** Stored attention objects that are invalid or over a limit, by slug. */
        skipped: Readonly<Record<string, Readonly<{
            slug: string;
            value: unknown;
            modifiedAt: number;
            problem: string;
        }>>>;
        /** Run state of its timers, by slug; written only by the runtime. */
        timers: Readonly<Record<string, Readonly<{
            armedAt: number;
            nextDue: number;
            used: number;
        }>>>;
        sourceRuns?: Readonly<Record<string, string>>;
        attentionHistory?: AgentRecord["attentionHistory"];
        /** Whether its watches and timers wake it: true while a plugin shows
         * Attention. Off keeps every object. */
        attentionEnabled: boolean;
        /** Its type's settings, the same in each of its communities. */
        config: unknown;
        /** The synced head each synced side's editor opens; Save revises it. */
        configBase?: ConfigBase;
        /** Why a synced side can't be read here; its field is then not shown. */
        configProblem?: string;
    }>>;
    updateRequests: () => readonly AgentUpdateRequest[];
    dismissUpdate: (id: string) => void;
    approveUpdate(id: string, input: NewAgent): Promise<void>;
    teamUpdateRequests: () => readonly Readonly<{
        id: string;
        requester: string;
        requesterName: string;
        owner: string;
        community: string;
        team: string;
        /** The team as it was requested over. */
        base: Pick<Team, "name" | "instructions" | "revision">;
        name?: string;
        instructions?: string;
    }>[];
    dismissTeamUpdate: (id: string) => void;
    approveTeamUpdate(id: string, { name, instructions }: Pick<Team, "name" | "instructions">): Promise<void>;
    private pendingRequests;
    /** The community `agent` asks from. */
    private callerOrigin;
    /** The teams the Agents page shows in `agent`'s community. */
    private callerTeams;
    private agentReadout;
    private teamReadout;
    /** The type `change` leaves the agent with, refusing what it cannot apply. */
    private updateKind;
    /** Whether watch classifiers can run on this device: the selected
     * decision provider is ready. */
    classifier(): ClassifierAvailability;
    private availability;
    private updateClassifier;
    /** The event's surroundings for the classifier, from what the app knows. */
    private context;
    private displayName;
    /** Has the provider make the agent, then sets it up. From here on it is
     * kept, unfinished until set up, so a failure never makes a second one. */
    private provision;
    finish(pubkey: string): Promise<Readonly<{
        /** Its membership in this community, which names it in every call here
         * and keys whatever is kept for it, such as its sessions. */
        key: AgentKey;
        /** Its identity, the same in each of its communities. */
        pubkey: string;
        name: string;
        /** Its picture in this community. */
        picture?: string;
        /** The agent type's key, `pluginId/typeId`. */
        type: string;
        owner: string;
        relay: string;
        place: AgentPlace;
        /** A hosted agent its provider made whose setup has not finished; `finish`
         * continues it. */
        unfinished?: true;
        /** Imported, but whether it is still archived in its community could not
         * be checked; `unarchive` tries again. */
        archiveUnchecked?: true;
        /** Its Delete, or its Remove from this community, did not finish: it is
         * stopped here until that runs again. */
        deleting?: true;
        protection?: Readonly<{
            provider: string;
            policy: unknown;
        }>;
        protectionRevision?: number;
        /** Saved execution selection for this membership on this device. */
        executionBinding?: Readonly<{
            provider: string;
            config?: JsonValue;
        }>;
        attention: Readonly<Record<string, Readonly<{
            slug: string;
            value: AttentionValue;
            modifiedAt: number;
        }>>>;
        /** Stored attention objects that are invalid or over a limit, by slug. */
        skipped: Readonly<Record<string, Readonly<{
            slug: string;
            value: unknown;
            modifiedAt: number;
            problem: string;
        }>>>;
        /** Run state of its timers, by slug; written only by the runtime. */
        timers: Readonly<Record<string, Readonly<{
            armedAt: number;
            nextDue: number;
            used: number;
        }>>>;
        sourceRuns?: Readonly<Record<string, string>>;
        attentionHistory?: AgentRecord["attentionHistory"];
        /** Whether its watches and timers wake it: true while a plugin shows
         * Attention. Off keeps every object. */
        attentionEnabled: boolean;
        /** Its type's settings, the same in each of its communities. */
        config: unknown;
        /** The synced head each synced side's editor opens; Save revises it. */
        configBase?: ConfigBase;
        /** Why a synced side can't be read here; its field is then not shown. */
        configProblem?: string;
    }>>;
    private setUp;
    portable(): Promise<{
        teams: readonly OldTeam[];
        warnings: readonly string[];
        agents: Readonly<{
            source: PortSource;
            connection?: import("./native").SavedConnection;
            pubkey: string;
            name: string;
            picture?: string;
            relay: string;
        }>[];
        here: string[];
    }>;
    port(input: PortInput): Promise<Ported>;
    /** Takes over an identity an earlier agent system saved. One deleted here
     * whose cleanup already archived it comes back unarchived where the owner
     * can, and otherwise says it is still archived. */
    private portIdentity;
    /** Unarchives an agent that came into the binding's community, as one
     * deleted or removed there may have been archived, noting what is left. */
    private unarchiveHere;
    portTeam({ id, type, }: Readonly<{
        id: string;
        type: string;
    }>): Promise<TeamPort>;
    /** Saves a new identity of `type` in the selected community, or `binding`'s,
     * with the type's default settings, or the `config` it was made with,
     * adopting what a brought-over one carried. */
    private add;
    private selectedOrigin;
    /** The selected community's live binding, where agents are made. */
    private selectedBinding;
    configHistory: (key: AgentKey) => ConfigHistory | undefined;
    teamHistory: (id: string) => ConfigHistory | undefined;
    save(key: AgentKey, change: AgentChange): Promise<void>;
    /** Why `identity`'s synced settings can't be revised here: their head
     * names another type. */
    private otherType;
    /** Saves each synced side an edit changed as the next revision of the head
     * its editor opened; throws unless every one saved. */
    private saveSynced;
    /** Saved now, an edit would land in the local copy being moved and never
     * be sent, so it stays in its editor until the move is confirmed. */
    private refuseWhileMoving;
    /** A hosted agent's name and picture are its provider's to publish; the app
     * then lists it under them. Its settings are the provider's, not saved here. */
    private saveHosted;
    sessionState(key: AgentKey, place: SessionPlace): SessionState;
    session(key: AgentKey, place: SessionPlace, action: SessionControlAction): Promise<void>;
    /** Whether the owner can stop a hosted agent's turn: its provider can. A
     * hosted agent's key is its pubkey. */
    interruptible(pubkey: AgentKey): boolean;
    hostedInstructions(pubkey: AgentKey): HostedInstructions | undefined;
    /** Stops the hosted agent's turn in `place`; false when none was running. */
    interrupt(pubkey: AgentKey, place: Readonly<{
        channelId: string;
        threadRootId: string;
    }>): Promise<boolean>;
    /** A hosted agent shown now, its provider, and its community's live session. */
    private hosted;
    retype(key: AgentKey, type: string, change?: Readonly<{
        config: unknown;
    }>): Promise<("instructions" | "workspace")[]>;
    /** Runs a change of `identity`'s type once its home's attach in flight
     * settles, with no attach of it anywhere until the change ends. */
    private typeChange;
    /** Saves synced settings as `type`'s, unless they already are. */
    private publishType;
    /** Makes the agent `type` here with `config`, as its type's change saves. */
    private applyType;
    /** Another device changed the agent's type: its synced settings name the
     * new one, which this device takes too when it has it. So does the device
     * that saved them when its own change failed after. Each head is tried
     * once, and once more after a run of the agent ends (`retakeType`); a type
     * this device doesn't have shows as its start's problem, and its settings
     * can't be saved here meanwhile. */
    private followType;
    /** A run of the agent ended: a type it couldn't take, as while it was
     * answering, is tried once more. */
    private retakeType;
    previewRetype(key: AgentKey, type: string): RetypePreview;
    remove(key: AgentKey): Promise<void>;
    /** Keeps its key until each community it is in confirms it left every
     * channel and was archived, so nothing can import it back meanwhile, here
     * or in another copy of the app. The owner signs each step. */
    private removeLocal;
    /** Archives the config channel in the agent's home community, which it is
     * no longer a member of. Nothing to do when its config never synced. */
    private archiveHomeConfig;
    /** Takes the membership out of its community: it leaves every channel and
     * is archived there, and its record there is deleted, and only then its key
     * and row here. Nothing is deleted when its community is offline or the
     * cleanup fails. All of it runs under its removal held for this copy of the
     * app, so a cleanup from another copy can't undo its being added there
     * again afterwards. Its catalog share there goes too, as nothing there
     * lists it to unshare from after; Delete also archives its config channel
     * in its home, which keeps it. */
    private depart;
    memberships(pubkey: string): {
        key: string;
        origin: string;
        connected: boolean;
        deleting?: true;
    }[];
    forget(key: AgentKey): Promise<void>;
    joinable(): Readonly<{
        /** Its membership in this community, which names it in every call here
         * and keys whatever is kept for it, such as its sessions. */
        key: AgentKey;
        /** Its identity, the same in each of its communities. */
        pubkey: string;
        name: string;
        /** Its picture in this community. */
        picture?: string;
        /** The agent type's key, `pluginId/typeId`. */
        type: string;
        owner: string;
        relay: string;
        place: AgentPlace;
        /** A hosted agent its provider made whose setup has not finished; `finish`
         * continues it. */
        unfinished?: true;
        /** Imported, but whether it is still archived in its community could not
         * be checked; `unarchive` tries again. */
        archiveUnchecked?: true;
        /** Its Delete, or its Remove from this community, did not finish: it is
         * stopped here until that runs again. */
        deleting?: true;
        protection?: Readonly<{
            provider: string;
            policy: unknown;
        }>;
        protectionRevision?: number;
        /** Saved execution selection for this membership on this device. */
        executionBinding?: Readonly<{
            provider: string;
            config?: JsonValue;
        }>;
        attention: Readonly<Record<string, Readonly<{
            slug: string;
            value: AttentionValue;
            modifiedAt: number;
        }>>>;
        /** Stored attention objects that are invalid or over a limit, by slug. */
        skipped: Readonly<Record<string, Readonly<{
            slug: string;
            value: unknown;
            modifiedAt: number;
            problem: string;
        }>>>;
        /** Run state of its timers, by slug; written only by the runtime. */
        timers: Readonly<Record<string, Readonly<{
            armedAt: number;
            nextDue: number;
            used: number;
        }>>>;
        sourceRuns?: Readonly<Record<string, string>>;
        attentionHistory?: AgentRecord["attentionHistory"];
        /** Whether its watches and timers wake it: true while a plugin shows
         * Attention. Off keeps every object. */
        attentionEnabled: boolean;
        /** Its type's settings, the same in each of its communities. */
        config: unknown;
        /** The synced head each synced side's editor opens; Save revises it. */
        configBase?: ConfigBase;
        /** Why a synced side can't be read here; its field is then not shown. */
        configProblem?: string;
    }>[];
    join(key: AgentKey): Promise<Ported>;
    leave(key: AgentKey): Promise<void>;
    /** Takes it out of one community, as Delete does, and keeps its key and
     * settings for its others. Its conversations stay on this device, so they
     * come back if it is added again; what it paid attention to there does not. */
    private leaveHere;
    unarchive(key: AgentKey): Promise<string | undefined>;
    /** Has a hosted agent's provider remove it, then takes it out of the
     * community as Delete does for one here. Its record goes last, so a failure
     * leaves it listed for Delete to be tried again. */
    private removeHosted;
    private exclusive;
    saveTeam({ id, name, instructions, members, opened, draft, }: TeamChange): Promise<Readonly<{
        id: string;
        name: string;
        instructions: string;
        members: readonly string[];
        revision?: string;
    }>>;
    teamHere({ id, draft }: Pick<TeamChange, "id" | "draft">, community?: string): boolean;
    /** Where Save puts the team with `id`, or the new team `draft`: a synced
     * team's home, or where a new one syncs, staying in the community its
     * first Save chose. Undefined keeps the team on this device. */
    private teamHome;
    /** Where a new team made with `selected` selected syncs: nowhere only
     * when its relay is known to have no config channels. */
    private newTeamHome;
    /** Puts `members` on an old Buzz team's copy `id`, made from `saved` or,
     * the first time, `team`. Its name and instructions here are never
     * replaced. */
    private writeImportedTeam;
    removeTeam(id: string): Promise<void>;
    /** The communities where `pubkey` is one of the owner's agents a team
     * there can have. */
    private homesOf;
    /** Moves each local team whose members are all the owner's agents in
     * `origin` there, once its config channels are up and its agent records
     * read. A team that can't move yet stays local and is tried again on the
     * next connection. The move never writes over a relay team this device
     * didn't create: one that differs keeps the team local, as a conflict. */
    private moveTeams;
    holdTeam: (id: string) => () => undefined;
    private movedTeamId;
    teamSync: (id: string) => SyncState;
    agentSync: (key: AgentKey) => SyncState | undefined;
    /** Synced teams with a confirmed copy, as members use them. */
    private synced;
    private allTeams;
    private teamsChanged;
    /** Makes `team` so in its home community, online: only its owner's agents
     * there may be members, and none is added to that community here. Rejects
     * with what was and wasn't done unless all of it was confirmed. */
    private changeSyncedTeam;
    /** Saves the teams; memory changes once storage has taken them, and the
     * promise settles once they are saved. When the save fails, memory goes
     * back to the teams storage still has. */
    private writeTeams;
    private showTeams;
    /** Saves which imports need an archive check, then keeps it in memory. */
    private setArchiveUnchecked;
    /** Saves the unfinished setups; memory changes once storage has taken them,
     * and the promise settles once they are saved. When the save fails, memory
     * goes back to the setups storage still has. */
    private writeUnfinished;
    private showUnfinished;
    /** Reads the viewer's agent records in the community, then lists each of
     * its agents here that they lack. A sync asks again until one succeeds.
     * Without the desktop app there are no agents to show. */
    private readListings;
    /** The community's listings: as read, or until the first read finishes,
     * those written since. */
    private rowsOf;
    private rowOf;
    /** Lists each agent here in the community whose record is missing or shows
     * another name, picture or type. Waits for the first read, so it never
     * replaces a record it has not seen. */
    private list;
    /** Writes the agent's record and lists it so, without reading it back.
     * Never relists an agent being deleted: its record may already be gone. */
    private writeListing;
    /** Whether its Delete, or its leaving the community at `origin`, started
     * there; in its other communities it is still listed. */
    private isDeleting;
    private unlist;
    /** Replaces or removes the agent's listing, and keeps the change until the
     * community's records are first read. */
    private setRow;
    /** The selected community's agents that are not here: hosted ones, set up
     * or not, and ones on the viewer's other devices. */
    private listedAgents;
    /** The agent as shown, the same object while nothing about it changed. */
    private show;
    /** Changes one agent's record. This is the only way a record changes:
     * owner settings, the agent's attention tools, timer progress, a provider
     * change and removal all send a change here. One agent's changes run in
     * the order they are sent, each after the one before it is saved or has
     * failed, so each one applies to the newest saved record, never to a copy
     * another change replaces. `apply` gets that record (or undefined) and
     * returns the next one, or null to remove it; it may throw to change
     * nothing. The owner and the agent see a change once it is saved, and the
     * promise settles then. When the save fails, the promise rejects and they
     * keep the saved record, so a form keeps its unsaved changes. `saved`
     * runs as the change is shown, before anyone is told. */
    private change;
    /** Records that timers ran or started counting, as a change to their run
     * state only. It applies to whatever the record is when its turn comes, so
     * it never undoes a change sent before it: when a timer was rearmed or
     * restarted meanwhile, its new deadline stays and only the occurrences it
     * used are added. Timers see it at once (`timersOf`), and memory keeps it
     * even when its save fails, so a timer does not run again at once. */
    private progress;
    /** Runs `step` after the agent's earlier changes have settled. */
    private queued;
    /** Saves `next` over `base` in the membership's own key, then keeps it.
     * Only this key: others may be another program's to change. A record
     * other than the agent's home record keeps no config, which is the
     * agent's, never one community's. */
    private commit;
    /** The agent's timers' run state as its timers go by: saved, with the
     * progress still being saved. */
    private timersOf;
    /** The agent's memberships, or every agent's, that were not deleted. */
    private liveRows;
    /** The agents a team in `origin` can have: its agents here, and its hosted
     * ones whose setup finished. */
    private teamAgents;
    /** Who rosters in `origin` name: the agents a team there can have. Until
     * its agent records are read, which tell a hosted agent from one on another
     * device, a synced team homed there names its other members by npub. */
    private teammates;
    /** The membership of this key, unless it was deleted. */
    private liveMember;
    /** Each row as a membership, with its key. */
    private withKeys;
    /** The agent's home record, which keeps its config: as saved or, without
     * one, its type's defaults, kept in memory until a save stores them.
     * Without its type there are no defaults yet. */
    private settingsOf;
    /** The membership's settings as its owner and agent see them: its own
     * attention, starting with none, and the agent's config. */
    private recordOf;
    private retypePlan;
    private view;
    /** What the agent starts with: its row, with each synced side's confirmed
     * copy over it. */
    /** The community whose config channel holds the agent's config: its home,
     * as every membership's row saved it, since that config applies in each
     * community it is in. Its other communities never discover, create or bind
     * one, so an Add can't split its config. */
    private configHome;
    /** Whether the agent is still a member of its home community. */
    private homeRemains;
    /** Which config sides the agent has synced: its home community's binding. */
    private configBinding;
    private resolve;
    /** For an agent whose config syncs: its row with each synced side's
     * confirmed copy, as editors show it and running agents use it, and those
     * heads as the base a Save revises. Undefined while every side is local. */
    private editorConfig;
    private configAgent;
    private archiveUnchecked;
    /** The live binding of the agent's community, if it has one now. */
    private bindingOf;
    /** Whether the agent stays running: it is the viewer's, and its community is
     * joined and not disconnected. A reconnect does not stop it. */
    private alive;
    /** A running agent, in any community. */
    private agent;
    /** The agent, while its community's session is live to run it in. */
    private ready;
    /** Reads the agent list from native. Every change is made there first and
     * then read back here, so the list has one source; Retry reads it again. */
    refresh(): Promise<void>;
    /** Brings the relay in line with the saved identities: publishes each name
     * its community lacks, and finishes Delete where connected. Each step
     * is safe to repeat; what fails is tried again on the next refresh or connect. */
    private sync;
    /** Starts the cleanup of a membership deleted under the old order, or
     * whose Delete or Remove stopped short of dropping it, unless one is
     * running or a re-import or add is taking it back. Its key there is gone,
     * so it can be imported or added again, and nothing tells whether someone
     * added it back to a channel since: it only drops the record and the row. */
    private cleanup;
    /** Stops running cleanups before a re-import or add takes a membership
     * back, `target` naming it by key, or every one of an agent by its pubkey,
     * and keeps new ones from starting until the import or add ends. Resolves
     * once every write they started has settled; none starts after the stop. */
    private reclaim;
    /** Deletes a deleted membership's record, then drops its row. A re-import's
     * stop holds through signing, while a publish already started settles, so
     * the deletion never lands on the record of an agent taken back. */
    private clean;
    /** Connects the selected community, where agents are made, and each one
     * the viewer has an agent in, deleted ones included so their cleanup can
     * finish; lets go of the rest. */
    private watch;
    /** Tries each unselected community whose connection failed again, since
     * nobody is there to press its Retry; its agents wait on it. Checks config
     * support again where its check failed. */
    private reconnect;
    private unbind;
    private bind;
    /** Brings up the community's config channels when config sync is on and
     * its relay passes the support check; a replaced binding drops it. */
    private startConfig;
    /** Delivers the session's live events, and retries what failed whenever its
     * connection recovers, which happens within the same session. A subscription
     * that comes back, after a reconnect or a failed route, first sends its
     * recent history again: what in it is new since this listener started was
     * missed while it was down, and is delivered now (`seen` drops the rest).
     * Older history is catch-up's, not replay's. */
    private listen;
    /** Refreshes the cached `core` memory of each agent running in the
     * community, which may have changed elsewhere while it was not connected. */
    private refreshCore;
    /** Rebuilds the snapshot's rows; true when it notified. */
    private update;
    /** Keeps live, in each community, the channels that the enabled watches
     * of the agents this copy runs name, so a watch also hears a public channel
     * the owner has not joined. A watch of "all" hears what the session already
     * listens to. A copy that does not hold an agent leaves its channels out. */
    private attend;
    /** Tells each community which agents this copy runs there: online every
     * minute while it does, and offline once it stops, unless another copy took
     * over. Offline is best effort; the relay lets a lapsed online expire. */
    private announce;
    private notify;
    /** The event's channel as the agent's community knows it, if at all. */
    private channelOf;
    /** Whether the agent is in the event's channel, by its relay-signed roster.
     * An event with no channel, or whose roster is unknown, is in none. A
     * roster only loaded from disk decides nothing (undefined): the agent may
     * have been removed or added since it was saved, so the event waits until
     * the relay confirms it. */
    private member;
    /** Whether the agent may read the event's channel: it is in it, or the
     * channel is public, as its relay-signed metadata says, and neither hidden
     * nor a DM, so the relay lets anyone read it. The stream is the owner's,
     * so a watch, even of "all", hears only what the agent itself could read.
     * For an agent not in the channel, metadata not yet read, or only loaded
     * from disk, decides nothing (undefined): the channel may have turned
     * public or private since. */
    private reads;
    /** Whether the event's channel is a DM of exactly the agent and one other,
     * by the same roster. A group DM, or one whose roster is unknown, is not. */
    private dm;
}
