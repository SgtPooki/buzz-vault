import type { RelayEvent } from "../relay/events";
import { type Expected, type SnapshotRead } from "./agent-config-artifacts";
import { type History, revertTemplate, type SettingsCheck } from "./agent-config-history";
/** What a revert's send came to: accepted, definitely not saved, or maybe. */
export type RevertOutcome = Readonly<{
    status: "accepted";
}> | Readonly<{
    status: "refused" | "uncertain";
    message: string;
}>;
export declare function AgentConfigHistory({ expected, head, version, read, settings, onRevert, title, onHistoryChange, selected, onSelect, }: {
    selected?: string | undefined;
    onSelect?: ((id?: string) => void) | undefined;
    expected: Expected;
    /** The current head from the config store; revert builds on it. */
    head: RelayEvent | undefined;
    /** Changes whenever history changes without a new head, as when an older
     * revision is redacted; history then reloads. */
    version?: number;
    read: SnapshotRead;
    /** Required to validate, and so to revert, `buzz.agent.settings`. */
    settings?: SettingsCheck;
    /** Signs and sends the revert; resolves to what the relay said. */
    onRevert(template: ReturnType<typeof revertTemplate>): Promise<RevertOutcome>;
    /** Names the section, as which side of the config it shows. */
    title?: string;
    /** Reports loaded counts without a separate history read. */
    onHistoryChange?: (history: History) => void;
}): import("react").JSX.Element;
/** A compact version target in the combined feed. */
export declare function AgentConfigVersionRow({ event, head, expected, settings, label, onSelect, }: {
    event: RelayEvent;
    head: RelayEvent | undefined;
    expected: Expected;
    settings?: SettingsCheck | undefined;
    label?: string;
    onSelect(): void;
}): import("react").JSX.Element;
