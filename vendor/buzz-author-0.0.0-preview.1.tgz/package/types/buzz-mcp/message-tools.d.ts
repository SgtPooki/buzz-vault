/** The Buzz tools that post a message, and so take `final`. Each harness
 * strips its own prefix from a tool's name before asking. */
export declare const MESSAGE_TOOLS: readonly ["send", "reply_in_subthread"];
export declare const isMessageTool: (name: unknown) => boolean;
/** Whether a call posts a message marked final, which can end the turn. */
export declare const isFinalMessage: (name: unknown, args: unknown) => boolean;
