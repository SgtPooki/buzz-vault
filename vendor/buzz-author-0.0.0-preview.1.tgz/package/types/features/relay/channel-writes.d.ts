import type { Outbox } from "./outbox";
import type { ChannelQueries } from "./contracts";
import type { RelayReader } from "./reader";
import type { EventData } from "./events";
export declare const DEFAULT_TEMPORARY_CHANNEL_TTL_SECONDS: number;
/** A Solo start that made no chat: the relay refused its create, or the
 * relay has no record of it once its delivery attempts ran out. */
export declare class ChatNotStarted extends Error {
}
/** Channel write commands use the same durable outbox and connection lifetime. */
export declare function createChannelWrites(outbox: Outbox | undefined, channels: ChannelQueries, reader: RelayReader, signal: AbortSignal, receipts?: Pick<Outbox, "snapshot" | "subscribe">, confirmCreation?: (id: string) => Promise<boolean>, 
/** Forward-looking agent choices plus the base archive rule for admissions. */
agents?: {
    selectable: () => readonly string[];
    archived: (pubkey: string) => boolean;
}, relayAuthor?: string, 
/** Signed roster discovery, including channels this viewer cannot open. */
discovery?: RelayReader, channelIdentity?: boolean): Readonly<{
    available: boolean;
    addAgents: (id: string, keys: readonly string[], active?: () => boolean) => Promise<void>;
    refreshMembership: (id: string) => Promise<Readonly<{
        id: string;
        name: string;
        description?: string | undefined;
        metadataPending?: boolean | undefined;
        visibility?: "public" | "private" | undefined;
        joinRole?: "member" | "guest" | undefined;
        viewerRole?: "owner" | "admin" | "member" | "guest" | "bot" | undefined;
        preview?: string | undefined;
        lastActivityAt?: number | undefined;
        activityKnown?: true;
        readOnly?: true;
        cached?: true;
        metadataCached?: true;
        pending?: true;
        hidden?: true;
        channelType?: "stream" | "forum" | "dm" | "solo" | "system";
        private?: true;
        autoJoin?: true;
        parentChannelId?: string | undefined;
        huddle?: true;
        updatedAt?: number;
        archived?: true;
        ttlSeconds?: number;
        members?: readonly string[];
        owners?: readonly string[];
        labels?: readonly string[];
        creator?: string;
        createdAt?: number;
        participants?: readonly string[];
    }>>;
    memberChannels: (pubkey: string, caller: AbortSignal, candidates: Iterable<string>) => Promise<string[]>;
    listsMember: (id: string, pubkey: string, caller: AbortSignal) => Promise<boolean>;
    createChannel(id: string, title: string, visibility: "open" | "private", description?: string, ttlSeconds?: number, active?: () => boolean, options?: Readonly<{
        labels?: readonly string[] | undefined;
        /** NIP-CL system channel: left out of reads that do not name it. */
        system?: boolean | undefined;
    }>): string;
    create(id: string, title: string, ttlSeconds?: number, named?: boolean, members?: readonly string[], active?: () => boolean, labels?: readonly string[]): string;
    /** Starts a Solo chat whose create names its `members`. It lists at once
     * as pending; `ready` settles once the relay OKs the create, which adds the
     * members (block/buzz#8421), and a background read then confirms the chat.
     * The chat's own events publish after `ready` (see `starting`). A refused
     * create (see `failed`) drops the pending chat. */
    start(id: string, title: string, members: readonly string[], ttlSeconds?: number, named?: boolean, setup?: {
        canvas: string;
        apply(): Promise<unknown>;
    }, options?: {
        labels?: readonly string[];
        active?: () => boolean;
    }): {
        create: string;
        ready: Promise<void>;
    };
    /** Settles when a chat this device is starting exists on the relay, so it
     * can be read and take events. */
    starting(id: string): Promise<void> | undefined;
    /** The Canvas a chat this device is starting will have ("" for none),
     * until its save lands: what a local agent's first turn reads, without
     * waiting for the relay. */
    startingCanvas(id: string): string | undefined;
    failed(id: string): boolean;
    /** Outbox fences local delivery and expiry; this read bypasses cached absence. */
    additionRecorded(event: EventData, caller: AbortSignal): Promise<boolean>;
    discardFailed(id: string): Promise<void>;
    delivered: (id: string, active?: () => boolean, addition?: boolean, retry?: boolean) => Promise<void>;
    refresh: (id: string, expected?: {
        member?: string;
        members?: readonly string[];
        system?: boolean | undefined;
    }, soloOnly?: boolean) => Promise<void>;
}>;
