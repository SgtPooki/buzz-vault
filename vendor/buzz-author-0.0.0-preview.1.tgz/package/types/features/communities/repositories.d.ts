export declare const DEFAULT_REPOSITORIES_FOLDER = "~/.buzz/REPOS";
export declare function repositoriesKey(community: string, viewer: string): string;
/** Paths are data, never shell fragments or prompt markup. Native save also checks the directory. */
export declare function repositoriesPath(value: string): string;
export declare function readRepositoriesFolder(community: string, viewer: string): string;
/** Required readback; never reports a failed or ignored write as saved. */
export declare function saveRepositoriesFolder(community: string, viewer: string, value: string): string;
/** Captured agent community/account, never the selected community. No filesystem changes. */
export declare function repositoriesContext(partition: string | undefined): string;
