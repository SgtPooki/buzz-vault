import type { EventData } from "./events";
import { type Attachment, type ChannelMessage } from "./contracts";
export declare function imetaAttachmentUrls(event: EventData): ReadonlySet<string>;
export declare function parseAttachments(event: EventData, markdownImages: readonly string[], markdownLinkNames?: ReadonlyMap<string, string>): Attachment[];
/** Base Buzz's displayed author: output signed by the relay's explicit NIP-11
 * `self` names its author in `actor`, else a leading `p` on channel events.
 * Any other signer, including a contact-key fallback, is the author. */
export declare function messageAuthor(event: EventData, signingAuthority: string | undefined): string;
/** A relay-verified NIP-09 that passed the relay's author/agent-owner check
 * removes its target. Keep this predicate shared by timeline and unread evidence.
 * Attributed owner deletion applies only to message kinds; reactions retain
 * ordinary raw-author deletion semantics. */
export declare function deletionApplies(deletion: EventData, event: EventData, signingAuthority: string | undefined): boolean;
/** Folds one window's top-level messages with their aux overlays: author deletes (5/9005),
 * author edits (40003, latest wins), reactions (7) and relay-signed thread summaries (39005).
 * Replies stay out of the top level; when they are not rows, the non-deleted `pendingReplies`
 * of a root layer on top of its summary: they add to `replyCount` and their authors lead
 * `participants`, so an own reply counts and shows before the relay's summary round trip.
 * Output is ascending by time; ties break on id so windows merge deterministically. */
export declare function foldMessages(channelId: string, relayAuthor: string, events: readonly EventData[], { includeReplies, collapseHuddles, signingAuthority, agentOwner, pendingReplies, }?: {
    includeReplies?: boolean;
    collapseHuddles?: boolean;
    signingAuthority?: string | undefined;
    agentOwner?: ((pubkey: string) => string | undefined) | undefined;
    /** Retained reply sends of this client's that no relay summary has counted yet
     * (MessageProjection decides that by observation order); absent means every
     * summary is complete. */
    pendingReplies?: ReadonlySet<string> | undefined;
}): ChannelMessage[];
/** Count people, but retain event IDs for author-only removal and duplicate cleanup. */
export declare function groupReactions(events: readonly EventData[], deleted?: (event: EventData) => boolean): readonly Readonly<{
    content: string;
    emoji?: Readonly<{
        shortcode: string;
        url: string;
    }>;
    events: readonly {
        id: string;
        authorId: string;
    }[];
}>[];
/** Keep the start ID stable without discarding its retained authoritative end. */
export declare function collapseHuddleCards(rows: ChannelMessage[], relayAuthor: string): ChannelMessage[];
